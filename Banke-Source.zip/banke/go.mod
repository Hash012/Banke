module banke.local/planner

go 1.23.0
