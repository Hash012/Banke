package org.banke.generic.sync;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * Small, offline-first native host. It accepts no external Intent URLs and exposes
 * no JavaScript-to-Java interface. LocalOnlyClient rejects external navigation.
 * Only APK-bundled scripts execute. File-system/content-provider access is disabled.
 *
 * The file-origin cross-origin exception is restricted to this immutable packaged
 * UI; connect-src plus sync-model.js restrict LAN endpoints. Do not reuse this
 * setting for untrusted HTML or a general-purpose browser (see SECURITY.md).
 */
public final class MainActivity extends Activity {
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(1);
        WebView view = new WebView(this);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setUserAgentString(settings.getUserAgentString() + " BankeGenericAndroid/1.1");
        view.setWebViewClient(new LocalOnlyClient());
        view.setWebChromeClient(new WebChromeClient());
        view.setBackgroundColor(0xfff6f8f7);
        setContentView(view);
        view.loadUrl("file:///android_asset/web/index.html");
    }
}
