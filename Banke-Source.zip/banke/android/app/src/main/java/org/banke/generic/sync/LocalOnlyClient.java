package org.banke.generic.sync;
import android.webkit.WebView;
import android.webkit.WebViewClient;
/** Never navigate a native-privileged view to user input or external pages. */
public final class LocalOnlyClient extends WebViewClient {
    @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return !url.startsWith("file:///android_asset/web/");
    }
}
