/* Shared pure synchronization model, no network and no embedded identities. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.BankeSyncModel=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const copy=v=>JSON.parse(JSON.stringify(v));
 const canonical=v=>{if(Array.isArray(v))return v.map(canonical);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])]));return v;};
 const equal=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
 const shared=s=>copy({semesterStart:s.semesterStart,events:s.events,completed:s.completed});
 function privateURL(raw){
  let u;try{u=new URL(raw.trim());}catch(_){throw Error('请填写完整电脑地址，例如 http://192.168.1.5:47833');}
  if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash||(u.pathname!=='/'&&u.pathname!==''))throw Error('地址只能包含 http(s)、IPv4 和端口，不可包含密码或路径');
  const p=u.hostname.split('.').map(Number);
  if(p.length!==4||p.some(n=>!Number.isInteger(n)||n<0||n>255)||!(p[0]===10||p[0]===127||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168)))throw Error('只连接电脑显示的私有 IPv4 局域网地址');
  return u.origin;
 }
 let serial=0;
 function copyID(){serial++;return 'local-conflict-'+Date.now().toString(36)+'-'+serial+'-'+Math.random().toString(36).slice(2,10);}
 // Rebase local edits made during a network request onto the server's response.
 function rebase(base,local,remote){
  if(equal(local,base))return copy(remote);
  let start=remote.semesterStart;
  if(local.semesterStart!==remote.semesterStart){
   if(local.semesterStart===base.semesterStart&&equal(local.events,base.events)&&equal(local.completed,base.completed))start=remote.semesterStart;
   else if(remote.semesterStart===base.semesterStart&&equal(remote.events,base.events)&&equal(remote.completed,base.completed))start=local.semesterStart;
   else throw Error('两端计划起点不同；原本机数据已保留，请先备份并统一第 1 周日期');
  }
  const bm=new Map(base.events.map(e=>[e.id,e])),lm=new Map(local.events.map(e=>[e.id,e])),rm=new Map(remote.events.map(e=>[e.id,e]));
  const out=new Map(),keys=new Set([...bm.keys(),...lm.keys(),...rm.keys()]);
  for(const id of keys){const b=bm.get(id),l=lm.get(id),r=rm.get(id);
   if(equal(l,r)){if(l)out.set(id,copy(l));continue;}
   if(equal(l,b)){if(r)out.set(id,copy(r));continue;}
   if(equal(r,b)){if(l)out.set(id,copy(l));continue;}
   if(!l||!r){out.set(id,copy(l||r));continue;}
   let merged=copy(r),conflict=!b;
   if(b){for(const k of Object.keys(l)){if(equal(l[k],r[k]))merged[k]=l[k];else if(equal(l[k],b[k]))merged[k]=r[k];else if(equal(r[k],b[k]))merged[k]=l[k];else conflict=true;}}
   if(merged.start>=merged.end)conflict=true;
   if(conflict){out.set(id,copy(r));const c=copy(l);c.id=copyID();out.set(c.id,c);}else out.set(id,merged);
  }
  const bs=new Set(base.completed),ls=new Set(local.completed),rs=new Set(remote.completed);
  const complete=[...new Set([...bs,...ls,...rs])].filter(k=>ls.has(k)===bs.has(k)?rs.has(k):ls.has(k));
  return {semesterStart:start,events:[...out.values()].sort((a,b)=>a.id.localeCompare(b.id)),completed:complete.sort()};
 }
 return Object.freeze({equal,shared,rebase,privateURL});
});
