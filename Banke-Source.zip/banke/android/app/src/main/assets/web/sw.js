'use strict';
const CACHE = 'banke-generic-offline-v110';
const ITEMS = ['./', './index.html', './styles.css', './app.js', './core.js','./sync-model.js','./sync.js', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ITEMS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(Promise.all([caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith("banke-generic-") && key !== CACHE).map(key => caches.delete(key)))), self.clients.claim()]));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  if (new URL(event.request.url).pathname.includes('/api/')) return;
  if (new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (!response.ok || response.type === 'opaque') return response;
    const clone = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request,clone)); return response;
  })));
});
