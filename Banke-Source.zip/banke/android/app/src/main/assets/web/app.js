(() => {
  'use strict';
  const Core = window.PlannerCore;
  const ANDROID = /BankeGenericAndroid/.test(navigator.userAgent);
  const $ = id => document.getElementById(id);
  const days = ['周一','周二','周三','周四','周五','周六','周日'];
  const categoryName = {work:'工作',study:'学习',course:'课程',life:'生活',rest:'休息'};
  const palettes = {work:['#e4f1f5','#81adc0','#466f81'],study:['#fcf1df','#dfba7b','#93733d'],course:['#e5f2eb','#88b69a','#4c7a60'],life:['#efebfa','#b09bcc','#806ca4'],rest:['#f7eaed','#cca6ad','#a06d7b']};
  const STORAGE_KEY = 'banke-generic-blank-v1';
  const VIEW_KEY = 'banke-generic-day-v1';
  const fmt = Core.formatTime;
  const copy = data => JSON.parse(JSON.stringify(data));
  const safeDate = date => [date.getFullYear(), String(date.getMonth()+1).padStart(2,'0'), String(date.getDate()).padStart(2,'0')].join('-');
  const thisMonday = () => { const d = new Date(); d.setHours(12,0,0,0); d.setDate(d.getDate() - ((d.getDay()+6)%7)); return safeDate(d); };
  const currentWeek = s => Core.teachingWeek(safeDate(new Date()), s.semesterStart);
  const monday = thisMonday();
  const fresh = () => ({version:1,semesterStart:monday,selectedWeek:1,rangeStart:420,rangeEnd:1380,events:[],completed:[],theme:'light'});
  let state;
  let editingId = null;
  let pendingImport = null;
  let nativeBackupAcknowledged = false;
  let textImportMode = false;
  let damaged = null;
  let storageProblem = false;
  let nativeProblem = '';
  const undoHistory = [];
  let selectedDay = ((new Date().getDay()+6)%7)+1;
  let toastHandle;
  let mobileMode = false;
  let printMode = false;
  let resizeHandle;

  function showFatal(error) {
    try {
      $('criticalError').hidden=false;
      $('criticalErrorText').textContent = (error && (error.message || String(error)) || '未知错误').slice(0,350);
    } catch (_) {}
  }
  window.addEventListener('error',e => showFatal(e.error || e.message));
  window.addEventListener('unhandledrejection',e=>showFatal(e.reason));
  $('reloadBtn').addEventListener('click',()=>location.reload());

  function readState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        let parsed;
        try { parsed = JSON.parse(raw); } catch (error) { damaged=raw; throw error; }
        const issues = Core.validateState(parsed);
        if (issues.length) { damaged=raw; throw new Error(issues[0]); }
        return parsed;
      }
    } catch (error) {
      storageProblem = true;
      nativeProblem = error.message;
      showFatal(new Error('无法读取旧日程，原文件未被覆盖：'+error.message));
    }
    return fresh();
  }
  function persist() {
    if (damaged || nativeProblem) { updateSaveBadge(); return false; }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      storageProblem = false;
    } catch (error) {storageProblem = true; showFatal(error);}
    updateSaveBadge();
    if(!storageProblem)window.dispatchEvent(new Event("banke:changed"));
    return !storageProblem;
  }
  function updateSaveBadge() {
    const title = storageProblem ? '未能保存，请立即导出备份' : '已保存到本机';
    $('saveLabel').textContent=title;
    $('sidebarSave').textContent=title;
    $('storageError').hidden=!storageProblem;
  }
  function notify(text) {
    clearTimeout(toastHandle);
    $('toast').textContent=text;
    $('toast').hidden=false;
    toastHandle=setTimeout(()=>{$('toast').hidden=true},3500);
  }
  function commit(mutator, message) {
    const next = copy(state);
    mutator(next);
    const issues = Core.validateState(next);
    if (issues.length) {notify(issues[0]); return false;}
    undoHistory.push(copy(state));
    if (undoHistory.length>25) undoHistory.shift();
    state=next;
    nativeBackupAcknowledged = false;
    const saved=persist();render();if(message&&saved)notify(message);
    return saved;
  }
  function updateView(mutator) {mutator(state);persist();render();}
  function undo() {if(!undoHistory.length)return;state=undoHistory.pop();persist();render();notify('已撤销上一步');}
  function el(tag, className='', content='') {const result=document.createElement(tag);if(className)result.className=className;if(content!==undefined&&content!=='')result.textContent=content;return result;}
  function modalOpen(id) {const d=$(id);if(!d.open){if(d.showModal)d.showModal();else d.setAttribute('open','');}}
  function modalClose(id) {const d=$(id);if(d.open){if(d.close)d.close();else d.removeAttribute('open');}}
  function hours(min){return (min/60).toFixed(1).replace(/\.0$/,'');}
  function setMetric(id,number,unit){$(id).replaceChildren(document.createTextNode(number+' '),el('em','',unit));}
  function visibleEvents() {return Core.weekEvents(state.events,state.selectedWeek);}
  function completionKey(e){return e.id+':'+state.selectedWeek;}
  function isComplete(e){return state.completed.includes(completionKey(e));}
  function dateLabel(s){const a=s.split('-');return a[1]+'/'+a[2];}
  function setTheme(){document.documentElement.classList.toggle('dark',state.theme==='dark');}
  function applyPalette(node, event){const [bg,border,color]=palettes[event.category]||palettes.work;node.style.setProperty('--event-bg',bg);node.style.setProperty('--event-border',border);node.style.setProperty('--event-color',color);}
  function render(){
    if (!state) return;
    setTheme();
    const dates=Core.weekDates(state.semesterStart,state.selectedWeek);
    const active=visibleEvents();
    const summary=Core.summarize(state.events,state.selectedWeek,state.rangeStart,state.rangeEnd);
    setMetric('plannedHours',hours(summary.plannedMinutes),'小时');
    setMetric('freeHours',hours(summary.freeMinutes),'小时');
    setMetric('eventCount',String(active.length),'项');
    $('weekSelect').value=String(state.selectedWeek);
    $('weekDates').textContent=dateLabel(dates[0])+' — '+dateLabel(dates[6]);
    $('prevWeek').disabled=state.selectedWeek<=1;
    $('nextWeek').disabled=state.selectedWeek>=52;
    $('rangeLabel').firstChild.textContent=fmt(state.rangeStart)+'–'+fmt(state.rangeEnd)+' ';
    const preset=state.rangeStart+','+state.rangeEnd;
    $('rangePreset').value=['420,1380','0,1440','360,720','780,1440','960,1440'].includes(preset)?preset:'custom';
    $('undoButton').disabled=!undoHistory.length;
    const counts=Core.findConflicts(state.events,state.selectedWeek).filter(pair=>pair.start<state.rangeEnd&&pair.end>state.rangeStart);
    $('conflictNotice').hidden=counts.length===0;
    if(counts.length)$('conflictNotice').textContent=counts.length+' 处时间重叠 · 已并排显示，可分别编辑。';
    renderMobileDates(dates);
    renderGrid(active,dates,counts);
    updateSaveBadge();
  }
  function renderMobileDates(dates){
    const tab=$('mobileDayStrip');tab.replaceChildren();
    const today=safeDate(new Date());
    days.forEach((d,index)=>{
      const day=index+1; const selected=selectedDay===day;
      const button=el('button',selected?'selected':'' );button.type='button';if(dates[index]===today)button.classList.add('today-date');
      const title=el('span','',d.slice(1));const num=el('strong','',dates[index].slice(8));
      button.append(title,num);button.setAttribute('aria-label',d+' '+dates[index]);button.setAttribute('aria-pressed',String(selected));
      button.onclick=()=>{selectedDay=day;render();};tab.append(button);
    });
  }
  function renderGrid(active,dates,conflicts){
    const grid=$('calendarGrid'), viewport=$('calendarScroll');
    const top=viewport.scrollTop,left=viewport.scrollLeft;
    grid.replaceChildren();
    mobileMode=window.matchMedia('(max-width: 780px)').matches && !printMode;
    const selected=printMode||!mobileMode?[1,2,3,4,5,6,7]:[selectedDay];
    const corner=el('div','grid-corner','时间');grid.append(corner);
    const today=safeDate(new Date());
    selected.forEach(day=>{
      const hd=el('div','day-header'+(today===dates[day-1]?' today':''));
      hd.append(el('strong','',days[day-1]),el('span','',dateLabel(dates[day-1])));grid.append(hd);
    });
    const rows=(state.rangeEnd-state.rangeStart)/30;
    const total=rows*30;
    const column=el('div','time-column');column.style.height='calc('+rows+' * var(--slot-height))';
    for(let start=state.rangeStart;start<state.rangeEnd;start+=30)column.append(el('div','time-mark'+(start%60===0?' on-hour':''),fmt(start)));
    grid.append(column);
    const conflictsSet=new Set(conflicts.flatMap(item=>[item.a,item.b]));
    selected.forEach(day=>{
      const container=el('div','day-col'+(today===dates[day-1]?' today':''));
      container.style.height='calc('+rows+' * var(--slot-height))';
      for(let t=state.rangeStart;t<state.rangeEnd;t+=30){
        const slot=el('button','slot','＋');slot.type='button';slot.dataset.day=String(day);slot.dataset.time=String(t);
        slot.setAttribute('aria-label',days[day-1]+' '+fmt(t)+' 添加安排');
        slot.onclick=()=>openEditor(null,day,t);container.append(slot);
      }
      const layouts=Core.layoutEvents(active.filter(e=>e.day===day),state.rangeStart,state.rangeEnd);
      layouts.forEach(item=>{
        const event=item.event;
        const card=el('button','event-card'+(item.heightMinutes<22?' tiny':item.heightMinutes<45?' short':'')+(isComplete(event)?' is-complete':'')+(conflictsSet.has(event.id)?' is-conflict':''));
        card.type='button';card.style.top='calc('+(item.topMinutes/30)+' * var(--slot-height) + 1px)';
        card.style.height='max(1px, calc('+(item.heightMinutes/30)+' * var(--slot-height) - 2px))';
        card.style.left='calc('+(item.lane/item.laneCount*100)+'% + 3px)';
        card.style.width='calc('+(100/item.laneCount)+'% - 6px)';
        applyPalette(card,event);
        card.append(el('span','event-time',fmt(event.start)+'–'+fmt(event.end)),el('span','event-title',event.title),el('span','event-place',event.location||categoryName[event.category]));
        card.title=event.title+' · '+days[day-1]+' '+fmt(event.start)+'–'+fmt(event.end)+' · '+event.location;
        card.setAttribute('aria-label',card.title);card.onclick=()=>openEditor(event.id);
        container.append(card);
      });
      grid.append(container);
    });
    const outside=active.filter(e=>e.start<state.rangeStart||e.end>state.rangeEnd);
    $('hiddenCount').textContent=outside.length?outside.length+' 项安排部分在显示范围外':'空白时段可以自由安排';
    viewport.scrollTop=top;viewport.scrollLeft=left;
  }
  function openEditor(id=null, day=1, start=state.rangeStart){
    editingId=id;
    const obj=id?state.events.find(e=>e.id===id):null;
    if(id&&!obj){notify('该安排不存在');return;}
    const event=obj||{title:'',category:'work',day,start,end:Math.min(start+30,1440),location:'',notes:'',weeks:[state.selectedWeek]};
    $('eventForm').reset();
    $('eventTitle').value=event.title;$('eventCategory').value=event.category;$('eventDay').value=event.day;
    $('eventStart').value=fmt(event.start);$('eventEnd').value=fmt(event.end);
    $('eventWeeks').value=Core.formatWeeks(event.weeks);$('eventLocation').value=event.location;$('eventNotes').value=event.notes;
    $('scopeRow').hidden=!obj||event.weeks.length<2||!event.weeks.includes(state.selectedWeek);
    $('eventScope').value='all';$('eventWeeks').disabled=false;
    $('deleteButton').hidden=!obj;$('completeButton').hidden=!obj||!event.weeks.includes(state.selectedWeek);
    if(obj)$('completeButton').textContent=isComplete(obj)?'取消完成':'标记本周完成';
    $('eventDialogTitle').textContent=obj?'编辑安排':'添加安排';
    $('formWarning').hidden=true;$('formError').hidden=true;
    modalOpen('eventDialog');
  }
  const freshId=()=> 'e-'+(window.crypto&&crypto.randomUUID?crypto.randomUUID():(Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)));
  function collect(){
    const start=Core.parseTime($('eventStart').value),end=Core.parseTime($('eventEnd').value);
    if(start===null||end===null)throw Error('时间格式不正确。请填写 09:00、14:30 等时间。');
    const original=editingId?state.events.find(e=>e.id===editingId):null;
    const onlyThis=original&&!$('scopeRow').hidden&&$('eventScope').value==='this';
    const event={id:editingId||freshId(),title:$('eventTitle').value.trim(),day:Number($('eventDay').value),start,end,category:$('eventCategory').value,location:$('eventLocation').value.trim(),notes:$('eventNotes').value.trim(),weeks:onlyThis?[state.selectedWeek]:Core.parseWeeks($('eventWeeks').value),uncertain:false};
    const issues=Core.validateEvent(event);if(issues.length)throw Error(issues.slice(0,2).join(' '));return {event,onlyThis};
  }
  function formConflicts(){
    $('formWarning').hidden=true;
    try{
      const {event}=collect();
      const hits=state.events.filter(item=>item.id!==editingId&&item.day===event.day&&item.start<event.end&&item.end>event.start&&event.weeks.some(week=>item.weeks.includes(week)));
      if(hits.length){$('formWarning').textContent='与 '+hits.slice(0,2).map(e=>e.title+' '+fmt(e.start)+'–'+fmt(e.end)).join('、')+' 时间重叠。仍可保存，日程表会并排显示。';$('formWarning').hidden=false;}
    }catch(_){/* incomplete input */}
  }
  function saveEvent(e){
    e.preventDefault();$('formError').hidden=true;
    try{
      const {event,onlyThis}=collect();
      if(commit(s=>{
        const index=s.events.findIndex(item=>item.id===editingId);
        if(index<0)s.events.push(event);
        else if(onlyThis && s.events[index].weeks.length>1){
          const originalId=s.events[index].id;
          s.events[index].weeks=s.events[index].weeks.filter(week=>week!==s.selectedWeek);
          event.id=freshId();s.events.push(event);
          const prev=originalId+':'+s.selectedWeek;if(s.completed.includes(prev)){s.completed=s.completed.filter(key=>key!==prev);s.completed.push(event.id+':'+s.selectedWeek);}
        }else s.events[index]=event;
      },'安排已保存'))modalClose('eventDialog');
    }catch(error){$('formError').hidden=false;$('formError').textContent=error.message;}
  }
  async function deleteEvent(){
    if(!editingId)return;
    if(!await confirmAction('确定删除这条安排吗？此操作可撤销，并会同步删除到已配对设备。'))return;
    const onlyThis=!$('scopeRow').hidden&&$('eventScope').value==='this';
    const id=editingId;
    if(commit(s=>{
      const match=s.events.find(e=>e.id===id);
      if(onlyThis&&match){match.weeks=match.weeks.filter(w=>w!==s.selectedWeek);}
      if(!onlyThis||!match||!match.weeks.length)s.events=s.events.filter(e=>e.id!==id);
      s.completed=s.completed.filter(key=>onlyThis?key!==id+':'+s.selectedWeek:!key.startsWith(id+':'));
    },'已删除安排，可撤销'))modalClose('eventDialog');
  }
  function completeEvent(){
    const id=editingId;
    const key=id+':'+state.selectedWeek;
    const done=state.completed.includes(key);
    if(commit(s=>{s.completed=done?s.completed.filter(v=>v!==key):s.completed.concat(key);},done?'已取消完成标记':'完成了！'))modalClose('eventDialog');
  }
  function settingsOpen(){
    $('weekOne').value=state.semesterStart;$('settingStart').value=state.rangeStart;$('settingEnd').value=state.rangeEnd;$('settingTheme').value=state.theme;
    $('settingsError').hidden=true;modalOpen('settingsDialog');
  }
  function saveSettings(e){
    e.preventDefault();const candidate=copy(state);
    candidate.semesterStart=$('weekOne').value;candidate.rangeStart=Number($('settingStart').value);candidate.rangeEnd=Number($('settingEnd').value);candidate.theme=$('settingTheme').value;
    const issues=Core.validateState(candidate);
    if(issues.length){$('settingsError').hidden=false;$('settingsError').textContent=issues.slice(0,2).join(' ');return;}
    if(commit(s=>{s.semesterStart=candidate.semesterStart;s.rangeStart=candidate.rangeStart;s.rangeEnd=candidate.rangeEnd;s.theme=candidate.theme;},'设置已保存')){modalClose('settingsDialog');$('calendarScroll').scrollTop=0;}
  }
  function confirmAction(message){
    return new Promise(resolve=>{
      const dialog=$('questionDialog');$('questionText').textContent=message;
      const finish=value=>{dialog.removeEventListener('cancel',cancel);dialog.close();resolve(value);};
      const cancel=e=>{e.preventDefault();finish(false);};
      $('questionNo').onclick=()=>finish(false);$('questionYes').onclick=()=>finish(true);
      dialog.addEventListener('cancel',cancel);dialog.showModal();
    });
  }
  function download(content,type,file){
    if(window.webkit?.messageHandlers?.banke){window.webkit.messageHandlers.banke.postMessage({action:'share',fileName:file,text:content});return true;}

    const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=el('a');a.href=url;a.download=file;
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
    return true;
  }
  function backupString(s=state){return JSON.stringify(s,null,2);}
  function shareTextExport(){
    $('textBackupTitle').textContent='复制完整日程备份';
    $('textBackupHelp').textContent='如果手机应用不支持文件下载，可复制下面的 JSON 文本并保存到笔记或文件。';
    $('textBackupValue').value=backupString();$('applyBackupText').hidden=true;$('textBackupError').hidden=true;
    textImportMode=false;modalOpen('textBackupDialog');
  }
  function exportBackup(){
    const raw=backupString();
    try {
      if (window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.banke) {
        window.webkit.messageHandlers.banke.postMessage({action:'share',fileName:'半刻通用日程备份.json',text:raw});
        return true;
      }
      if (window.BankeDesktop && typeof window.BankeDesktop.saveBackup==='function') {
        const result = JSON.parse(window.BankeDesktop.saveBackup(raw));
        if (!result.ok) {notify(result.error || '备份未保存');return false;}
        return true;
      }
      if(ANDROID){shareTextExport();return false;}
      return download(raw,'application/json;charset=utf-8','半刻通用日程备份-'+safeDate(new Date())+'.json');
    }catch(error){showFatal(error);shareTextExport();return false;}
  }
  function importText(text){
    if(typeof text!=='string'||text.length>4*1024*1024)throw Error('备份过大（最多 4 MB）。');
    const parsed=JSON.parse(text.replace(/^\uFEFF/,''));
    const problems=Core.validateState(parsed);
    if(problems.length)throw Error(problems.slice(0,2).join(' '));
    pendingImport=copy(parsed);
    $('importSummary').textContent='包含 '+pendingImport.events.length+' 项安排，共 '+pendingImport.events.filter(e=>e.day===7).length+' 项周日安排。导入会替换当前全部日程。';
    $('importError').hidden=true;modalClose('textBackupDialog');modalOpen('importDialog');
  }
  async function handleImportFile(e){
    const file=e.target.files&&e.target.files[0];e.target.value='';
    if(!file)return;
    try{if(file.size>4*1024*1024)throw Error('备份超过 4MB。');importText(await file.text());}
    catch(error){notify('导入失败：'+error.message);}
  }
  function safetyBackup(){
    try {const existing=JSON.parse(localStorage.getItem('banke-safety-history')||'[]');existing.unshift({at:new Date().toISOString(),state:copy(state)});localStorage.setItem('banke-safety-history',JSON.stringify(existing.slice(0,5)));return true;}
    catch(e){notify('无法保存操作前的安全副本：'+e.message);return false;}
  }
  function confirmImport(){
    if(!pendingImport||!safetyBackup())return;
    const incoming=copy(pendingImport);
    if(commit(s=>{Object.keys(s).forEach(key=>delete s[key]);Object.assign(s,incoming);},'完整备份已导入；操作前的安全副本已保留')){pendingImport=null;modalClose('importDialog');}
  }
  function csv(){return Core.gridCsv(state);}
  function setWeek(number){if(number<1||number>52)return;updateView(s=>{s.selectedWeek=number;});}
  function clearAll(){
    if(!safetyBackup())return;
    if(commit(s=>{s.events=[];s.completed=[];},'已清空；可从安全副本恢复'))modalClose('clearDialog');
  }
  window.BankeApp=Object.freeze({
    getState:()=>copy(state), notify, confirm:confirmAction,
    hasStorageError:()=>storageProblem||!!damaged||!!nativeProblem,
    isEditing:()=>!!document.querySelector('dialog[open]:not(#syncDialog)'),
    safetyBackup,
    applyShared:value=>{const previous=copy(state);const next={...state,...copy(value)};if(Core.validateState(next).length)return false;state=next;if(!persist()){state=previous;return false;}undoHistory.length=0;render();return true;}
  });
  function start(){
    if(!Core){showFatal(new Error('日程核心未能加载，请检查安装文件是否完整。'));return;}
    state=readState();
    for(let n=1;n<=52;n++){const o=el('option','', '第 '+n+' 周');o.value=n;$('weekSelect').append(o);}
    days.forEach((d,i)=>{const o=el('option','',d);o.value=i+1;$('eventDay').append(o);});
    for(let t=0;t<=1440;t+=30){if(t!==1440){const o=el('option','',fmt(t));o.value=t;$('settingStart').append(o);}if(t!==0){const o=el('option','',fmt(t));o.value=t;$('settingEnd').append(o);}}
    try {const saved=Number(localStorage.getItem(VIEW_KEY)); if(saved>=1&&saved<=7)selectedDay=saved;}catch(_){}
    $('prevWeek').onclick=()=>setWeek(state.selectedWeek-1);
    $('nextWeek').onclick=()=>setWeek(state.selectedWeek+1);
    $('weekSelect').onchange=()=>setWeek(Number($('weekSelect').value));
    $('goToday').onclick=()=>{const n=currentWeek(state);if(n>=1&&n<=52){selectedDay=((new Date().getDay()+6)%7)+1;setWeek(n);}else notify('当前日期超出计划起始周的 52 周；可在设置中更改起始周。');};
    $('rangePreset').onchange=()=>{if($('rangePreset').value==='custom'){settingsOpen();return;}const [a,b]=$('rangePreset').value.split(',').map(Number);updateView(s=>{s.rangeStart=a;s.rangeEnd=b;});$('calendarScroll').scrollTop=0;};
    $('undoButton').onclick=undo;$('addButton').onclick=()=>openEditor(null,selectedDay,Math.min(state.rangeStart,1410));
    $('settingsButton').onclick=settingsOpen;$('settingsForm').onsubmit=saveSettings;$('eventForm').onsubmit=saveEvent;
    $('eventScope').onchange=()=>{$('eventWeeks').disabled=$('eventScope').value==='this';formConflicts();};
    ['eventDay','eventTitle','eventStart','eventEnd','eventWeeks'].forEach(id=>$(id).addEventListener('input',formConflicts));
    $('thisWeekPreset').onclick=()=>{$('eventWeeks').value=String(state.selectedWeek);formConflicts();};
    $('allWeeksPreset').onclick=()=>{$('eventWeeks').value='1-52';formConflicts();};
    $('deleteButton').onclick=deleteEvent;$('completeButton').onclick=completeEvent;
    document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>modalClose(btn.closest('dialog').id)));
    $('exportJson').onclick=()=>{exportBackup();$('menuDetails').open=false;};
    $('exportCsv').onclick=()=>{if(ANDROID){$('textBackupTitle').textContent='CSV 时间表';$('textBackupValue').value=csv();$('applyBackupText').hidden=true;modalOpen('textBackupDialog');return;}download(csv(),'text/csv;charset=utf-8','半刻通用-第'+state.selectedWeek+'周.csv');$('menuDetails').open=false;};
    $('importJson').onclick=()=>{$('menuDetails').open=false;if(ANDROID)$('pasteImport').click();else $('importFile').click();};
    $('pasteImport').onclick=()=>{$('menuDetails').open=false;textImportMode=true;$('textBackupValue').value='';$('textBackupTitle').textContent='粘贴 JSON 备份';$('textBackupHelp').textContent='将另一台设备导出的 JSON 全部粘贴进来，确认后导入。';$('applyBackupText').hidden=false;$('textBackupError').hidden=true;modalOpen('textBackupDialog');};
    $('restoreSafety').onclick=()=>{try{const all=JSON.parse(localStorage.getItem('banke-safety-history')||'[]');if(!all.length){notify('还没有操作前的安全副本');return;}importText(JSON.stringify(all[0].state));}catch(e){notify(e.message);}};
    $('textBackupValue').addEventListener('input',()=>{$('textBackupError').hidden=true;});
    $('copyBackupText').onclick=async()=>{try{const v=$('textBackupValue');v.focus();v.select();if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(v.value);nativeBackupAcknowledged=true;notify('已复制 JSON 文本');}else{const copied=document.execCommand('copy');if(copied){nativeBackupAcknowledged=true;notify('已复制 JSON 文本');}else{notify('请长按文字并选择全选、复制，然后保存。');}}}catch(error){notify('请长按文本全选并复制。');}};
    $('applyBackupText').onclick=()=>{try{importText($('textBackupValue').value);}catch(e){$('textBackupError').textContent=e.message;$('textBackupError').hidden=false;}};
    $('importFile').onchange=handleImportFile;$('confirmImport').onclick=confirmImport;
    $('clearBtn').onclick=()=>{$('menuDetails').open=false;modalOpen('clearDialog');};$('confirmClear').onclick=clearAll;
    $('printBtn').onclick=()=>{$('menuDetails').open=false;window.print();};
    document.addEventListener('click',e=>{if(!$('menuDetails').contains(e.target))$('menuDetails').open=false;});
    document.addEventListener('keydown',e=>{
      const typing=/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!typing&&!document.querySelector('dialog[open]')){e.preventDefault();undo();}
      if(e.target.classList.contains('slot')&&['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){
        const day=Number(e.target.dataset.day),minute=Number(e.target.dataset.time);
        const nd=day+(e.key==='ArrowLeft'?-1:e.key==='ArrowRight'?1:0), nt=minute+(e.key==='ArrowUp'?-30:e.key==='ArrowDown'?30:0);
        const next=document.querySelector('.slot[data-day="'+nd+'"][data-time="'+nt+'"]');if(next){e.preventDefault();next.focus();}
      }
    });
    window.addEventListener('resize',()=>{clearTimeout(resizeHandle);resizeHandle=setTimeout(()=>render(),120);});
    window.addEventListener('storage',e=>{if(e.key===STORAGE_KEY&&e.newValue){try{const incoming=JSON.parse(e.newValue);if(!Core.validateState(incoming).length){state=incoming;undoHistory.length=0;render();notify('已读取另一窗口的更新');}}catch(_){}}});
    window.addEventListener('beforeprint',()=>{printMode=true;render();});window.addEventListener('afterprint',()=>{printMode=false;render();});
    window.addEventListener('pagehide',()=>{try{localStorage.setItem(VIEW_KEY,selectedDay);}catch(_){}});
    window.addEventListener('banke:native-save-error',e=>{storageProblem=true;updateSaveBadge();showFatal(new Error(e.detail||'保存到设备失败'));});
    const m=document.querySelector('meta[name="theme-color"]');if(m&&state.theme==='dark')m.content='#1e2a2b';
    persist();render();
    if(window.webkit?.messageHandlers?.banke){window.webkit.messageHandlers.banke.postMessage({action:"ready",eventCount:state.events.length,columns:document.querySelectorAll(".day-header").length});}
    if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost')){
      navigator.serviceWorker.register('sw.js').catch(()=>{});
    }
  }
  start();
})();
