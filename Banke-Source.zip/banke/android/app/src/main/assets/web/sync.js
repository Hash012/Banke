/* LAN synchronization controller. Tokens/baselines never enter schedule exports. */
(()=>{
 'use strict';const $=id=>document.getElementById(id),M=window.BankeSyncModel,A=window.BankeApp;
 if(!A||!M)return;
 const KEY='banke-generic-sync-v2';let config=null,busy=false,lastError='',pending=null,host=false;
 try{config=JSON.parse(localStorage.getItem(KEY)||'null');}catch(_){config=null;}
 if(config&&(!config.url||!config.token||config.version!==2))config=null;
 try{
  const fragment=new URLSearchParams(location.hash.slice(1)),token=fragment.get('host');
  if(token&&/^[a-f0-9]{64}$/.test(token)&&location.hostname==='127.0.0.1'){
   config={version:2,url:location.origin,token,host:true,room:config?.room||'',base:config?.base||null};
   history.replaceState(null,'',location.pathname);writeConfig();
  }
 }catch(e){A.notify(e.message);}
 host=!!config?.host;
 function writeConfig(){localStorage.setItem(KEY,JSON.stringify(config));}
 function status(text,kind='neutral'){$('syncStatus').textContent=text;$('syncBadge').textContent=kind==='ok'?'已同步':kind==='error'?'同步暂停':config?'同步中':'未配对';$('syncStatus').dataset.kind=kind;}
 function stateValid(value){return value&&window.PlannerCore.validateState({...A.getState(),...value}).length===0;}
 async function request(url,path,data,token){
  const target=M.privateURL(url)+path;
  const headers={'Content-Type':'application/json'};if(token)headers.Authorization='Bearer '+token;
  if(window.BankeTransport&&typeof window.BankeTransport.request==='function')return window.BankeTransport.request(target,data,token);
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
   const response=await fetch(target,{method:data===undefined?'GET':'POST',headers,body:data===undefined?undefined:JSON.stringify(data),signal:controller.signal,cache:'no-store',credentials:'omit',redirect:'error'});
   const text=await response.text();if(text.length>4*1024*1024)throw Error('服务器回复过大');
   let result;try{result=JSON.parse(text);}catch(_){throw Error('电脑回复不是有效数据；请核对地址和端口');}
   if(!response.ok||result.ok===false)throw Error(result.error||'电脑返回错误 '+response.status);
   return result;
  }finally{clearTimeout(timer);}
 }
 function open(){
  $('syncAddress').value=config?.url||((['http:','https:'].includes(location.protocol)&&/^(10\.|192\.168\.|172\.)/.test(location.hostname))?location.origin:'');
  $('syncName').value=localStorage.getItem('banke-device-label')||(/Android/.test(navigator.userAgent)?'我的安卓手机':/iPhone|iPad/.test(navigator.userAgent)?'我的苹果手机':'我的设备');
  $('syncHostPanel').hidden=!host;$('syncClientPanel').hidden=host;$('syncConnected').hidden=!config;
  if(!$('syncDialog').open)$('syncDialog').showModal();if(host)refreshHost();
 }
 async function refreshHost(){if(!host||!config)return;try{const v=await request(config.url,'/api/admin/status',undefined,config.token);renderHost(v);}catch(e){status(e.message,'error');}}
 function renderHost(v){
  $('hostAddresses').textContent=v.addresses?.join('\n')||'未检测到私有 IPv4，请连接 Wi-Fi';
  $('hostCode').textContent=v.code||'尚未生成';
  $('hostState').textContent=(v.enabled?'局域网同步已开启':'局域网同步未开启')+' · 已配对 '+(v.deviceCount||0)+' 台设备';
  $('hostEnable').textContent=v.enabled?'重新开启 / 生成配对码':'开启局域网同步';
 }
 async function hostAction(path){try{const v=await request(config.url,path,{},config.token);renderHost(v);}catch(e){status(e.message,'error');}}
 async function pair(){
  if(busy)return;busy=true;$('syncPair').disabled=true;
  try{
   const url=M.privateURL($('syncAddress').value),code=$('syncCode').value.trim(),name=$('syncName').value.trim()||'我的设备';
   if(!/^\d{6}$/.test(code))throw Error('请输入电脑上显示的六位配对码');
   if(config)throw Error('已配对的设备请先断开；修改 IP 请使用“更新地址”');
   status('正在核对配对码…');const result=await request(url,'/api/pair',{code,name});
   if(!/^[a-f0-9]{64}$/.test(result.token)||typeof result.room!=='string')throw Error('电脑返回了无效的配对数据');
   if(!A.safetyBackup())throw Error('无法保存配对前的本机安全副本；本机安排未改动');
   config={version:2,url,token:result.token,room:result.room,base:null,host:false};writeConfig();localStorage.setItem('banke-device-label',name);
   $('syncConnected').hidden=false;$('syncCode').value='';status('配对成功，关闭此窗口后开始同步');
  }catch(e){status(e.message,'error');}finally{busy=false;$('syncPair').disabled=false;}
 }
 async function applyResult(result,sent){
  if(!stateValid(result.shared)||typeof result.room!=='string')throw Error('未应用电脑返回的无效日程');
  const next=M.rebase(sent,M.shared(A.getState()),result.shared);
  if(!stateValid(next))throw Error('合并后数据无效，本机原数据已保留');
  if(!M.equal(M.shared(A.getState()),next)&&!A.applyShared(next))throw Error('本机存储失败，未确认同步');
  config.room=result.room;config.base=result.shared;writeConfig();
  const stillDirty=!M.equal(M.shared(A.getState()),result.shared);
  status(stillDirty?'本机有新修改，下一轮继续同步':'已同步 · '+new Date().toLocaleTimeString(),stillDirty?'neutral':'ok');
  if(result.conflicts?.length){A.notify(result.conflicts.join('；'));$('syncConflicts').textContent=result.conflicts.join('\n');$('syncConflicts').hidden=false;}
  lastError='';
 }
 async function tick(manual=false){
  if(!config||busy||A.hasStorageError()||document.hidden)return;
  // The synchronization dialog may remain open for status; never update an open editor/import form.
  if(A.isEditing())return;
  if(pending){const p=pending;pending=null;try{await applyResult(p.result,p.sent);}catch(e){status(e.message,'error');}return;}
  busy=true;
  try{
   const sent=M.shared(A.getState());
   const result=await request(config.url,'/api/sync',{room:config.room||'',base:config.base,current:sent},config.token);
   if(A.isEditing()){pending={result,sent};return;}
   await applyResult(result,sent);
  }catch(e){
   const text=e.name==='AbortError'?'连接超时；修改已保存在本机，连接恢复后重试':e.message||'无法连接电脑';
   lastError=text;status(text+' · 本机安排保留','error');if(manual)A.notify(text);
  }finally{busy=false;}
 }
 $('syncButton').onclick=open;$('syncPair').onclick=pair;$('syncNow').onclick=()=>tick(true);
 $('syncDisconnect').onclick=()=>{if(busy){A.notify('正在同步，请稍候');return;}if(!A.safetyBackup()){status('安全副本保存失败，未断开','error');return;}config=null;pending=null;localStorage.removeItem(KEY);host=false;$('syncConnected').hidden=true;$('syncHostPanel').hidden=true;$('syncClientPanel').hidden=false;status('已断开，本机安排保留');};
 $('syncUpdateAddress').onclick=async()=>{if(!config||busy)return;busy=true;try{const url=M.privateURL($('syncAddress').value);const result=await request(url,'/api/state',undefined,config.token);if(result.room!==config.room)throw Error('这不是原来的日程空间，未修改地址');config.url=url;writeConfig();status('地址已更新');}catch(e){status(e.message,'error');}finally{busy=false;}};
 $('hostEnable').onclick=()=>hostAction('/api/admin/enable');$('hostPair').onclick=()=>hostAction('/api/admin/pair');$('hostDisable').onclick=()=>hostAction('/api/admin/disable');
 $('hostRevoke').onclick=async()=>{if(await A.confirm('撤销所有手机的配对？本机日程保留。'))hostAction('/api/admin/revoke');};
 document.querySelectorAll('#syncDialog [data-sync-close]').forEach(b=>b.onclick=()=>{$('syncDialog').close();setTimeout(tick,20);});
 window.addEventListener('banke:changed',()=>setTimeout(tick,300));window.addEventListener('online',()=>tick());document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick();});
 window.addEventListener('banke:active',()=>tick());
 setInterval(()=>tick(),3000);setInterval(()=>{if(host&&$('syncDialog').open)refreshHost()},5000);
 status(config?'等待连接电脑':'尚未配对 · 日程只保存在本机');setTimeout(tick,100);
 window.BankeSync={tick,open};
})();
