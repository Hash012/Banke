#!/usr/bin/env python3
"""Package actual files, never fabricate absent platform binaries.
The source ZIP is intentionally separate from private signing identities.
"""
from pathlib import Path
import argparse, hashlib, shutil, zipfile, sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from privacy_check import audit
STAMP=(2026,1,1,0,0,0)
def digest(data):return hashlib.sha256(data).hexdigest()
def zipped(path,entries):
    """entries: (archive name, data bytes, POSIX mode)"""
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data,mode in sorted(entries):
            if name.startswith('/') or '..' in Path(name).parts:raise ValueError('Unsafe ZIP path')
            info=zipfile.ZipInfo(name,STAMP);info.create_system=3;info.external_attr=(0o100000|mode)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

def small_package(out,name,binary,inside):
    entries=[(inside,binary.read_bytes(),0o755 if inside.endswith('.exe') else 0o644)]
    for f in ['README.md','LICENSE','SECURITY.md','third_party/NOTICE.md','third_party/GO-LICENSE.txt','third_party/GO-PATENTS.txt']:
        if (ROOT/f).is_file():entries.append((f,(ROOT/f).read_bytes(),0o644))
    for doc in sorted((ROOT/'docs').glob('*.md')):entries.append(('docs/'+doc.name,doc.read_bytes(),0o644))
    sums=''.join(f'{digest(data)}  {n}\n' for n,data,mode in entries)
    entries.append(('SHA256SUMS.txt',sums.encode(),0o644));path=out/name;zipped(path,entries);return path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=ROOT/'dist');p.add_argument('--source-only',action='store_true');p.add_argument('--windows',type=Path);p.add_argument('--android',type=Path);p.add_argument('--mac-dir',type=Path);a=p.parse_args()
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    files=audit(ROOT);source=out/'Banke-Source.zip'
    # Never include the output directory, even when the caller selected a custom one.
    if out==ROOT:raise ValueError('Choose an output directory different from the source root')
    if out.is_relative_to(ROOT):files=[f for f in files if not f.resolve().is_relative_to(out)]
    entries=[('banke/'+f.relative_to(ROOT).as_posix(),f.read_bytes(),0o755 if f.suffix in {'.py','.sh'} else 0o644) for f in files]
    sums=''.join(f'{digest(data)}  {name.removeprefix("banke/")}\n' for name,data,_ in entries)
    entries.append(('banke/SOURCE_SHA256SUMS.txt',sums.encode(),0o644));zipped(source,entries);products=[source]
    if not a.source_only:
        if a.windows:products.append(small_package(out,'Banke-Windows.zip',a.windows,'Banke-Windows.exe'))
        if a.android:products.append(small_package(out,'Banke-Android.zip',a.android,'Banke-Android.apk'))
        if a.mac_dir:
            for arch,label in [('amd64','intel'),('arm64','arm64')]:
                original=a.mac_dir/f'Banke-macOS-{arch}.zip'
                if not original.is_file():raise ValueError(f'Missing actual Mac build: {original}')
                path=out/f'Banke-Mac-{label}.zip';shutil.copy2(original,path);products.append(path)
    sums=''.join(f'{digest(f.read_bytes())}  {f.name}\n' for f in products)
    (out/'SHA256SUMS.txt').write_text(sums,encoding='utf-8');shutil.copy2(ROOT/'README.md',out/'README-Banke.md')
    if not a.source_only:
        bundled=[(f.name,f.read_bytes(),0o644) for f in products]+[('README.md',(ROOT/'README.md').read_bytes(),0o644),('SHA256SUMS.txt',sums.encode(),0o644)]
        allzip=out/'Banke-All.zip';zipped(allzip,bundled)
        with (out/'SHA256SUMS.txt').open('a',encoding='utf-8') as f:f.write(f'{digest(allzip.read_bytes())}  {allzip.name}\n')
        products.append(allzip)
    for f in products:print(f'{f.name}: {f.stat().st_size} bytes, SHA256 {digest(f.read_bytes())}')
if __name__=='__main__':main()
