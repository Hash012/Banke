#!/usr/bin/env python3
"""Build a real macOS .app using public source; Developer ID signing is separate.
On macOS use Apple's clang. Linux cross-build needs clang + ld64.lld in PATH.
The tiny text stub below declares libSystem's public ABI, not Apple SDK contents.
"""
from pathlib import Path
import argparse,os,subprocess,shutil,plistlib,platform,zipfile,struct
ROOT=Path(__file__).resolve().parents[1]
def run(args,**kw):subprocess.run(args,check=True,cwd=ROOT,**kw)
def build(arch,out):
 folder=out/f'Banke-macOS-{arch}';app=folder/'Banke.app';mac=app/'Contents/MacOS';res=app/'Contents/Resources'
 mac.mkdir(parents=True,exist_ok=True);res.mkdir(parents=True,exist_ok=True)
 env={**os.environ,'GOOS':'darwin','GOARCH':arch,'CGO_ENABLED':'0'}
 run(['go','build','-trimpath','-ldflags=-s -w','-o',str(res/'banke-server'),'./cmd/server'],env=env)
 cpu='arm64' if arch=='arm64' else 'x86_64';source=ROOT/'cmd/mac/main.c'
 if platform.system()=='Darwin':
  run(['clang','-arch',cpu,'-mmacosx-version-min=13.0','-O2',str(source),'-o',str(mac/'Banke')])
  run(['codesign','--force','--sign','-',str(res/'banke-server')])
 else:
  temp=ROOT/'build/mac-cross';temp.mkdir(parents=True,exist_ok=True)
  symbols=['alarm','getpid','mkdtemp','dlopen','dlsym','pipe','fork','dup2','close','kill','execv','read','snprintf','strlen','strcmp','strchr','getenv','_exit','open','poll','memcpy','memset','__stack_chk_fail','__stack_chk_guard']
  (temp/'libSystem.tbd').write_text('--- !tapi-tbd\ntbd-version: 4\ntargets: [ x86_64-macos, arm64-macos ]\ninstall-name: /usr/lib/libSystem.B.dylib\nexports:\n  - targets: [ x86_64-macos, arm64-macos ]\n    symbols: [ dyld_stub_binder, '+', '.join('_'+s for s in symbols)+' ]\n...\n')
  obj=temp/f'Banke-{arch}.o'
  run(['clang','-target',f'{cpu}-apple-macos13','-O2','-fno-stack-protector','-c',str(source),'-o',str(obj)])
  # Swift's Linux LLD fork may reject every object carrying platform metadata.
  # Drop that optional object metadata; the final linker command still explicitly
  # sets the architecture and minimum macOS version. No instructions are altered.
  raw=bytearray(obj.read_bytes());count=struct.unpack_from('<I',raw,16)[0];pos=32;commands=[]
  for _ in range(count):
   kind,size=struct.unpack_from('<II',raw,pos)
   if kind not in (0x32,0x24,0x25,0x2f,0x30):commands.append(raw[pos:pos+size])
   pos+=size
  load=b''.join(commands);raw[32:pos]=load+bytes(pos-32-len(load));struct.pack_into('<II',raw,16,len(commands),len(load));obj.write_bytes(raw)
  run(['ld64.lld' ,'-arch',cpu,'-platform_version','macos','13.0','13.0','-o',str(mac/'Banke'),str(obj),'-L'+str(temp),'-lSystem','-adhoc_codesign'])
 png=(ROOT/'web/icons/icon-512.png').read_bytes();icon=b'ic09'+struct.pack('>I',8+len(png))+png;(res/'icon.icns').write_bytes(b'icns'+struct.pack('>I',8+len(icon))+icon)
 meta={'CFBundleName':'Banke','CFBundleDisplayName':'半刻通用版','CFBundleIdentifier':'org.banke.generic.sync.mac','CFBundleVersion':'11','CFBundleShortVersionString':'1.1.0','CFBundleExecutable':'Banke','CFBundlePackageType':'APPL','CFBundleIconFile':'icon.icns','LSMinimumSystemVersion':'13.0','NSHighResolutionCapable':True,'NSLocalNetworkUsageDescription':'在你开启后，与同一 Wi-Fi 的已配对手机同步日程。','NSAppTransportSecurity':{'NSAllowsLocalNetworking':True}}
 (app/'Contents/Info.plist').write_bytes(plistlib.dumps(meta));(app/'Contents/PkgInfo').write_bytes(b'APPL????')
 for p in [mac/'Banke',res/'banke-server']:p.chmod(0o755)
 if platform.system()=='Darwin':run(['codesign','--force','--sign','-','--deep',str(app)])
 for name in ['README.md','LICENSE','SECURITY.md','third_party/NOTICE.md','third_party/GO-LICENSE.txt','third_party/GO-PATENTS.txt']:
  item=ROOT/name
  if item.is_file():
   dest=folder/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(item,dest)
 for doc in sorted((ROOT/'docs').glob('*.md')):
  dest=folder/'docs'/doc.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(doc,dest)
 # source file modes survive unzip on macOS.
 archive=out/f'Banke-macOS-{arch}.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(folder))
 print(archive)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--arch',choices=['amd64','arm64','both'],default='both');p.add_argument('--out',default=str(ROOT/'dist'));a=p.parse_args();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
 for arch in ['amd64','arm64'] if a.arch=='both' else [a.arch]:build(arch,out)
