#!/usr/bin/env python3
"""Sign a zipaligned, unsigned APK using a stable private PEM identity."""
from pathlib import Path
import argparse, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from apk_sign import sign, verify, positions, MAGIC
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('input', type=Path);p.add_argument('output', type=Path)
p.add_argument('--key', required=True);p.add_argument('--cert', required=True)
a=p.parse_args()
raw=a.input.read_bytes();cd,_=positions(raw)
if raw[cd-16:cd]==MAGIC:raise SystemExit('Expected an UNSIGNED APK, refusing nested signing blocks')
signed=sign(raw,a.key,a.cert);print(verify(signed))
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(signed)
