#!/usr/bin/env python3
"""Copy canonical web assets into native SDK projects. No personal data is read."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
def prepare():
 for target in [ROOT/'android/app/src/main/assets/web',ROOT/'apple/BankeGenericApp/web']:
  if target.exists(): shutil.rmtree(target)
  shutil.copytree(ROOT/'web',target)
 icon=ROOT/'android/app/src/main/res/drawable/icon.png';icon.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'web/icons/icon-192.png',icon)
 print('Native assets updated from web/')
if __name__=='__main__':prepare()
