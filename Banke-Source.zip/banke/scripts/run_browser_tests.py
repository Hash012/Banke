#!/usr/bin/env python3
"""Start an isolated temporary server and test UI + real HTTP synchronization."""
from pathlib import Path
import argparse, json, os, selectors, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bridged',action='store_true',help='Model browser transport for restricted environments; not a native network-stack test')
a=p.parse_args()
with tempfile.TemporaryDirectory(prefix='banke-ui-') as folder:
    binary=Path(folder)/('server.exe' if os.name=='nt' else 'server')
    subprocess.run(['go','build','-trimpath','-o',str(binary),'./cmd/server'],cwd=ROOT,check=True)
    with open(Path(folder)/'server.log','w+') as errors:
        proc=subprocess.Popen([str(binary),'--data-dir',str(Path(folder)/'data'),'--port','0','--lan-port','0','--no-open'],cwd=ROOT,stdout=subprocess.PIPE,stderr=errors,text=True)
        try:
            # Portable bounded read without exposing the local admin token in logs.
            import queue,threading
            q=queue.Queue()
            threading.Thread(target=lambda:q.put(proc.stdout.readline()),daemon=True).start()
            line=q.get(timeout=20)
            if not line:raise RuntimeError('Test server did not become ready')
            ready=json.loads(line);env={**os.environ,'BANKE_TEST_URL':ready['url'],'BANKE_BRIDGED_TEST':'1' if a.bridged else '0'}
            subprocess.run([sys.executable,str(ROOT/'tests/browser_smoke.py')],cwd=ROOT,env=env,check=True,timeout=120)
        finally:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            proc.stdout.close()
