#!/usr/bin/env python3
"""Internal integrity checks, NOT a substitute for official apksigner or a device."""
from pathlib import Path
import argparse, hashlib, json, struct, sys, zipfile, zlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from apk_sign import verify
p=argparse.ArgumentParser(description=__doc__);p.add_argument('apk',type=Path);p.add_argument('--compare-assets',action='store_true');a=p.parse_args()
report=verify(a.apk.read_bytes())
with zipfile.ZipFile(a.apk) as z:
    assert z.testzip() is None,'ZIP CRC failed'
    for name in ['AndroidManifest.xml','classes.dex','resources.arsc','assets/web/index.html']:
        assert name in z.namelist(),f'Missing {name}'
    dex=z.read('classes.dex')
    assert dex[:4]==b'dex\n','Invalid DEX'
    assert struct.unpack_from('<I',dex,8)[0]==zlib.adler32(dex[12:])&0xffffffff,'DEX checksum'
    assert dex[12:32]==hashlib.sha1(dex[32:]).digest(),'DEX signature'
    if a.compare_assets:
        for f in sorted((ROOT/'web').rglob('*')):
            if f.is_file():assert z.read('assets/web/'+f.relative_to(ROOT/'web').as_posix())==f.read_bytes(),f'Asset mismatch: {f.name}'
    report['entries']=len(z.namelist())
report.update({'apkSha256':hashlib.sha256(a.apk.read_bytes()).hexdigest(),'dexIntegrity':True,'officialAndroidVerification':'not performed by this script'})
print(json.dumps(report,indent=2))
