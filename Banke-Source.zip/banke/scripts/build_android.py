#!/usr/bin/env python3
"""Build the preview APK entirely from public source, without downloading an SDK.
For an Android Studio build use android/ (Java) and the official Android SDK.
"""
import xml.etree.ElementTree as ET
from pathlib import Path
import sys,io,zipfile,struct,hashlib,json,argparse,shutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from android_host import CLASSES
from dex_builder import build
from android_binary import manifest,resources
from apk_sign import generate,sign,verify

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',default=str(ROOT/'dist/Banke-Android-1.1.0.apk'));p.add_argument('--key',required=True);p.add_argument('--cert',required=True);p.add_argument('--generate-key',action='store_true');args=p.parse_args()
 if args.generate_key:generate(args.key,args.cert)
 dex=build(CLASSES);assert dex[:8]==b'dex\n035\0';assert hashlib.sha1(dex[32:]).digest()==dex[12:32]
 root=ET.fromstring((ROOT/'android/app/src/main/AndroidManifest.xml').read_text());ns='http://schemas.android.com/apk/res/android'
 root.set('package','org.banke.generic.sync');root.set('{'+ns+'}versionCode','11');root.set('{'+ns+'}versionName','1.1.0')
 root.insert(0,ET.Element('uses-sdk',{'{'+ns+'}minSdkVersion':'26','{'+ns+'}targetSdkVersion':'34'}))
 values={'AndroidManifest.xml':manifest(ET.tostring(root,encoding='unicode')),'classes.dex':dex,'resources.arsc':resources('org.banke.generic.sync'),'res/drawable/icon.png':(ROOT/'web/icons/icon-192.png').read_bytes()}
 for f in sorted((ROOT/'web').rglob('*')):
  if f.is_file():values['assets/web/'+f.relative_to(ROOT/'web').as_posix()]=f.read_bytes()
 output=io.BytesIO()
 with zipfile.ZipFile(output,'w') as z:
  for name,data in values.items():
   info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_STORED
   padding=(- (output.tell()+30+len(name.encode())+4))%4;info.extra=struct.pack('<HH',0xd935,padding)+bytes(padding)
   z.writestr(info,data)
 signed=sign(output.getvalue(),args.key,args.cert);report=verify(signed)
 with zipfile.ZipFile(io.BytesIO(signed)) as z:assert z.testzip() is None
 dest=Path(args.out);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(signed)
 print(json.dumps({'file':str(dest),'bytes':len(signed),'sha256':hashlib.sha256(signed).hexdigest(),'verification':report},indent=2))
if __name__=='__main__':main()
