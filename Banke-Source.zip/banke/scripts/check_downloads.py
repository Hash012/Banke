#!/usr/bin/env python3
"""Verify SHA256SUMS plus ZIP CRC. No network, extraction, or code execution."""
from pathlib import Path
import argparse, hashlib, re, sys, zipfile

def verify(manifest):
    root = manifest.resolve().parent
    checked = []
    for n, line in enumerate(manifest.read_text(encoding='utf-8-sig').splitlines(), 1):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        m = re.fullmatch(r'([a-fA-F0-9]{64}) [ *](.+)', line)
        if not m:
            raise ValueError(f'Invalid checksum format, line {n}')
        expected, name = m.groups()
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError(f'Missing or unsafe file: {name}')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected.lower():
            raise ValueError(f'SHA-256 mismatch: {name}')
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                bad = z.testzip()
                if bad:
                    raise ValueError(f'Corrupt ZIP member: {name}:{bad}')
        checked.append(name)
        print(f'OK  {name}')
    if not checked:
        raise ValueError('No checksums found')
    return checked

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('manifest', type=Path)
    try:
        names = verify(p.parse_args().manifest)
        print(f'Verified {len(names)} files. Integrity is not publisher identity.')
    except (ValueError, OSError, zipfile.BadZipFile) as e:
        sys.exit(str(e))
