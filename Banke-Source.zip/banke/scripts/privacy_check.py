#!/usr/bin/env python3
"""Audit the selected public source tree for accidental private data and secrets."""
from pathlib import Path
import argparse, re, sys
ROOT=Path(__file__).resolve().parents[1]
SKIP={'build','dist','.git','.gradle','DerivedData','node_modules','__pycache__','xcuserdata','release'}
# Public snippets in documentation may mention file names, never actual private keys.
FORBIDDEN_EXT={'.pem','.jks','.keystore','.p12','.mobileprovision','.pyc','.exe','.apk','.ipa','.dmg','.o','.a','.so','.node'}
def source_files(root):
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if any(part in SKIP for part in rel.parts) or path.name in {'.DS_Store','SOURCE_SHA256SUMS.txt','SHA256SUMS.txt'}:continue
        if path.is_symlink():raise ValueError(f'Public source must not contain symlinks: {rel}')
        if path.is_file():yield path

def audit(root):
    failures=[];files=list(source_files(root))
    required=['README.md','LICENSE','SECURITY.md','go.mod','web/index.html','.github/workflows/build.yml','docs/TESTING.md','scripts/package_release.py']
    for name in required:
        if not(root/name).is_file():failures.append('Missing '+name)
    for f in files:
        rel=f.relative_to(root)
        if f.suffix.lower() in FORBIDDEN_EXT or any(t in rel.parts for t in ['private','secrets']):failures.append('Sensitive/binary path: '+str(rel))
        if f.name in {'schedule-sync.json','sync-config.json','server-info.json','local.properties'}:failures.append('Private runtime file: '+str(rel))
        if f.suffix.lower() in {'.png','.icns','.ico'}:continue
        try:text=f.read_text('utf-8')
        except UnicodeDecodeError:failures.append('Unexpected binary: '+str(rel));continue
        if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE' + r' KEY-----',text):failures.append('Private key: '+str(rel))
        if re.search(r'gh[pousr]_[A-Za-z0-9]{30,}',text):failures.append('GitHub credential: '+str(rel))
        if re.search(r'art_v2_[A-Za-z0-9_]{15,}',text):failures.append('Repository credential: '+str(rel))
    if failures:raise ValueError('\n'.join(failures))
    return files
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',nargs='?',type=Path,default=ROOT)
    try:print(f'Public-source audit passed: {len(audit(p.parse_args().root))} files. Review remains necessary before publication.')
    except ValueError as e:sys.exit(str(e))
