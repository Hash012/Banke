# Changelog

## 1.1.0 — 2026-10-19 (preview)

- Added an actual, opt-in local-network coordinator and client synchronization.
- Added empty-first pairing, three-way merge, conflict copies, retry handling and offline foreground reconnect.
- Added durable server storage, last-valid backups, corrupted-file protection and OS cross-process locks.
- Kept Windows as a native normal Win32 window, with taskbar entry; removed the wallpaper embedding architecture.
- Added a macOS AppKit/WKWebView host for Intel and Apple Silicon plus an embedded Go service.
- Added a clean Android host, complete Java source and source-built SDK-free preview packaging tools; no reused opaque DEX.
- Updated iOS Xcode project with restricted native LAN transport and local-network declarations; real-device signing remains the distributor's responsibility.
- Added public README, MIT license, build/test/security/protocol docs, release workflow, checksums and privacy checks.

## 1.0.0

Generic blank local-only planner. Did not implement automatic device synchronization. Apple deliverables were web/source projects rather than signed installable applications.
