"""Readable Dalvik assembly source for the tiny Android host.

This is NOT copied/opaque classes.dex. build_android.py assembles these methods
from symbolic instructions. Equivalent Android Studio Java sources live in android/.
Only APIs available on Android 8+ are referenced; no SDK/dependency downloads are
needed for the preview build. CI additionally verifies it with official apksigner.
"""
ACT='Lorg/banke/generic/sync/MainActivity;'
GUARD='Lorg/banke/generic/sync/LocalOnlyClient;'
A='Landroid/app/Activity;';B='Landroid/os/Bundle;';C='Landroid/content/Context;'
W='Landroid/webkit/WebView;';S='Landroid/webkit/WebSettings;'
WC='Landroid/webkit/WebViewClient;';CC='Landroid/webkit/WebChromeClient;'
V='Landroid/view/View;';J='Ljava/lang/String;'
def method(cls,name,ret='V',params=()):return (cls,name,ret,tuple(params))
def invoke(kind,cls,name,ret,params,regs):return ('invoke-'+kind,method(cls,name,ret,params),regs)
def constructor(cls,superclass):
 return {'ref':method(cls,'<init>'), 'access':0x10001,'registers':1,'ins':1,'direct':True,'code':[invoke('direct',superclass,'<init>','V',(),[0]),('return-void',)]}
code=[invoke('super',A,'onCreate','V',(B,),[6,7]),('const',2,1),invoke('virtual',A,'requestWindowFeature','Z',('I',),[6,2]),('new-instance',0,W),invoke('direct',W,'<init>','V',(C,),[0,6]),invoke('virtual',W,'getSettings',S,(),[0]),('move-result-object',1)]
for name,val in [('setJavaScriptEnabled',1),('setDomStorageEnabled',1),('setAllowFileAccess',0),('setAllowContentAccess',0),('setAllowFileAccessFromFileURLs',0),('setAllowUniversalAccessFromFileURLs',1)]:
 code += [('const',2,val),invoke('virtual',S,name,'V',('Z',),[1,2])]
code += [invoke('virtual',S,'getUserAgentString',J,(),[1]),('move-result-object',3),('const-string',4,' BankeGenericAndroid/1.1'),invoke('virtual',J,'concat',J,(J,),[3,4]),('move-result-object',3),invoke('virtual',S,'setUserAgentString','V',(J,),[1,3]),('new-instance',3,GUARD),invoke('direct',GUARD,'<init>','V',(),[3]),invoke('virtual',W,'setWebViewClient','V',(WC,),[0,3]),('new-instance',3,CC),invoke('direct',CC,'<init>','V',(),[3]),invoke('virtual',W,'setWebChromeClient','V',(CC,),[0,3]),('const',2,0xfff6f8f7),invoke('virtual',W,'setBackgroundColor','V',('I',),[0,2]),invoke('virtual',A,'setContentView','V',(V,),[6,0]),('const-string',3,'file:///android_asset/web/index.html'),invoke('virtual',W,'loadUrl','V',(J,),[0,3]),('return-void',)]
CLASSES=[
 {'type':ACT,'super':A,'methods':[constructor(ACT,A),{'ref':method(ACT,'onCreate','V',(B,)),'access':4,'registers':8,'ins':2,'direct':False,'code':code}]},
 {'type':GUARD,'super':WC,'methods':[constructor(GUARD,WC),{'ref':method(GUARD,'shouldOverrideUrlLoading','Z',(W,J)),'access':1,'registers':5,'ins':3,'direct':False,'code':[('const-string',0,'file:///android_asset/web/'),invoke('virtual',J,'startsWith','Z',(J,),[4,0]),('move-result',0),('xor-int/lit8',0,0,1),('return',0)]}]}
]
