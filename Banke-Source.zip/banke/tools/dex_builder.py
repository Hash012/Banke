"""Minimal deterministic DEX 035 assembler for android_host.py's documented subset.

File format: https://source.android.com/docs/core/runtime/dex-format
Unsupported instructions fail closed. No opaque executable bytes or private data.
"""
import hashlib,struct,zlib
P=lambda *n:struct.pack('<'+'I'*len(n),*n)
H=lambda *n:struct.pack('<'+'H'*len(n),*n)
def uleb(n):
 out=bytearray()
 while True:
  x=n&127;n>>=7;out.append(x|(128 if n else 0))
  if not n:return bytes(out)
def short(t):return 'L' if t[0] in '[L' else t

def build(classes):
 methods=set();types=set();texts=set()
 for c in classes:
  types|={c['type'],c['super']}
  for m in c['methods']:
   methods.add(m['ref'])
   for ins in m['code']:
    if ins[0].startswith('invoke-'):methods.add(ins[1])
    elif ins[0]=='new-instance':types.add(ins[2])
    elif ins[0]=='const-string':texts.add(ins[2])
 protos=set()
 for cls,name,ret,args in methods:types.add(cls);types.add(ret);types.update(args);texts.add(name);protos.add((ret,args));texts.add(short(ret)+''.join(map(short,args)))
 texts|=types;strings=sorted(texts);si={s:i for i,s in enumerate(strings)}
 types=sorted(types,key=lambda t:si[t]);ti={t:i for i,t in enumerate(types)}
 protos=sorted(protos,key=lambda p:(ti[p[0]],tuple(ti[t] for t in p[1])));pi={p:i for i,p in enumerate(protos)}
 methods=sorted(methods,key=lambda m:(ti[m[0]],si[m[1]],pi[(m[2],m[3])]))
 mi={m:i for i,m in enumerate(methods)};classes=sorted(classes,key=lambda c:ti[c['type']])
 ns,nt,np,nm,nc=map(len,[strings,types,protos,methods,classes])
 so=112;to=so+4*ns;po=to+4*nt;mo=po+12*np;co=mo+8*nm;do=co+32*nc
 buf=bytearray(do);sections=[]
 def align():
  while len(buf)%4:buf.append(0)
 def record(kind,count,offset):
  if count:sections.append((kind,count,offset))
 def put(data):offset=len(buf);buf.extend(data);return offset
 str_offsets=[]
 for text in strings:
  # This assembler's symbolic names and literals are ASCII; general modified UTF8
  # is deliberately rejected rather than generating subtly invalid DEX strings.
  if not text.isascii():raise ValueError('DEX literal must be ASCII')
  str_offsets.append(put(uleb(len(text))+text.encode()+b'\0'))
 record(0x2002,ns,str_offsets[0]);align()
 param_offsets={};first_param=0
 for ret,args in protos:
  if args and args not in param_offsets:
   align();offset=put(P(len(args))+H(*[ti[t] for t in args]));param_offsets[args]=offset;first_param=first_param or offset
 record(0x1001,len(param_offsets),first_param);align()
 code_offsets={};first_code=len(buf);count=0
 for c in classes:
  for m in c['methods']:
   words=[];outs=0
   for i in m['code']:
    op=i[0]
    if op.startswith('invoke-'):
     opcode={'invoke-virtual':0x6e,'invoke-super':0x6f,'invoke-direct':0x70,'invoke-static':0x71}[op]
     regs=i[2];outs=max(outs,len(regs));assert len(regs)<=5 and all(0<=r<16 for r in regs)
     rr=list(regs)+[0]*(5-len(regs));words.extend([opcode|(len(regs)<<12)|(rr[4]<<8),mi[i[1]],rr[0]|rr[1]<<4|rr[2]<<8|rr[3]<<12])
    elif op=='const':words.extend([0x14|(i[1]<<8),i[2]&65535,(i[2]>>16)&65535])
    elif op=='const-string':words.extend([0x1a|(i[1]<<8),si[i[2]]])
    elif op=='new-instance':words.extend([0x22|(i[1]<<8),ti[i[2]]])
    elif op in ['move-result','move-result-object','return']:words.append({'move-result':0x0a,'move-result-object':0x0c,'return':0x0f}[op]|i[1]<<8)
    elif op=='return-void':words.append(0x0e)
    elif op=='xor-int/lit8':words.extend([0xdf|(i[1]<<8),i[2]|(i[3]&255)<<8])
    else:raise ValueError('Unsupported opcode '+op)
   align();code_offsets[m['ref']]=put(H(m['registers'],m['ins'],outs,0)+P(0,len(words))+H(*words));count+=1
 record(0x2001,count,first_code)
 class_data={};first_data=len(buf)
 for c in classes:
  direct=sorted([m for m in c['methods'] if m['direct']],key=lambda m:mi[m['ref']]);virtual=sorted([m for m in c['methods'] if not m['direct']],key=lambda m:mi[m['ref']])
  data=bytearray(uleb(0)+uleb(0)+uleb(len(direct))+uleb(len(virtual)))
  for group in [direct,virtual]:
   last=0
   for m in group:
    idx=mi[m['ref']];data+=uleb(idx-last)+uleb(m['access'])+uleb(code_offsets[m['ref']]);last=idx
  class_data[c['type']]=put(data)
 record(0x2000,nc,first_data);align();map_offset=len(buf)
 for kind,n,off in [(0,1,0),(1,ns,so),(2,nt,to),(3,np,po),(5,nm,mo),(6,nc,co),(0x1000,1,map_offset)]:record(kind,n,off)
 entries=sorted(sections,key=lambda e:e[2]);put(P(len(entries))+b''.join(H(kind,0)+P(n,off) for kind,n,off in entries))
 for idx,off in enumerate(str_offsets):buf[so+idx*4:so+(idx+1)*4]=P(off)
 for idx,t in enumerate(types):buf[to+idx*4:to+(idx+1)*4]=P(si[t])
 for idx,(ret,args) in enumerate(protos):buf[po+idx*12:po+(idx+1)*12]=P(si[short(ret)+''.join(map(short,args))],ti[ret],param_offsets.get(args,0))
 for idx,(cls,name,ret,args) in enumerate(methods):buf[mo+idx*8:mo+(idx+1)*8]=H(ti[cls],pi[(ret,args)])+P(si[name])
 for idx,c in enumerate(classes):buf[co+idx*32:co+(idx+1)*32]=P(ti[c['type']],0x11,ti[c['super']],0,0xffffffff,0,class_data[c['type']],0)
 buf[:8]=b'dex\n035\0';buf[32:112]=P(len(buf),112,0x12345678,0,0,map_offset,ns,so,nt,to,np,po,0,0,nm,mo,nc,co,len(buf)-do,do)
 buf[12:32]=hashlib.sha1(buf[32:]).digest();buf[8:12]=P(zlib.adler32(buf[12:])&0xffffffff)
 return bytes(buf)
