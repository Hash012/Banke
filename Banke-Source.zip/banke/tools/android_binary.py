"""Small Android binary XML/resource writer. Input is the public manifest XML.
All resource data is regenerated from text and the project's own PNG icon.
"""
import struct,xml.etree.ElementTree as ET
P=lambda *n:struct.pack('<'+'I'*len(n),*n)
H=lambda *n:struct.pack('<'+'H'*len(n),*n)
NS='http://schemas.android.com/apk/res/android';NONE=0xffffffff
ATTR={'label':0x01010001,'icon':0x01010002,'name':0x01010003,'exported':0x01010010,'minSdkVersion':0x0101020c,'versionCode':0x0101021b,'versionName':0x0101021c,'windowSoftInputMode':0x0101022b,'targetSdkVersion':0x01010270,'allowBackup':0x01010280,'usesCleartextTraffic':0x010104ec}
def chunk(t,header,payload):return H(t,len(header)+8)+P(8+len(header)+len(payload))+header+payload
def pool(strings):
 data=bytearray();offs=[]
 for s in strings:
  encoded=s.encode('utf-16-le');n=len(encoded)//2;assert n<32768;offs.append(len(data));data+=H(n)+encoded+H(0)
 while len(data)%4:data.append(0)
 start=28+4*len(strings)
 return chunk(1,P(len(strings),0,0,start,0),P(*offs)+data)
def manifest(xml):
 root=ET.fromstring(xml);strings=sorted(ATTR,key=lambda k:ATTR[k])+['android',NS]
 def add(t):
  if t not in strings:strings.append(t)
 for node in root.iter():
  add(node.tag)
  for k,v in node.attrib.items():add(k.split('}')[-1]);add(v)
 si={s:i for i,s in enumerate(strings)};out=bytearray(pool(strings))
 out+=chunk(0x180,b'',P(*[ATTR.get(s,0) for s in strings[:len(ATTR)]]))
 def node(t,payload):return chunk(t,P(1,NONE),payload)
 out+=node(0x100,P(si['android'],si[NS]))
 def emit(el):
  nonlocal out
  attrs=[]
  for k,v in el.attrib.items():
   android=k.startswith('{'+NS+'}');name=k.split('}')[-1];namespace=si[NS] if android else NONE;kind=3;value=si[v]
   if android:
    if name in ['minSdkVersion','targetSdkVersion','versionCode']:kind=0x10;value=int(v)
    elif name in ['allowBackup','exported','usesCleartextTraffic']:kind=0x12;value=0xffffffff if v=='true' else 0
    elif name=='windowSoftInputMode':kind=0x11;value=0x10
    elif name=='icon':kind=1;value=0x7f010000
   attrs.append((ATTR.get(name,0) if android else 0,P(namespace,si[name],si[v])+H(8)+bytes([0,kind])+P(value)))
  attrs.sort(key=lambda a:a[0]);extension=P(NONE,si[el.tag])+H(20,20,len(attrs),0,0,0)
  out+=node(0x102,extension+b''.join(a[1] for a in attrs))
  for c in el:emit(c)
  out+=node(0x103,P(NONE,si[el.tag]))
 emit(root);out+=node(0x101,P(si['android'],si[NS]));return chunk(3,b'',out)
def resources(package):
 global_strings=pool(['res/drawable/icon.png']);types=pool(['drawable']);keys=pool(['icon'])
 spec=chunk(0x202,bytes([1,0])+H(0)+P(1),P(0x40000000))
 config=P(64)+bytes(60)
 header=bytes([1,0])+H(0)+P(1,88)+config
 typ=chunk(0x201,header,P(0)+H(8,0)+P(0)+H(8)+bytes([0,3])+P(0))
 name=package.encode('utf-16-le').ljust(256,b'\0')
 pkg_header=P(0x7f)+name+P(288,1,288+len(types),1,0)
 pkg=chunk(0x200,pkg_header,types+keys+spec+typ)
 return chunk(2,P(1),global_strings+pkg)
