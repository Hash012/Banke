"""APK Signature Scheme v2 (RSA/SHA256), plus independent verification.
Format: https://source.android.com/docs/security/features/apksigning/v2
No legacy host binary is used. Keep signing keys OUT of the public repository.
"""
import hashlib,struct,datetime
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
P=lambda v:struct.pack('<I',v)
Q=lambda v:struct.pack('<Q',v)
LP=lambda b:P(len(b))+b
MAGIC=b'APK Sig Block 42';V2=0x7109871a;ALG=0x0103

def generate(keyfile,certfile):
 keyfile=Path(keyfile);certfile=Path(certfile)
 if keyfile.exists() or certfile.exists():raise ValueError('Refusing to overwrite a signing identity')
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Banke Generic preview signing')])
 now=datetime.datetime.now(datetime.timezone.utc)
 cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256())
 keyfile.parent.mkdir(parents=True,exist_ok=True)
 keyfile.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));keyfile.chmod(0o600)
 certfile.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

def digest(sections):
 parts=[]
 for data in sections:
  for off in range(0,len(data),1024*1024):
   b=data[off:off+1024*1024];parts.append(hashlib.sha256(b'\xa5'+P(len(b))+b).digest())
 return hashlib.sha256(b'\x5a'+P(len(parts))+b''.join(parts)).digest()

def positions(b):
 eocd=b.rfind(b'PK\x05\x06');assert eocd>=0 and eocd+22+struct.unpack_from('<H',b,eocd+20)[0]==len(b),'Malformed ZIP EOCD'
 cd=struct.unpack_from('<I',b,eocd+16)[0];assert b[cd:cd+4]==b'PK\x01\x02';return cd,eocd

def sign(raw,keyfile,certfile):
 key=serialization.load_pem_private_key(Path(keyfile).read_bytes(),password=None);cert=x509.load_pem_x509_certificate(Path(certfile).read_bytes())
 cd,eocd=positions(raw);d=digest([raw[:cd],raw[cd:eocd],raw[eocd:]])
 cert_der=cert.public_bytes(serialization.Encoding.DER)
 signed_data=LP(LP(P(ALG)+LP(d)))+LP(LP(cert_der))+LP(b'')
 signature=key.sign(signed_data,padding.PKCS1v15(),hashes.SHA256())
 public=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
 signer=LP(signed_data)+LP(LP(P(ALG)+LP(signature)))+LP(public)
 value=LP(LP(signer));pair=Q(4+len(value))+P(V2)+value
 length=len(pair)+24;block=Q(length)+pair+Q(length)+MAGIC
 e=bytearray(raw[eocd:]);struct.pack_into('<I',e,16,cd+len(block))
 return raw[:cd]+block+raw[cd:eocd]+e

def lp(data,pos=0):
 assert pos+4<=len(data);n=struct.unpack_from('<I',data,pos)[0];assert pos+4+n<=len(data);return data[pos+4:pos+4+n],pos+4+n

def verify(raw):
 cd,eocd=positions(raw);assert raw[cd-16:cd]==MAGIC,'Missing v2 signature'
 length=struct.unpack_from('<Q',raw,cd-24)[0];start=cd-length-8;assert start>=0 and struct.unpack_from('<Q',raw,start)[0]==length
 pos=start+8;value=None
 while pos<cd-24:
  n=struct.unpack_from('<Q',raw,pos)[0];tag=struct.unpack_from('<I',raw,pos+8)[0]
  if tag==V2:value=raw[pos+12:pos+8+n]
  pos+=8+n
 assert value is not None
 signers,_=lp(value);signer,_=lp(signers);signed,p=lp(signer);signatures,p=lp(signer,p);public,_=lp(signer,p)
 sigrec,_=lp(signatures);assert struct.unpack_from('<I',sigrec)[0]==ALG;signature,_=lp(sigrec,4)
 digests,p=lp(signed);certs,p=lp(signed,p);certder,_=lp(certs);cert=x509.load_der_x509_certificate(certder)
 assert cert.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)==public
 cert.public_key().verify(signature,signed,padding.PKCS1v15(),hashes.SHA256())
 drec,_=lp(digests);assert struct.unpack_from('<I',drec)[0]==ALG;d,_=lp(drec,4)
 e=bytearray(raw[eocd:]);struct.pack_into('<I',e,16,start)
 assert d==digest([raw[:start],raw[cd:eocd],bytes(e)]),'APK content digest mismatch'
 return {'scheme':'v2','algorithm':'RSA-PKCS1-SHA256','certificateSha256':hashlib.sha256(certder).hexdigest(),'contentDigest':d.hex()}
