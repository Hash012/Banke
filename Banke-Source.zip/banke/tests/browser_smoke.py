"""UI + real local HTTP service tests. No user schedules or credentials are fixtures.

Default: native browser HTTP navigation on a developer/CI machine.
BANKE_BRIDGED_TEST=1: render in-memory, forward requests to the SAME local service
through a test binding. This is for restricted browser environments; it does not
claim to verify the OS/WebView network stack or native localStorage implementation.
"""
import os,json,time,urllib.request,urllib.error
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
url=os.getenv('BANKE_TEST_URL') or json.loads(Path('/tmp/banke-server-ready.json').read_text())['url']
bridged=os.getenv('BANKE_BRIDGED_TEST')=='1';offline={};counter=0

def load(page,host=False,saved=None):
 global counter
 if not bridged:
  page.goto(url if host else url.split('#')[0]);return
 counter+=1;key=counter;offline[key]=False
 def proxy(target,data=None,token=None):
  if offline[key]:raise RuntimeError('测试断网：暂时无法连接电脑')
  headers={'Content-Type':'application/json'}
  if token:headers['Authorization']='Bearer '+token
  payload=None if data is None else json.dumps(data).encode()
  req=urllib.request.Request(target,data=payload,headers=headers)
  try:
   with urllib.request.urlopen(req,timeout=8) as r:return json.loads(r.read())
  except urllib.error.HTTPError as e:
   obj=json.loads(e.read());raise RuntimeError(obj.get('error',str(e)))
 page.expose_function('testTransport'+str(key),proxy)
 initial=saved or {}
 if host:initial['banke-generic-sync-v2']=json.dumps({'version':2,'url':url.split('/#')[0],'token':url.split('#host=')[1],'host':True,'room':'','base':None})
 import re
 html=(ROOT/'web/index.html').read_text();html=re.sub(r'<script\b[^>]*>.*?</script>','',html,flags=re.S)
 html=re.sub(r'<link\b[^>]*>','',html);html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
 page.set_content(html)
 page.add_style_tag(content=(ROOT/'web/styles.css').read_text())
 page.evaluate('''([values,key])=>{const m=new Map(Object.entries(values));Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}});window.__testStorageSnapshot=()=>Object.fromEntries(m);window.BankeTransport={request:(url,data,token)=>window['testTransport'+key](url,data??null,token??null)};}''',[initial,key])
 for name in ['core.js','app.js','sync-model.js','sync.js']:page.add_script_tag(content=(ROOT/'web'/name).read_text())
 page.test_key=key

def set_offline(context,page,value):
 if bridged:offline[page.test_key]=value
 else:context.set_offline(value)

with sync_playwright() as p:
 args={'headless':True,'args':['--no-sandbox']}
 if Path('/usr/bin/chromium').exists():args['executable_path']='/usr/bin/chromium'
 browser=p.chromium.launch(**args)
 context=browser.new_context(viewport={'width':1366,'height':950})
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 print('UI: initial desktop',flush=True);load(page,True);page.wait_for_selector('.day-header');page.wait_for_timeout(700)
 assert page.locator('.day-header').count()==7
 assert page.evaluate('BankeApp.getState().events.length')==0
 page.screenshot(path=str(ROOT/'docs/screenshots/desktop.png'),full_page=True)
 page.locator('#addButton').click();page.fill('#eventTitle','测试任务');page.fill('#eventStart','09:15');page.fill('#eventEnd','10:05');page.select_option('#eventDay','7');page.locator('#eventForm button[type=submit]').click();page.wait_for_timeout(900)
 assert page.evaluate('BankeApp.getState().events[0].start')==555
 assert page.evaluate('BankeApp.getState().events[0].day')==7
 assert page.locator('#criticalError').is_hidden()
 print('UI: enable host sharing',flush=True);page.locator('#syncButton').click();page.locator('#hostEnable').click();page.wait_for_function('document.getElementById("hostCode").textContent.match(/^\\d{6}$/)')
 code=page.locator('#hostCode').inner_text();page.locator('#syncDialog [data-sync-close]').first.click()
 print('UI: host sharing ready',flush=True);mobile_context=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 phone=mobile_context.new_page();phone.on('pageerror',lambda e:errors.append(str(e)))
 load(phone);phone.wait_for_selector('.day-header')
 phone.screenshot(path=str(ROOT/'docs/screenshots/mobile.png'),full_page=True)
 assert phone.evaluate('BankeApp.getState().events.length')==0
 print('UI: pair phone',flush=True);phone.click('#syncButton');phone.fill('#syncAddress',url.split('/#')[0]);phone.fill('#syncCode',code);phone.fill('#syncName','测试手机');phone.click('#syncPair')
 phone.wait_for_function('document.getElementById("syncConnected").hidden===false')
 phone.locator('#syncDialog [data-sync-close]').first.click();phone.wait_for_function('BankeApp.getState().events.length===1',timeout=10000)
 assert phone.evaluate('BankeApp.getState().events[0].title')=='测试任务'
 print('UI: phone to desktop',flush=True);phone.click('#addButton');phone.fill('#eventTitle','手机新增');phone.fill('#eventStart','12:30');phone.fill('#eventEnd','13:00');phone.locator('#eventForm button[type=submit]').click()
 page.wait_for_function('BankeApp.getState().events.length===2',timeout=10000)
 print('UI: offline edits',flush=True);set_offline(mobile_context,phone,True)
 phone.click('#addButton');phone.fill('#eventTitle','离线安排');phone.locator('#eventForm button[type=submit]').click()
 assert phone.evaluate('BankeApp.getState().events.length')==3
 phone.wait_for_timeout(3500);assert phone.evaluate('BankeApp.getState().events.length')==3
 set_offline(mobile_context,phone,False)
 page.wait_for_function('BankeApp.getState().events.length===3',timeout=12000)
 print('UI: storage reload',flush=True)
 if bridged:
  storage=phone.evaluate('__testStorageSnapshot()');phone.close();phone=mobile_context.new_page();load(phone,saved=storage)
 else:phone.reload()
 phone.wait_for_function('BankeApp.getState().events.length===3')
 assert not errors,errors
 print(json.dumps({'mode':'memory UI + real HTTP via test bridge' if bridged else 'browser HTTP','desktop_columns':7,'empty_initial_state':True,'minute_precision':True,'desktop_to_phone':True,'phone_to_desktop':True,'offline_reconnect':True,'page_state_reload':True,'page_errors':errors},indent=2))
 browser.close()
