//go:build windows

// 半刻通用版 · Windows 原生 Win32 GUI
// 不使用浏览器、Electron 或桌面背景层。数据结构与通用版 JSON 相同。
package main

import (
	banke "banke.local/planner"
	model "banke.local/planner/internal/planner"
	"banke.local/planner/internal/syncserver"
	"encoding/json"
	"errors"

	"flag"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"
)

const (
	WS_OVERLAPPEDWINDOW          = 0x00CF0000
	WS_VISIBLE                   = 0x10000000
	WS_CHILD                     = 0x40000000
	WS_BORDER                    = 0x00800000
	WS_TABSTOP                   = 0x00010000
	WS_VSCROLL                   = 0x00200000
	ES_AUTOHSCROLL               = 0x0080
	CBS_DROPDOWNLIST             = 3
	LVS_REPORT                   = 1
	LVS_SINGLESEL                = 4
	LVS_SHOWSELALWAYS            = 8
	LVS_EX_GRIDLINES             = 1
	LVS_EX_FULLROWSELECT         = 0x20
	LVS_EX_DOUBLEBUFFER          = 0x10000
	WM_CREATE                    = 0x0001
	WM_DESTROY                   = 0x0002
	WM_SIZE                      = 0x0005
	WM_COMMAND                   = 0x0111
	WM_NOTIFY                    = 0x004E
	WM_SETFONT                   = 0x0030
	WM_GETTEXT                   = 0x000D
	WM_GETTEXTLENGTH             = 0x000E
	WM_SETTEXT                   = 0x000C
	LVM_FIRST                    = 0x1000
	LVM_INSERTCOLUMNW            = LVM_FIRST + 97
	LVM_INSERTITEMW              = LVM_FIRST + 77
	LVM_SETITEMTEXTW             = LVM_FIRST + 116
	LVM_DELETEALLITEMS           = LVM_FIRST + 9
	LVM_SETEXTENDEDLISTVIEWSTYLE = LVM_FIRST + 54
	LVCF_FMT                     = 1
	LVCF_WIDTH                   = 2
	LVCF_TEXT                    = 4
	LVIF_TEXT                    = 1
	CB_ADDSTRING                 = 0x0143
	CB_SETCURSEL                 = 0x014E
	CB_GETCURSEL                 = 0x0147
	BM_GETCHECK                  = 0x00F0
	MB_OK                        = 0
	MB_ICONERROR                 = 0x10
	MB_ICONINFORMATION           = 0x40
	MB_YESNO                     = 4
	MB_ICONQUESTION              = 0x20
	IDYES                        = 6
	OFN_OVERWRITEPROMPT          = 2
	OFN_PATHMUSTEXIST            = 0x800
	OFN_FILEMUSTEXIST            = 0x1000
	OFN_EXPLORER                 = 0x80000
	ID_PREV                      = 201
	ID_NEXT                      = 202
	ID_TODAY                     = 203
	ID_RANGE                     = 204
	ID_EXPORT                    = 205
	ID_IMPORT                    = 206
	ID_NEW                       = 207
	ID_TITLE                     = 301
	ID_DAY                       = 302
	ID_CATEGORY                  = 303
	ID_START                     = 304
	ID_END                       = 305
	ID_WEEKS                     = 306
	ID_LOCATION                  = 307
	ID_NOTES                     = 308
	ID_SAVE                      = 309
	ID_DELETE                    = 310
	ID_ONLYTHIS                  = 311
)

var (
	user32                = syscall.NewLazyDLL("user32.dll")
	gdi32                 = syscall.NewLazyDLL("gdi32.dll")
	comctl32              = syscall.NewLazyDLL("comctl32.dll")
	comdlg32              = syscall.NewLazyDLL("comdlg32.dll")
	kernel32              = syscall.NewLazyDLL("kernel32.dll")
	createWindow          = user32.NewProc("CreateWindowExW")
	sendMessage           = user32.NewProc("SendMessageW")
	moveWindow            = user32.NewProc("MoveWindow")
	messageBox            = user32.NewProc("MessageBoxW")
	defWindowProc         = user32.NewProc("DefWindowProcW")
	mainWindow            uintptr
	list                  uintptr
	weekLabel             uintptr
	controls              = map[int]uintptr{}
	editorID              string
	state                 PlannerState
	rows                  []int
	lastWidth, lastHeight int
	storageDamaged        bool
)
var labels = []string{"周一", "周二", "周三", "周四", "周五", "周六", "周日"}
var cats = []string{"工作", "学习", "课程", "生活", "休息"}
var catCodes = []string{"work", "study", "course", "life", "rest"}

type Event = model.Event
type PlannerState = model.State

var scheduleStore *syncserver.Store
var syncService *syncserver.Service
var loadedSnapshot model.Shared
var lastEditorSignature string
var dataDir string
var smokeTest bool

const ID_SYNC = 208
const ID_STOP_SYNC = 209
const ID_PLAN_START = 210
const ID_SET_PLAN_START = 211
const ID_COMPLETE = 312

var subtitleWindow uintptr

const WM_TIMER = 0x0113

type point struct{ X, Y int32 }
type nmhdr struct {
	HwndFrom, IDFrom uintptr
	Code             uint32
	_                uint32
}
type nmitemactivate struct {
	Hdr                            nmhdr
	IItem, ISubItem                int32
	UNewState, UOldState, UChanged uint32
	PtAction                       point
	LParam                         uintptr
	UKeyFlags                      uint32
	_                              uint32
}
type lvc struct {
	Mask       uint32
	Fmt        int32
	Cx         int32
	PszText    *uint16
	CchTextMax int32
	ISubItem   int32
	IImage     int32
	IOrder     int32
	CxMin      int32
	CxDefault  int32
	CxIdeal    int32
}
type lvi struct {
	Mask             uint32
	IItem, ISubItem  int32
	State, StateMask uint32
	PszText          *uint16
	CchTextMax       int32
	IImage           int32
	LParam           uintptr
	IIndent          int32
	IGroupId         int32
	CColumns         uint32
	PuColumns        uintptr
	PiColFmt         uintptr
	IGroup           int32
}
type wndclass struct {
	Style                                    uint32
	LpfnWndProc                              uintptr
	CbClsExtra, CbWndExtra                   int32
	HInstance, HIcon, HCursor, HbrBackground uintptr
	LpszMenuName, LpszClassName              *uint16
}
type msg struct {
	Hwnd           uintptr
	Message        uint32
	_              uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	LPrivate       uint32
}
type iccex struct {
	Size    uint32
	Classes uint32
}
type openFile struct {
	LStructSize     uint32
	_               uint32
	HwndOwner       uintptr
	HInstance       uintptr
	Filter          *uint16
	CustomFilter    *uint16
	MaxCustomFilter uint32
	FilterIndex     uint32
	File            *uint16
	MaxFile         uint32
	FileTitle       *uint16
	MaxFileTitle    uint32
	InitialDir      *uint16
	Title           *uint16
	Flags           uint32
	FileOffset      uint16
	FileExtension   uint16
	DefExt          *uint16
	CustData        uintptr
	Hook            uintptr
	TemplateName    *uint16
	Reserved        uintptr
	Reserved2       uint32
	FlagsEx         uint32
}

func ptr(s string) *uint16                              { return syscall.StringToUTF16Ptr(s) }
func call(p *syscall.LazyProc, args ...uintptr) uintptr { r, _, _ := p.Call(args...); return r }
func send(h uintptr, message uint32, w, l uintptr) uintptr {
	return call(sendMessage, h, uintptr(message), w, l)
}
func show(title, text string, flags uint32) uintptr {
	return call(messageBox, mainWindow, uintptr(unsafe.Pointer(ptr(text))), uintptr(unsafe.Pointer(ptr(title))), uintptr(flags))
}
func getText(hwnd uintptr) string {
	if hwnd == 0 {
		return ""
	}
	n := int(send(hwnd, WM_GETTEXTLENGTH, 0, 0)) + 1
	if n > 4096 {
		n = 4096
	}
	buf := make([]uint16, n)
	send(hwnd, WM_GETTEXT, uintptr(n), uintptr(unsafe.Pointer(&buf[0])))
	return syscall.UTF16ToString(buf)
}
func setText(hwnd uintptr, text string) {
	if hwnd != 0 {
		send(hwnd, WM_SETTEXT, 0, uintptr(unsafe.Pointer(ptr(text))))
	}
}
func create(class, text string, style uint32, id int, x, y, w, h int) uintptr {
	instance := call(kernel32.NewProc("GetModuleHandleW"), 0)
	result := call(createWindow, 0, uintptr(unsafe.Pointer(ptr(class))), uintptr(unsafe.Pointer(ptr(text))), uintptr(style), uintptr(x), uintptr(y), uintptr(w), uintptr(h), mainWindow, uintptr(id), instance, 0)
	if result != 0 {
		font := call(gdi32.NewProc("GetStockObject"), 17)
		send(result, WM_SETFONT, font, 1)
	}
	if id > 0 {
		controls[id] = result
	}
	return result
}
func appFile() string               { return scheduleStore.Path() }
func validate(s PlannerState) error { return model.Validate(s) }
func load() {
	root, err := os.UserConfigDir()
	if err != nil {
		panic(err)
	}
	if dataDir == "" {
		dataDir = filepath.Join(root, "BankeGenericSync")
	}
	scheduleStore, err = syncserver.OpenStore(dataDir)
	if err != nil {
		show("无法打开日程", err.Error()+"\n请保留原存档与 .previous 文件。", MB_OK|MB_ICONERROR)
		os.Exit(1)
	}
	state = scheduleStore.Get().State
	loadedSnapshot = model.Snapshot(state)
	syncService = syncserver.New(scheduleStore, banke.Web())
	// Ordinary native controls stay usable even if the optional local web admin cannot start.
	if err = syncService.StartLocal(0); err != nil {
		show("同步管理提示", err.Error(), MB_OK|MB_ICONERROR)
	}
}
func save() error {
	updated, notices, err := scheduleStore.Local(loadedSnapshot, state)
	if err != nil {
		return err
	}
	state = updated
	loadedSnapshot = model.Snapshot(state)
	if len(notices) > 0 {
		show("同步冲突已保留", strings.Join(notices, "\n"), MB_OK|MB_ICONINFORMATION)
	}
	return nil
}
func editorSignature() string {
	values := []string{}
	for _, id := range []int{ID_TITLE, ID_START, ID_END, ID_WEEKS, ID_LOCATION, ID_NOTES} {
		values = append(values, getText(controls[id]))
	}
	values = append(values, fmt.Sprint(send(controls[ID_ONLYTHIS], BM_GETCHECK, 0, 0)))
	values = append(values, fmt.Sprint(send(controls[ID_DAY], CB_GETCURSEL, 0, 0)), fmt.Sprint(send(controls[ID_CATEGORY], CB_GETCURSEL, 0, 0)))
	return strings.Join(values, "\x1f")
}
func refreshFromSync() {
	if controls[ID_TITLE] == 0 || editorSignature() != lastEditorSignature {
		return
	}
	current := scheduleStore.Get().State
	if !model.Equal(model.Snapshot(current), loadedSnapshot) {
		state = model.Apply(state, model.Snapshot(current))
		loadedSnapshot = model.Snapshot(state)
		refreshGrid()
		if editorID != "" {
			if e := findEvent(editorID); e != nil {
				updateEditor(e, e.Day, e.Start)
			} else {
				updateEditor(nil, 1, state.RangeStart)
			}
		}
	}
}
func showPairing() {
	if err := syncService.EnableLAN(47833); err != nil {
		show("无法开启手机同步", err.Error()+"\n请关闭另一份半刻同步服务后重试。", MB_OK|MB_ICONERROR)
		return
	}
	code, _ := syncService.PairCode()
	status := syncService.Status()
	addresses := status["addresses"].([]string)
	message := "手机连接同一 Wi-Fi，在同步页填写一个 Wi-Fi 地址：\n" + strings.Join(addresses, "\n") + "\n\n配对码：" + code + "  （2 分钟有效，使用一次）\n\n配对后，两端编辑自动同步。电脑应保持软件运行，手机需要在前台。\n仅在可信私人 Wi-Fi 使用：默认 HTTP 未加密。\n\n停止共享请点击主窗口的“关闭同步”。"
	if len(addresses) == 0 {
		message = "没有检测到私有 IPv4 网络，请先连接 Wi-Fi。\n\n" + message
	}
	show("手机同步 · 半刻通用版", message, MB_OK|MB_ICONINFORMATION)
}
func formatTime(n int) string { return fmt.Sprintf("%02d:%02d", n/60, n%60) }
func parseTime(raw string) (int, error) {
	parts := strings.Split(strings.TrimSpace(strings.ReplaceAll(raw, "：", ":")), ":")
	if len(parts) != 2 {
		return 0, errors.New("请填写 HH:MM")
	}
	h, er1 := strconv.Atoi(parts[0])
	m, er2 := strconv.Atoi(parts[1])
	if er1 != nil || er2 != nil || h < 0 || h > 24 || m < 0 || m > 59 || (h == 24 && m != 0) {
		return 0, errors.New("时间格式无效")
	}
	return h*60 + m, nil
}
func weekText(weeks []int) string {
	parts := make([]string, len(weeks))
	for i, n := range weeks {
		parts[i] = strconv.Itoa(n)
	}
	return strings.Join(parts, ",")
}
func parseWeeks(input string) ([]int, error) {
	text := strings.ReplaceAll(strings.ReplaceAll(strings.ReplaceAll(input, "，", ","), "～", "-"), "至", "-")
	found := map[int]bool{}
	for _, section := range strings.Split(text, ",") {
		section = strings.TrimSpace(section)
		v := strings.Split(section, "-")
		if len(v) < 1 || len(v) > 2 || section == "" {
			return nil, errors.New("周次格式如 1-4,6-12")
		}
		a, err := strconv.Atoi(strings.TrimSpace(v[0]))
		if err != nil {
			return nil, err
		}
		b := a
		if len(v) == 2 {
			b, err = strconv.Atoi(strings.TrimSpace(v[1]))
			if err != nil {
				return nil, err
			}
		}
		if a < 1 || b > 52 || a > b {
			return nil, errors.New("周次只能为 1 至 52")
		}
		for n := a; n <= b; n++ {
			found[n] = true
		}
	}
	out := []int{}
	for n := 1; n <= 52; n++ {
		if found[n] {
			out = append(out, n)
		}
	}
	return out, nil
}
func applies(e Event) bool {
	for _, w := range e.Weeks {
		if w == state.SelectedWeek {
			return true
		}
	}
	return false
}
func initList() {
	var icc = iccex{Size: uint32(unsafe.Sizeof(iccex{})), Classes: 1}
	call(comctl32.NewProc("InitCommonControlsEx"), uintptr(unsafe.Pointer(&icc)))
	list = create("SysListView32", "", WS_CHILD|WS_VISIBLE|WS_BORDER|LVS_REPORT|LVS_SINGLESEL|LVS_SHOWSELALWAYS, 0, 16, 86, 1100, 400)
	send(list, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT|LVS_EX_DOUBLEBUFFER)
	for n, t := range append([]string{"时间"}, labels...) {
		width := 136
		if n == 0 {
			width = 82
		}
		c := lvc{Mask: LVCF_FMT | LVCF_WIDTH | LVCF_TEXT, Cx: int32(width), PszText: ptr(t)}
		send(list, LVM_INSERTCOLUMNW, uintptr(n), uintptr(unsafe.Pointer(&c)))
	}
}
func refreshGrid() {
	if list == 0 {
		return
	}
	send(list, LVM_DELETEALLITEMS, 0, 0)
	rows = rows[:0]
	dates := dateRanges()
	rowIndex := 0
	count := 0
	for _, event := range state.Events {
		if applies(event) {
			count++
		}
	}
	setText(weekLabel, fmt.Sprintf("第 %d 周  ·  %s — %s  ·  本周 %d 项安排", state.SelectedWeek, dates[0][5:], dates[6][5:], count))
	for start := state.RangeStart; start < state.RangeEnd; start += 30 {
		rows = append(rows, start)
		label := formatTime(start)
		item := lvi{Mask: LVIF_TEXT, IItem: int32(rowIndex), ISubItem: 0, PszText: ptr(label)}
		send(list, LVM_INSERTITEMW, 0, uintptr(unsafe.Pointer(&item)))
		for day := 1; day <= 7; day++ {
			titles := []string{}
			for _, e := range state.Events {
				if e.Day == day && applies(e) && e.Start < start+30 && e.End > start {
					title := e.Title
					for _, k := range state.Completed {
						if k == e.ID+":"+strconv.Itoa(state.SelectedWeek) {
							title = "✓ " + title
							break
						}
					}
					titles = append(titles, title)
				}
			}
			var title string
			if len(titles) > 0 {
				title = strings.Join(titles, "、")
				if len([]rune(title)) > 46 {
					title = string([]rune(title)[:43]) + "…"
				}
			}
			itm := lvi{ISubItem: int32(day), PszText: ptr(title)}
			send(list, LVM_SETITEMTEXTW, uintptr(rowIndex), uintptr(unsafe.Pointer(&itm)))
		}
		rowIndex++
	}
}
func dateRanges() [7]string {
	start, _ := time.Parse("2006-01-02", state.SemesterStart)
	start = start.AddDate(0, 0, (state.SelectedWeek-1)*7)
	var output [7]string
	for n := 0; n < 7; n++ {
		output[n] = start.AddDate(0, 0, n).Format("2006-01-02")
	}
	return output
}
func updateEditor(e *Event, day, start int) {
	defer func() { lastEditorSignature = editorSignature() }()
	send(controls[ID_ONLYTHIS], 0x00F1, 0, 0)
	if e != nil {
		editorID = e.ID
		setText(controls[ID_TITLE], e.Title)
		send(controls[ID_DAY], CB_SETCURSEL, uintptr(e.Day-1), 0)
		catIndex := 0
		for n, c := range catCodes {
			if c == e.Category {
				catIndex = n
			}
		}
		send(controls[ID_CATEGORY], CB_SETCURSEL, uintptr(catIndex), 0)
		setText(controls[ID_START], formatTime(e.Start))
		setText(controls[ID_END], formatTime(e.End))
		setText(controls[ID_WEEKS], weekText(e.Weeks))
		setText(controls[ID_LOCATION], e.Location)
		setText(controls[ID_NOTES], e.Notes)
	} else {
		editorID = ""
		setText(controls[ID_TITLE], "")
		send(controls[ID_DAY], CB_SETCURSEL, uintptr(day-1), 0)
		send(controls[ID_CATEGORY], CB_SETCURSEL, 0, 0)
		setText(controls[ID_START], formatTime(start))
		setText(controls[ID_END], formatTime(min(start+30, 1440)))
		setText(controls[ID_WEEKS], strconv.Itoa(state.SelectedWeek))
		setText(controls[ID_LOCATION], "")
		setText(controls[ID_NOTES], "")
	}
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func findEvent(id string) *Event {
	for i := range state.Events {
		if state.Events[i].ID == id {
			return &state.Events[i]
		}
	}
	return nil
}
func saveForm() {
	title := strings.TrimSpace(getText(controls[ID_TITLE]))
	if title == "" {
		show("填写错误", "请填写安排名称", MB_OK|MB_ICONERROR)
		return
	}
	start, err := parseTime(getText(controls[ID_START]))
	if err != nil {
		show("时间错误", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	end, err := parseTime(getText(controls[ID_END]))
	if err != nil || start >= end || start >= 1440 {
		show("时间错误", "结束时间必须在开始时间之后；跨日请拆为两条安排。", MB_OK|MB_ICONERROR)
		return
	}
	weeks, err := parseWeeks(getText(controls[ID_WEEKS]))
	if err != nil {
		show("周次错误", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	day := int(send(controls[ID_DAY], CB_GETCURSEL, 0, 0)) + 1
	cat := int(send(controls[ID_CATEGORY], CB_GETCURSEL, 0, 0))
	if cat < 0 || cat >= len(catCodes) || day < 1 || day > 7 {
		return
	}
	old := findEvent(editorID)
	id := editorID
	previousState := model.Clone(state)
	if id == "" {
		id = "e-" + strconv.FormatInt(time.Now().UnixNano(), 36)
	}
	event := Event{ID: id, Title: title, Day: day, Start: start, End: end, Category: catCodes[cat], Location: strings.TrimSpace(getText(controls[ID_LOCATION])), Notes: strings.TrimSpace(getText(controls[ID_NOTES])), Weeks: weeks, Uncertain: false}
	if old != nil && send(controls[ID_ONLYTHIS], BM_GETCHECK, 0, 0) == 1 && len(old.Weeks) > 1 {
		oldID := old.ID
		remaining := []int{}
		for _, w := range old.Weeks {
			if w != state.SelectedWeek {
				remaining = append(remaining, w)
			}
		}
		if len(remaining) == len(old.Weeks) {
			show("修改范围", "所选安排不在当前周。", MB_OK|MB_ICONERROR)
			return
		}
		old.Weeks = remaining
		event.ID = "e-" + strconv.FormatInt(time.Now().UnixNano(), 36)
		event.Weeks = []int{state.SelectedWeek}
		state.Events = append(state.Events, event)
		for i, k := range state.Completed {
			if k == oldID+":"+strconv.Itoa(state.SelectedWeek) {
				state.Completed[i] = event.ID + ":" + strconv.Itoa(state.SelectedWeek)
			}
		}
	} else if old != nil {
		*old = event
	} else {
		state.Events = append(state.Events, event)
	}
	if err = save(); err != nil {
		state = previousState
		show("保存失败", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	refreshGrid()
	updateEditor(&event, day, start)
}
func deleteForm() {
	if editorID == "" {
		return
	}
	if show("删除安排", "确定删除所选安排吗？", MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	beforeDelete := model.Clone(state)
	onlyThis := send(controls[ID_ONLYTHIS], BM_GETCHECK, 0, 0) == 1
	kept := []Event{}
	for _, e := range state.Events {
		if e.ID == editorID && onlyThis {
			weeks := []int{}
			for _, w := range e.Weeks {
				if w != state.SelectedWeek {
					weeks = append(weeks, w)
				}
			}
			e.Weeks = weeks
		}
		if e.ID != editorID || (onlyThis && len(e.Weeks) > 0) {
			kept = append(kept, e)
		}
	}
	state.Events = kept
	keptCompleted := []string{}
	for _, s := range state.Completed {
		if (onlyThis && s != editorID+":"+strconv.Itoa(state.SelectedWeek)) || (!onlyThis && !strings.HasPrefix(s, editorID+":")) {
			keptCompleted = append(keptCompleted, s)
		}
	}
	state.Completed = keptCompleted
	if err := save(); err != nil {
		state = beforeDelete
		show("删除失败", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	refreshGrid()
	updateEditor(nil, 1, state.RangeStart)
}
func filenameDialog(isSave bool) string {
	var file [520]uint16
	copy(file[:], utf16.Encode([]rune("半刻通用日程备份.json")))
	filter := utf16.Encode([]rune("JSON 文件 (*.json)\x00*.json\x00所有文件 (*.*)\x00*.*\x00\x00"))
	title := "选择半刻日程 JSON"
	if isSave {
		title = "导出半刻日程备份"
	}
	ofn := openFile{LStructSize: uint32(unsafe.Sizeof(openFile{})), HwndOwner: mainWindow, Filter: &filter[0], File: &file[0], MaxFile: uint32(len(file)), Title: ptr(title), DefExt: ptr("json"), Flags: OFN_EXPLORER | OFN_PATHMUSTEXIST}
	var result uintptr
	if isSave {
		ofn.Flags |= OFN_OVERWRITEPROMPT
		result = call(comdlg32.NewProc("GetSaveFileNameW"), uintptr(unsafe.Pointer(&ofn)))
	} else {
		ofn.Flags |= OFN_FILEMUSTEXIST
		result = call(comdlg32.NewProc("GetOpenFileNameW"), uintptr(unsafe.Pointer(&ofn)))
	}
	if result == 0 {
		return ""
	}
	return syscall.UTF16ToString(file[:])
}
func exportJSON() {
	path := filenameDialog(true)
	if path == "" {
		return
	}
	data, err := json.MarshalIndent(state, "", "  ")
	if err == nil {
		err = os.WriteFile(path, data, 0600)
	}
	if err != nil {
		show("导出失败", err.Error(), MB_OK|MB_ICONERROR)
	} else {
		show("导出完成", "已保存完整 JSON 日程备份。", MB_OK|MB_ICONINFORMATION)
	}
}
func importJSON() {
	path := filenameDialog(false)
	if path == "" {
		return
	}
	file, err := os.Open(path)
	if err != nil {
		show("读取失败", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	defer file.Close()
	b, err := io.ReadAll(io.LimitReader(file, 4*1024*1024+1))
	if err != nil || len(b) > 4*1024*1024 {
		show("导入失败", "备份超过 4MB 或无法读取。", MB_OK|MB_ICONERROR)
		return
	}
	var incoming PlannerState
	err = json.Unmarshal(b, &incoming)
	if err == nil {
		err = validate(incoming)
	}
	if err != nil {
		show("导入失败", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if show("覆盖当前日程", "导入会替换当前日程。建议先导出备份。确定继续？", MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	before := state
	state = incoming
	if err = save(); err != nil {
		state = before
		show("导入失败", err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	refreshGrid()
	updateEditor(nil, 1, state.RangeStart)
	show("导入完成", fmt.Sprintf("已导入 %d 条安排。", len(state.Events)), MB_OK|MB_ICONINFORMATION)
}
func createUI() {
	create("STATIC", "半刻  ·  通用空白周计划", WS_CHILD|WS_VISIBLE, 0, 15, 12, 250, 29)
	subtitleWindow = create("STATIC", "每半小时一格 · 七天 · 局域网自动同步", WS_CHILD|WS_VISIBLE, 0, 274, 15, 340, 24)
	weekLabel = create("STATIC", "", WS_CHILD|WS_VISIBLE, 0, 16, 50, 520, 25)
	create("BUTTON", "‹ 上一周", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_PREV, 550, 45, 85, 28)
	create("BUTTON", "下一周 ›", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_NEXT, 640, 45, 85, 28)
	create("BUTTON", "当前周", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_TODAY, 730, 45, 75, 28)
	create("BUTTON", "导出 JSON", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_EXPORT, 822, 45, 94, 28)
	create("BUTTON", "导入 JSON", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_IMPORT, 923, 45, 94, 28)
	create("BUTTON", "切换时间范围", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_RANGE, 1022, 45, 124, 28)
	create("BUTTON", "新建安排", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_NEW, 1030, 13, 116, 27)
	create("BUTTON", "手机同步", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_SYNC, 640, 12, 102, 28)
	create("BUTTON", "关闭同步", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_STOP_SYNC, 750, 12, 102, 28)
	create("EDIT", state.SemesterStart, WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_PLAN_START, 640, 43, 134, 23)
	create("BUTTON", "设置第1周", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_SET_PLAN_START, 778, 43, 104, 24)
	initList()
	staticHwnds = append(staticHwnds, create("STATIC", "编辑安排（点击时间表单元格，可新建或修改）", WS_CHILD|WS_VISIBLE, 0, 16, 0, 600, 23))
	// edit row one
	staticHwnds = append(staticHwnds, create("STATIC", "名称", WS_CHILD|WS_VISIBLE, 0, 17, 0, 50, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL, ID_TITLE, 68, 0, 210, 25)
	staticHwnds = append(staticHwnds, create("STATIC", "星期", WS_CHILD|WS_VISIBLE, 0, 291, 0, 46, 25))
	create("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, ID_DAY, 334, 0, 88, 160)
	staticHwnds = append(staticHwnds, create("STATIC", "分类", WS_CHILD|WS_VISIBLE, 0, 433, 0, 45, 25))
	create("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, ID_CATEGORY, 477, 0, 94, 160)
	staticHwnds = append(staticHwnds, create("STATIC", "开始", WS_CHILD|WS_VISIBLE, 0, 585, 0, 46, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_START, 631, 0, 66, 25)
	staticHwnds = append(staticHwnds, create("STATIC", "结束", WS_CHILD|WS_VISIBLE, 0, 710, 0, 46, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_END, 754, 0, 66, 25)
	// edit row two
	staticHwnds = append(staticHwnds, create("STATIC", "重复周", WS_CHILD|WS_VISIBLE, 0, 17, 0, 50, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_WEEKS, 68, 0, 170, 25)
	staticHwnds = append(staticHwnds, create("STATIC", "地点", WS_CHILD|WS_VISIBLE, 0, 256, 0, 46, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_LOCATION, 300, 0, 210, 25)
	staticHwnds = append(staticHwnds, create("STATIC", "备注", WS_CHILD|WS_VISIBLE, 0, 524, 0, 43, 25))
	create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL, ID_NOTES, 567, 0, 246, 25)
	create("BUTTON", "仅修改/删除本周", WS_CHILD|WS_VISIBLE|WS_TABSTOP|3, ID_ONLYTHIS, 16, 0, 148, 25)
	create("BUTTON", "完成 / 未完成", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_COMPLETE, 170, 0, 140, 25)
	create("BUTTON", "保存安排", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_SAVE, 822, 0, 94, 29)
	create("BUTTON", "删除", WS_CHILD|WS_VISIBLE|WS_TABSTOP, ID_DELETE, 924, 0, 94, 29)
	for _, d := range labels {
		send(controls[ID_DAY], CB_ADDSTRING, 0, uintptr(unsafe.Pointer(ptr(d))))
	}
	for _, c := range cats {
		send(controls[ID_CATEGORY], CB_ADDSTRING, 0, uintptr(unsafe.Pointer(ptr(c))))
	}
	updateEditor(nil, 1, state.RangeStart)
	refreshGrid()
}
func onSize(width, height int) {
	if width < 640 || height < 430 {
		return
	}
	lastWidth, lastHeight = width, height
	y := max(225, height-194)
	call(moveWindow, list, 16, 96, uintptr(width-32), uintptr(y-101), 1)
	// Fit seven day columns into the current window; never hide a half-screen control.
	for n := 0; n < 8; n++ {
		w := (width - 112) / 7
		if n == 0 {
			w = 72
		}
		send(list, LVM_FIRST+30, uintptr(n), uintptr(w))
	}
	call(moveWindow, weekLabel, 16, 45, uintptr(width-308), 24, 1)
	for i, id := range []int{ID_PREV, ID_NEXT, ID_TODAY, ID_EXPORT, ID_IMPORT, ID_RANGE, ID_NEW} {
		w := (width - 38) / 7
		call(moveWindow, controls[id], uintptr(16+i*w), 69, uintptr(w-4), 24, 1)
	}
	call(moveWindow, controls[ID_SYNC], uintptr(width-216), 10, 98, 28, 1)
	call(moveWindow, controls[ID_STOP_SYNC], uintptr(width-112), 10, 98, 28, 1)
	call(moveWindow, controls[ID_PLAN_START], uintptr(width-280), 43, 142, 23, 1)
	call(moveWindow, controls[ID_SET_PLAN_START], uintptr(width-132), 42, 116, 24, 1)
	call(user32.NewProc("ShowWindow"), subtitleWindow, uintptr(func() int {
		if width < 920 {
			return 0
		}
		return 1
	}()))
	half := (width - 48) / 2
	positions := [][4]int{{16, y, width - 32, 22}, {16, y + 28, 40, 24}, {16 + half, y + 28, 40, 24}, {16 + half + 138, y + 28, 40, 24}, {16, y + 64, 40, 24}, {158, y + 64, 40, 24}, {300, y + 64, 60, 24}, {16, y + 100, 40, 24}, {16 + half, y + 100, 40, 24}}
	for i, h := range staticHwnds {
		if i < len(positions) {
			r := positions[i]
			call(moveWindow, h, uintptr(r[0]), uintptr(r[1]), uintptr(r[2]), uintptr(r[3]), 1)
		}
	}
	for id, r := range map[int][4]int{
		ID_ONLYTHIS: {16, y + 142, 152, 25}, ID_COMPLETE: {174, y + 142, 144, 25},
		ID_TITLE: {58, y + 28, half - 65, 25}, ID_DAY: {58 + half, y + 28, 86, 170}, ID_CATEGORY: {196 + half, y + 28, 90, 170},
		ID_START: {58, y + 64, 84, 25}, ID_END: {200, y + 64, 84, 25}, ID_WEEKS: {364, y + 64, width - 388, 25},
		ID_LOCATION: {58, y + 100, half - 65, 25}, ID_NOTES: {58 + half, y + 100, half - 20, 25}, ID_SAVE: {width - 230, y + 141, 104, 29}, ID_DELETE: {width - 116, y + 141, 100, 29},
	} {
		call(moveWindow, controls[id], uintptr(r[0]), uintptr(r[1]), uintptr(r[2]), uintptr(r[3]), 1)
	}
}

var staticHwnds = []uintptr{}

func positionStatic(y int) {
	if len(staticHwnds) == 0 {
		return
	}
	// index 0 = editor section heading; subsequent IDs are first row and second row labels
	positions := [][4]int{{16, y, 620, 22}, {17, y + 35, 50, 24}, {291, y + 35, 43, 24}, {433, y + 35, 44, 24}, {585, y + 35, 44, 24}, {710, y + 35, 44, 24},
		{17, y + 77, 50, 24}, {256, y + 77, 44, 24}, {524, y + 77, 43, 24}}
	for i, h := range staticHwnds {
		if i < len(positions) {
			r := positions[i]
			call(moveWindow, h, uintptr(r[0]), uintptr(r[1]), uintptr(r[2]), uintptr(r[3]), 1)
		}
	}
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func winProc(hwnd, message, wParam, lParam uintptr) uintptr {
	switch message {
	case WM_CREATE:
		mainWindow = hwnd
		createUI()
		return 0
	case WM_TIMER:
		refreshFromSync()
		return 0
	case WM_SIZE:
		onSize(int(uint16(lParam)), int(uint16(lParam>>16)))
		return 0
	case WM_COMMAND:
		switch int(wParam & 0xffff) {
		case ID_SET_PLAN_START:
			raw := strings.TrimSpace(getText(controls[ID_PLAN_START]))
			date, err := time.Parse("2006-01-02", raw)
			if err != nil || date.Weekday() != time.Monday {
				show("日期无效", "请输入周一日期，例如 2026-10-19。", MB_OK|MB_ICONERROR)
				return 0
			}
			if show("修改计划起点", "这会改变所有重复周次对应的日期，并同步到其他设备。请先导出备份。继续吗？", MB_YESNO|MB_ICONQUESTION) != IDYES {
				return 0
			}
			old := state.SemesterStart
			state.SemesterStart = raw
			if err = save(); err != nil {
				state.SemesterStart = old
				show("未修改", err.Error(), MB_OK|MB_ICONERROR)
			}
			refreshGrid()
		case ID_COMPLETE:
			if editorID == "" {
				show("请选择安排", "先点击已有安排，再标记完成。", MB_OK|MB_ICONINFORMATION)
				return 0
			}
			before := model.Clone(state)
			key := editorID + ":" + strconv.Itoa(state.SelectedWeek)
			found := false
			marks := []string{}
			for _, k := range state.Completed {
				if k == key {
					found = true
				} else {
					marks = append(marks, k)
				}
			}
			if !found {
				marks = append(marks, key)
			}
			state.Completed = marks
			if err := save(); err != nil {
				state = before
				show("保存失败", err.Error(), MB_OK|MB_ICONERROR)
			}
			refreshGrid()
		case ID_SYNC:
			showPairing()
		case ID_STOP_SYNC:
			syncService.DisableLAN()
			show("同步已关闭", "本机日程保留；手机修改留在手机，重新连接后再同步。", MB_OK|MB_ICONINFORMATION)
		case ID_PREV:
			if state.SelectedWeek > 1 {
				state.SelectedWeek--
				save()
				refreshGrid()
			}
		case ID_NEXT:
			if state.SelectedWeek < 52 {
				state.SelectedWeek++
				save()
				refreshGrid()
			}
		case ID_TODAY:
			base, _ := time.Parse("2006-01-02", state.SemesterStart)
			today, _ := time.Parse("2006-01-02", time.Now().Format("2006-01-02"))
			delta := int(today.Sub(base).Hours() / 24)
			target := delta/7 + 1
			if target >= 1 && target <= 52 {
				state.SelectedWeek = target
				save()
				refreshGrid()
			} else {
				show("超出范围", "今天不在目前设置的 52 周内。", MB_OK|MB_ICONINFORMATION)
			}
		case ID_RANGE:
			if state.RangeStart == 420 && state.RangeEnd == 1380 {
				state.RangeStart = 0
				state.RangeEnd = 1440
			} else if state.RangeStart == 0 && state.RangeEnd == 1440 {
				state.RangeStart = 960
				state.RangeEnd = 1440
			} else if state.RangeStart == 960 && state.RangeEnd == 1440 {
				state.RangeStart = 360
				state.RangeEnd = 720
			} else {
				state.RangeStart = 420
				state.RangeEnd = 1380
			}
			if err := save(); err != nil {
				show("保存失败", err.Error(), MB_OK|MB_ICONERROR)
			}
			refreshGrid()
		case ID_SAVE:
			saveForm()
		case ID_DELETE:
			deleteForm()
		case ID_NEW:
			updateEditor(nil, 1, state.RangeStart)
		case ID_EXPORT:
			exportJSON()
		case ID_IMPORT:
			importJSON()
		}
		return 0
	case WM_NOTIFY:
		if lParam != 0 {
			hdr := (*nmhdr)(unsafe.Pointer(lParam))
			if hdr.HwndFrom == list && int32(hdr.Code) == -2 {
				detail := (*nmitemactivate)(unsafe.Pointer(lParam))
				row, day := int(detail.IItem), int(detail.ISubItem)
				if row >= 0 && row < len(rows) && day >= 1 && day <= 7 {
					start := rows[row]
					var match *Event
					hits := []*Event{}
					for n := range state.Events {
						e := &state.Events[n]
						if e.Day == day && applies(*e) && e.Start < start+30 && e.End > start {
							hits = append(hits, e)
						}
					}
					if len(hits) > 0 {
						match = hits[0]
						for i, e := range hits {
							if e.ID == editorID {
								match = hits[(i+1)%len(hits)]
								break
							}
						}
					}
					updateEditor(match, day, start)
				}
			}
		}
		return 0
	case WM_DESTROY:
		call(user32.NewProc("PostQuitMessage"), 0)
		return 0
	}
	return call(defWindowProc, hwnd, message, wParam, lParam)
}
func main() {
	runtime.LockOSThread()
	flag.StringVar(&dataDir, "data-dir", "", "isolated data directory")
	flag.BoolVar(&smokeTest, "smoke-test", false, "verify native controls on a Windows CI runner")
	flag.Parse()
	if dataDir == "" && !smokeTest {
		if previous := call(user32.NewProc("FindWindowW"), uintptr(unsafe.Pointer(ptr("BankeGenericSyncWindow"))), 0); previous != 0 {
			call(user32.NewProc("ShowWindow"), previous, 9)
			call(user32.NewProc("SetForegroundWindow"), previous)
			return
		}
	}
	if smokeTest && dataDir == "" {
		dataDir, _ = os.MkdirTemp("", "banke-ui-test-")
		defer os.RemoveAll(dataDir)
	}
	load()
	defer syncService.Close()
	call(user32.NewProc("SetProcessDPIAware"))
	shell32 := syscall.NewLazyDLL("shell32.dll")
	call(shell32.NewProc("SetCurrentProcessExplicitAppUserModelID"), uintptr(unsafe.Pointer(ptr("org.banke.generic.sync"))))
	if storageDamaged {
		show("日程提示", "发现无法读取的旧本机日程。为保护原文件，建议先复制数据文件，再继续编辑。", MB_OK|MB_ICONERROR)
	}
	proc := syscall.NewCallback(winProc)
	instance := call(kernel32.NewProc("GetModuleHandleW"), 0)
	className := ptr("BankeGenericSyncWindow")
	icon := call(user32.NewProc("LoadIconW"), 0, 32512)
	if png, e := fs.ReadFile(banke.Web(), "icons/icon-192.png"); e == nil && len(png) > 0 {
		if h := call(user32.NewProc("CreateIconFromResourceEx"), uintptr(unsafe.Pointer(&png[0])), uintptr(len(png)), 1, 0x00030000, 64, 64, 0); h != 0 {
			icon = h
		}
	}
	cursor := call(user32.NewProc("LoadCursorW"), 0, 32512)
	class := wndclass{LpfnWndProc: proc, HInstance: instance, HIcon: icon, HCursor: cursor, HbrBackground: call(gdi32.NewProc("GetStockObject"), 0), LpszClassName: className}
	if call(user32.NewProc("RegisterClassW"), uintptr(unsafe.Pointer(&class))) == 0 {
		show("启动失败", "窗口组件未能注册。", MB_OK|MB_ICONERROR)
		return
	}
	h := call(createWindow, 0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(ptr("半刻 · 通用空白周计划（Windows 原生版）"))), WS_OVERLAPPEDWINDOW|WS_VISIBLE, 70, 60, 1100, 760, 0, 0, instance, 0)
	if h == 0 {
		show("启动失败", "Windows 窗口创建失败。", MB_OK|MB_ICONERROR)
		return
	}
	call(user32.NewProc("ShowWindow"), h, 1)
	call(user32.NewProc("UpdateWindow"), h)
	call(user32.NewProc("SetTimer"), h, 1, 1000, 0)
	if smokeTest {
		if list == 0 || call(user32.NewProc("IsWindow"), list) == 0 || send(list, LVM_FIRST+4, 0, 0) != 32 {
			os.Exit(2)
		}
		header := send(list, LVM_FIRST+31, 0, 0)
		if header == 0 || send(header, 0x1200, 0, 0) != 8 {
			os.Exit(3)
		}
		return
	}
	var m msg
	for call(user32.NewProc("GetMessageW"), uintptr(unsafe.Pointer(&m)), 0, 0, 0) > 0 {
		call(user32.NewProc("TranslateMessage"), uintptr(unsafe.Pointer(&m)))
		call(user32.NewProc("DispatchMessageW"), uintptr(unsafe.Pointer(&m)))
	}
}
