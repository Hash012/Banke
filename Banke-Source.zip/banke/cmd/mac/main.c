/* Banke's tiny, SDK-independent AppKit + WKWebView desktop host.
 * All APIs below are macOS public Objective-C runtime / AppKit / WebKit APIs.
 * Fixed ABI declarations permit reproducible Linux cross-linking without copying
 * Apple's SDK headers or redistributing SDK files. The same C source builds with
 * Apple's clang on macOS. No remote executable code or external browser is used.
 */
typedef void *Obj, *Sel, *Cls;
typedef unsigned long USize; typedef long Integer;
typedef struct { double x,y; } Point;
typedef struct { double width,height; } Size;
typedef struct { Point origin; Size size; } Rect;
extern void *dlopen(const char *,int); extern void *dlsym(void *,const char *);
extern int pipe(int *),fork(void),dup2(int,int),close(int),kill(int,int),execv(const char *,char *const *);
extern long read(int,void *,USize); extern int snprintf(char *,USize,const char *,...);
extern USize strlen(const char *); extern int strcmp(const char *,const char *);
extern char *strchr(const char *,int); extern char *getenv(const char *);
extern void _exit(int); extern unsigned alarm(unsigned); extern int getpid(void); extern char *mkdtemp(char *); extern int open(const char *,int,...);
struct PollFD { int fd; short events,revents; }; extern int poll(struct PollFD *,unsigned long,int);
static Cls (*getClass)(const char *); static Sel (*selector)(const char *);
static Cls (*newClass)(Cls,const char *,USize); static int (*addMethod)(Cls,Sel,void *,const char *);
static void (*registerClass)(Cls); static void (*send)(void);
static int child=-1, adminPort=0, smoke=0; static char testDirectory[128]; static Obj app,window,delegate;
#define S(s) selector(s)
#define O(o,s) ((Obj(*)(Obj,Sel))send)((o),S(s))
#define O1(o,s,a) ((Obj(*)(Obj,Sel,Obj))send)((o),S(s),(a))
#define V(o,s) ((void(*)(Obj,Sel))send)((o),S(s))
#define V1(o,s,a) ((void(*)(Obj,Sel,Obj))send)((o),S(s),(a))
#define NUM(o,s,n) ((void(*)(Obj,Sel,Integer))send)((o),S(s),(n))
#define INT(o,s) ((Integer(*)(Obj,Sel))send)((o),S(s))
#define C(s) ((Obj)getClass(s))
static Obj str(const char *s){return ((Obj(*)(Obj,Sel,const char *))send)(C("NSString"),S("stringWithUTF8String:"),s);}
static const char *utf(Obj o){return ((const char *(*)(Obj,Sel))send)(o,S("UTF8String"));}
static void alert(const char *title,const char *message){Obj a=O(O(C("NSAlert"),"alloc"),"init");V1(a,"setMessageText:",str(title));V1(a,"setInformativeText:",str(message));O1(a,"addButtonWithTitle:",str("OK"));INT(a,"runModal");}
static void terminate(Obj self,Sel command,Obj note){(void)self;(void)command;(void)note;if(child>0){kill(child,15);child=-1;}}
static signed char quitLast(Obj self,Sel command,Obj sender){(void)self;(void)command;(void)sender;return 1;}
struct Block {void *isa; int flags,reserved; void (*invoke)(void *,Integer);};
static void navigation(Obj self,Sel command,Obj view,Obj action,void *callback){
 (void)self;(void)command;(void)view;Obj url=O(O(action,"request"),"URL");
 const char *host=utf(O(url,"host")),*scheme=utf(O(url,"scheme"));
 int allowed=host&&scheme&&!strcmp(host,"127.0.0.1")&&!strcmp(scheme,"http")&&INT(O(url,"port"),"integerValue")==adminPort;
 struct Block *b=(struct Block *)callback;b->invoke(callback,allowed?1:0);
}
static void share(Obj self,Sel command,Obj controller,Obj message){
 (void)self;(void)command;(void)controller;
 Obj data=O(message,"body"),action=O1(data,"objectForKey:",str("action"));
 if(!action||!utf(action))return;
 if(smoke&&!strcmp(utf(action),"ready")){
  if(INT(O1(data,"objectForKey:",str("eventCount")),"integerValue")!=0||INT(O1(data,"objectForKey:",str("columns")),"integerValue")!=7){terminate(0,0,0);_exit(4);}
  alarm(0);V1(app,"terminate:",(Obj)0);return;
 }
 if(strcmp(utf(action),"share"))return;
 Obj text=O1(data,"objectForKey:",str("text")),name=O1(data,"objectForKey:",str("fileName"));
 if(!text||!name||INT(text,"length")>8*1024*1024)return;
 Obj panel=O(C("NSSavePanel"),"savePanel");V1(panel,"setNameFieldStringValue:",O(name,"lastPathComponent"));NUM(panel,"setCanCreateDirectories:",1);
 if(INT(panel,"runModal")!=1)return;
 signed char ok=((signed char(*)(Obj,Sel,Obj,signed char,USize,Obj *))send)(text,S("writeToURL:atomically:encoding:error:"),O(panel,"URL"),1,4,(Obj*)0);
 if(!ok)alert("Backup not saved","The destination could not be written. Choose another folder and try again.");
}
static void menuItem(Obj menu,const char *title,const char *action,const char *key){
 Obj item=((Obj(*)(Obj,Sel,Obj,Sel,Obj))send)(O(C("NSMenuItem"),"alloc"),S("initWithTitle:action:keyEquivalent:"),str(title),S(action),str(key));V1(menu,"addItem:",item);
}
static void createMenu(void){
 Obj bar=O(O(C("NSMenu"),"alloc"),"init");
 Obj item=O(O(C("NSMenuItem"),"alloc"),"init"),sub=O1(O(C("NSMenu"),"alloc"),"initWithTitle:",str("Banke"));
 menuItem(sub,"Quit Banke","terminate:","q");V1(item,"setSubmenu:",sub);V1(bar,"addItem:",item);
 item=O(O(C("NSMenuItem"),"alloc"),"init");sub=O1(O(C("NSMenu"),"alloc"),"initWithTitle:",str("Edit"));
 menuItem(sub,"Cut","cut:","x");menuItem(sub,"Copy","copy:","c");menuItem(sub,"Paste","paste:","v");menuItem(sub,"Select All","selectAll:","a");
 V1(item,"setSubmenu:",sub);V1(bar,"addItem:",item);V1(app,"setMainMenu:",bar);
}
static Obj launchService(void){
 Obj bundle=O(C("NSBundle"),"mainBundle");const char *resources=utf(O(bundle,"resourcePath"));if(!resources)return 0;
 char path[4096];snprintf(path,sizeof(path),"%s/banke-server",resources);
 int fds[2];if(pipe(fds)!=0)return 0;child=fork();
 if(child==0){
  close(fds[0]);dup2(fds[1],1);close(fds[1]);
  char log[4096];const char *home=getenv("HOME");if(home){snprintf(log,sizeof(log),"%s/Library/Logs/Banke-launch.log",home);int fd=open(log,1|0x0200|0x0008,0600);if(fd>=0){dup2(fd,2);close(fd);}}
  char *args[]={path,"--no-open","--port","47832",0,0,0};if(smoke){args[4]="--data-dir";args[5]=testDirectory;}execv(path,args);_exit(127);
 }
 close(fds[1]);if(child<0){close(fds[0]);return 0;}
 char line[4096];int used=0;
 while(used<(int)sizeof(line)-1){struct PollFD p={fds[0],1,0};if(poll(&p,1,10000)<=0)break;long count=read(fds[0],line+used,1);if(count<=0)break;if(line[used++]=='\n')break;}
 close(fds[0]);line[used]=0;if(!used)return 0;
 Obj bytes=((Obj(*)(Obj,Sel,const void *,USize))send)(C("NSData"),S("dataWithBytes:length:"),line,(USize)used);
 Obj parsed=((Obj(*)(Obj,Sel,Obj,USize,Obj *))send)(C("NSJSONSerialization"),S("JSONObjectWithData:options:error:"),bytes,0,(Obj*)0);
 Obj text=O1(parsed,"objectForKey:",str("url"));if(!text)return 0;
 Obj url=O1(C("NSURL"),"URLWithString:",text);adminPort=(int)INT(O(url,"port"),"integerValue");return url;
}
int main(int argc,char **argv){
 smoke=argc>1&&!strcmp(argv[1],"--smoke-test");if(smoke){snprintf(testDirectory,sizeof(testDirectory),"/tmp/banke-mac-test-XXXXXX");if(!mkdtemp(testDirectory))return 5;alarm(25);}
 void *runtime=dlopen("/usr/lib/libobjc.A.dylib",1|8);
 if(!runtime)_exit(1);
 getClass=(Cls(*)(const char *))dlsym(runtime,"objc_getClass");selector=(Sel(*)(const char *))dlsym(runtime,"sel_registerName");send=(void(*)(void))dlsym(runtime,"objc_msgSend");
 newClass=(Cls(*)(Cls,const char *,USize))dlsym(runtime,"objc_allocateClassPair");addMethod=(int(*)(Cls,Sel,void *,const char *))dlsym(runtime,"class_addMethod");registerClass=(void(*)(Cls))dlsym(runtime,"objc_registerClassPair");
 if(!dlopen("/System/Library/Frameworks/Foundation.framework/Foundation",1|8)||!dlopen("/System/Library/Frameworks/AppKit.framework/AppKit",1|8)||!dlopen("/System/Library/Frameworks/WebKit.framework/WebKit",1|8))_exit(2);
 Obj pool=O(O(C("NSAutoreleasePool"),"alloc"),"init");app=O(C("NSApplication"),"sharedApplication");NUM(app,"setActivationPolicy:",0);
 Cls dc=newClass((Cls)C("NSObject"),"BankeApplicationDelegate",0);
 addMethod(dc,S("applicationShouldTerminateAfterLastWindowClosed:"),(void*)quitLast,"c@:@");
 addMethod(dc,S("applicationWillTerminate:"),(void*)terminate,"v@:@");
 addMethod(dc,S("webView:decidePolicyForNavigationAction:decisionHandler:"),(void*)navigation,"v@:@@@?");
 addMethod(dc,S("userContentController:didReceiveScriptMessage:"),(void*)share,"v@:@@");registerClass(dc);
 delegate=O(O((Obj)dc,"alloc"),"init");V1(app,"setDelegate:",delegate);createMenu();V(app,"finishLaunching");
 Obj url=launchService();if(!url){alert("Banke could not start","The local data service could not start. Your saved data was not cleared. Check ~/Library/Logs/Banke-launch.log and the README.");terminate(0,0,0);return 3;}
 Rect frame={{80,80},{1120,800}};
 window=((Obj(*)(Obj,Sel,Rect,USize,Integer,signed char))send)(O(C("NSWindow"),"alloc"),S("initWithContentRect:styleMask:backing:defer:"),frame,1|2|4|8,2,0);
 V1(window,"setTitle:",str("半刻 · 通用空白日程 1.1.0"));
 Size minimum={640,480};((void(*)(Obj,Sel,Size))send)(window,S("setContentMinSize:"),minimum);
 Obj config=O(O(C("WKWebViewConfiguration"),"alloc"),"init"),controller=O(config,"userContentController");
 if(smoke)V1(config,"setWebsiteDataStore:",O(C("WKWebsiteDataStore"),"nonPersistentDataStore"));
 ((void(*)(Obj,Sel,Obj,Obj))send)(controller,S("addScriptMessageHandler:name:"),delegate,str("banke"));
 Rect webFrame={{0,0},{1120,800}};Obj web=((Obj(*)(Obj,Sel,Rect,Obj))send)(O(C("WKWebView"),"alloc"),S("initWithFrame:configuration:"),webFrame,config);
 NUM(web,"setAutoresizingMask:",2|16);V1(web,"setNavigationDelegate:",delegate);V1(window,"setContentView:",web);
 Obj request=O1(C("NSURLRequest"),"requestWithURL:",url);O1(web,"loadRequest:",request);
 V(window,"center");V1(window,"makeKeyAndOrderFront:",(Obj)0);NUM(app,"activateIgnoringOtherApps:",1);V(app,"run");
 terminate(0,0,0);V(pool,"drain");return 0;
}
