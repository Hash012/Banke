// banke-server is a standalone, dependency-free LAN server; the browser is a client.
package main

import (
	"banke.local/planner"
	"banke.local/planner/internal/syncserver"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"syscall"
)

func main() {
	home, _ := os.UserConfigDir()
	folder := flag.String("data-dir", filepath.Join(home, "BankeGenericSync"), "private data directory")
	port := flag.Int("port", 47832, "loopback admin port")
	lanPort := flag.Int("lan-port", 47833, "optional LAN port")
	lan := flag.Bool("lan", false, "explicitly enable LAN access")
	noOpen := flag.Bool("no-open", false, "do not open the local browser")
	cert := flag.String("tls-cert", "", "optional trusted certificate PEM for LAN listener")
	key := flag.String("tls-key", "", "optional certificate key PEM")
	flag.Parse()
	store, err := syncserver.OpenStore(*folder)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	service := syncserver.New(store, banke.Web())
	if err = service.SetLANPort(*lanPort); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	service.TLSCert = *cert
	service.TLSKey = *key
	if (*cert == "") != (*key == "") {
		fmt.Fprintln(os.Stderr, "tls-cert and tls-key must be set together")
		os.Exit(1)
	}
	if err = service.StartLocal(*port); err != nil {
		fmt.Fprintln(os.Stderr, "启动失败（端口可能被占用）：", err)
		os.Exit(1)
	}
	defer service.Close()
	if *lan {
		if err = service.EnableLAN(*lanPort); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		service.PairCode()
	}
	// The first stdout line is a machine-readable launch contract for the macOS shell.
	json.NewEncoder(os.Stdout).Encode(map[string]any{"url": service.URL(), "data": store.Path(), "version": syncserver.Version})
	if !*noOpen {
		var c *exec.Cmd
		switch runtime.GOOS {
		case "windows":
			c = exec.Command("rundll32", "url.dll,FileProtocolHandler", service.URL())
		case "darwin":
			c = exec.Command("open", service.URL())
		default:
			c = exec.Command("xdg-open", service.URL())
		}
		_ = c.Start()
	}
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop
}
