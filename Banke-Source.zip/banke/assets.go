package banke

import (
	"embed"
	"io/fs"
)

//go:embed web/* web/icons/*
var content embed.FS

func Web() fs.FS { f, _ := fs.Sub(content, "web"); return f }
