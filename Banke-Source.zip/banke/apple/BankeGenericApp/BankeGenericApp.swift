import SwiftUI

@main
struct BankeGenericApp: App {
    var body: some Scene {
        WindowGroup {
            PlannerWebView()
                .ignoresSafeArea(edges: .bottom)
        }
    }
}
