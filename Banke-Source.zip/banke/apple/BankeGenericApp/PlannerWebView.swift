import Foundation
import SwiftUI
import WebKit
import UIKit

// The app packages immutable UI files. WKWebsiteDataStore.default() retains local
// schedules/credentials. No personal seed, broad filesystem bridge or remote scripts.
struct PlannerWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.userContentController.add(context.coordinator, name: "banke")
        let bridge = """
        (()=>{const calls=new Map();let serial=0;
          window.BankeAppleReply=(id,result,error)=>{const p=calls.get(id);if(!p)return;calls.delete(id);clearTimeout(p.timer);error?p.reject(Error(error)):p.resolve(result);};
          window.BankeTransport={request:(url,data,token)=>new Promise((resolve,reject)=>{
            const id=String(++serial);const timer=setTimeout(()=>{calls.delete(id);reject(Error('连接电脑超时，本机数据保留'));},10000);
            calls.set(id,{resolve,reject,timer});window.webkit.messageHandlers.banke.postMessage({action:'request',id,url,data:data===undefined?null:data,token:token||''});
          })};
        })();
        """
        config.userContentController.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let view = WKWebView(frame: .zero, configuration: config)
        context.coordinator.webView = view
        view.navigationDelegate = context.coordinator
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.965, green: 0.973, blue: 0.969, alpha: 1)
        if let file = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "web") {
            context.coordinator.assetRoot = file.deletingLastPathComponent().standardizedFileURL.path + "/"
            view.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent())
        } else { view.loadHTMLString("<h2>界面文件缺失</h2><p>请重新安装完整应用。</p>", baseURL: nil) }
        return view
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, URLSessionTaskDelegate {
        weak var webView: WKWebView?
        var assetRoot = ""
        private lazy var session: URLSession = {
            let c = URLSessionConfiguration.ephemeral
            c.timeoutIntervalForRequest = 8
            c.timeoutIntervalForResource = 9
            c.httpCookieStorage = nil
            c.urlCache = nil
            return URLSession(configuration: c, delegate: self, delegateQueue: nil)
        }()
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.name == "banke",
                  let obj = message.body as? [String: Any], let action = obj["action"] as? String else { return }
            if action == "request" { request(obj) }
            if action == "share", let text = obj["text"] as? String { share(text, name: obj["fileName"] as? String ?? "Banke-backup.json") }
        }
        private func validURL(_ raw: String) -> URL? {
            guard let u = URL(string: raw), let c = URLComponents(url: u, resolvingAgainstBaseURL: false),
                  ["http", "https"].contains(c.scheme ?? ""), c.user == nil, c.password == nil,
                  c.query == nil, c.fragment == nil, let host = c.host,
                  ["/api/pair", "/api/sync", "/api/state", "/api/health"].contains(c.path) else { return nil }
            let parts = host.split(separator: ".", omittingEmptySubsequences: false)
            let n = parts.compactMap { Int($0) }
            guard n.count == 4, parts.count == 4, n.allSatisfy({ $0 >= 0 && $0 <= 255 }),
                  n[0] == 10 || n[0] == 127 || (n[0] == 172 && n[1] >= 16 && n[1] <= 31) || (n[0] == 192 && n[1] == 168) else { return nil }
            return u
        }
        private func request(_ obj: [String: Any]) {
            guard let id = obj["id"] as? String else { return }
            guard let raw = obj["url"] as? String, let url = validURL(raw) else { reply(id, error: "只允许软件显示的私有 IPv4 地址和同步接口"); return }
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 8)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            if let token = obj["token"] as? String, !token.isEmpty {
                guard token.count == 64, token.allSatisfy({ "0123456789abcdef".contains($0) }) else { reply(id, error: "配对凭据无效"); return }
                request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
            }
            if let data = obj["data"], !(data is NSNull) {
                guard JSONSerialization.isValidJSONObject(data), let body = try? JSONSerialization.data(withJSONObject: data), body.count <= 4 * 1024 * 1024 else { reply(id, error: "请求数据无效或超过 4 MB"); return }
                request.httpMethod = "POST"; request.httpBody = body
            } else { request.httpMethod = "GET" }
            session.dataTask(with: request) { [weak self] data, response, error in
                guard let self = self else { return }
                if let error = error { self.reply(id, error: error.localizedDescription); return }
                guard let data = data, data.count <= 4 * 1024 * 1024,
                      let value = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let http = response as? HTTPURLResponse else { self.reply(id, error: "电脑回复无效"); return }
                if !(200...299).contains(http.statusCode) || value["ok"] as? Bool == false { self.reply(id, error: value["error"] as? String ?? "同步请求失败"); return }
                self.reply(id, value: value)
            }.resume()
        }
        private func reply(_ id: String, value: [String: Any]? = nil, error: String? = nil) {
            let payload: [Any] = [id, value as Any? ?? NSNull(), error as Any? ?? NSNull()]
            guard let data = try? JSONSerialization.data(withJSONObject: payload), let json = String(data: data, encoding: .utf8) else { return }
            DispatchQueue.main.async { [weak self] in self?.webView?.evaluateJavaScript("window.BankeAppleReply(..." + json + ")") }
        }
        // Never follow a redirect from a private host to an unrelated destination.
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let u = navigationAction.request.url, u.isFileURL, u.standardizedFileURL.path.hasPrefix(assetRoot) else { decisionHandler(.cancel); return }
            decisionHandler(.allow)
        }
        private func share(_ text: String, name: String) {
            guard text.utf8.count <= 8 * 1024 * 1024 else { return }
            let fileName = URL(fileURLWithPath: name).lastPathComponent
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
            do { try text.write(to: url, atomically: true, encoding: .utf8) } catch { return }
            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  var current = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return }
            while let shown = current.presentedViewController { current = shown }
            let picker = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            if let pop = picker.popoverPresentationController { pop.sourceView = current.view; pop.sourceRect = CGRect(x: current.view.bounds.midX, y: current.view.bounds.midY, width: 1, height: 1) }
            current.present(picker, animated: true)
        }
    }
}
