//go:build !windows

package syncserver

import (
	"fmt"
	"os"
	"path/filepath"
	"syscall"
)

func lockStore(path string) (*os.File, error) {
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		return nil, e
	}
	f, e := os.OpenFile(path+".lock", os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		return nil, e
	}
	if e = syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		f.Close()
		return nil, fmt.Errorf("该日程目录已被另一个半刻进程使用，请退出重复程序：%w", e)
	}
	return f, nil
}
