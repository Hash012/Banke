//go:build windows

package syncserver

import (
	"fmt"
	"os"
	"path/filepath"
	"syscall"
	"unsafe"
)

func lockStore(path string) (*os.File, error) {
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		return nil, e
	}
	f, e := os.OpenFile(path+".lock", os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		return nil, e
	}
	var overlap syscall.Overlapped
	ok, _, callErr := syscall.NewLazyDLL("kernel32.dll").NewProc("LockFileEx").Call(f.Fd(), 3, 0, 1, 0, uintptr(unsafe.Pointer(&overlap)))
	if ok == 0 {
		f.Close()
		return nil, fmt.Errorf("该日程目录已被另一个半刻进程使用，请退出重复程序：%w", callErr)
	}
	return f, nil
}
