package syncserver

import (
	"banke.local/planner/internal/planner"
	"bytes"
	"encoding/json"
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"testing/fstest"
	"time"
)

func setup(t *testing.T) (*Service, *Store) {
	t.Helper()
	store, e := OpenStore(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { store.Close() })
	return New(store, fstest.MapFS{"index.html": &fstest.MapFile{Data: []byte("<!doctype html>blank")}}), store
}
func req(s *Service, method, path, token string, body any, origin string) *httptest.ResponseRecorder {
	b, _ := json.Marshal(body)
	r := httptest.NewRequest(method, "http://127.0.0.1:47832"+path, bytes.NewReader(b))
	r.RemoteAddr = "127.0.0.1:12345"
	if token != "" {
		r.Header.Set("Authorization", "Bearer "+token)
	}
	if origin != "" {
		r.Header.Set("Origin", origin)
	}
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	return w
}
func event(id string) planner.Event {
	return planner.Event{ID: id, Title: "Synthetic test", Day: 7, Start: 1180, End: 1270, Category: "work", Location: "", Notes: "", Weeks: []int{7}, Uncertain: false}
}
func TestUnauthorizedAndCrossOrigin(t *testing.T) {
	s, _ := setup(t)
	for _, p := range []string{"/api/state", "/api/admin/status"} {
		if w := req(s, "GET", p, "", nil, ""); w.Code != 401 {
			t.Fatal(w.Code, w.Body)
		}
	}
	if w := req(s, "GET", "/api/state", s.Admin, nil, "https://attacker.invalid"); w.Code != 403 {
		t.Fatal(w.Code)
	}
}
func TestPairOnceAndRevoke(t *testing.T) {
	s, st := setup(t)
	code, _ := s.PairCode()
	w := req(s, "POST", "/api/pair", "", map[string]string{"code": code, "name": "test phone"}, "null")
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	var v map[string]string
	json.Unmarshal(w.Body.Bytes(), &v)
	token := v["token"]
	if !st.Authorize(token) {
		t.Fatal("token not valid")
	}
	if w = req(s, "GET", "/api/state", token, nil, "null"); w.Code != 200 {
		t.Fatal(w.Code)
	}
	if w = req(s, "POST", "/api/pair", "", map[string]string{"code": code, "name": "again"}, ""); w.Code != 403 {
		t.Fatal("code reused")
	}
	if e := st.Revoke(); e != nil {
		t.Fatal(e)
	}
	if st.Authorize(token) {
		t.Fatal("revocation failed")
	}
}
func TestPairExpiryAndRateLimit(t *testing.T) {
	s, _ := setup(t)
	code, _ := s.PairCode()
	s.expires = time.Now().Add(-time.Second)
	if w := req(s, "POST", "/api/pair", "", map[string]string{"code": code, "name": "test"}, ""); w.Code != 403 {
		t.Fatal("expired accepted")
	}
	s.attempts = 10
	s.attemptsStart = time.Now()
	code, _ = s.PairCode()
	if w := req(s, "POST", "/api/pair", "", map[string]string{"code": code, "name": "test"}, ""); w.Code != 403 {
		t.Fatal("rate limit failed")
	}
}
func TestStrictPayloadAndRoom(t *testing.T) {
	s, st := setup(t)
	blank := planner.Snapshot(st.Get().State)
	if w := req(s, "POST", "/api/sync", s.Admin, map[string]any{"room": "not-this-room", "base": nil, "current": blank}, ""); w.Code != 409 {
		t.Fatal(w.Code)
	}
	if w := req(s, "POST", "/api/pair", "", map[string]any{"code": "x", "name": "t", "unknown": 1}, ""); w.Code != 400 {
		t.Fatal(w.Code)
	}
}
func TestPrivateNetworkAndHostFilter(t *testing.T) {
	s, _ := setup(t)
	for _, x := range []struct{ host, peer string }{{"evil.invalid", "127.0.0.1:1"}, {"127.0.0.1", "8.8.8.8:1"}} {
		r := httptest.NewRequest("GET", "http://"+x.host+"/api/health", nil)
		r.RemoteAddr = x.peer
		w := httptest.NewRecorder()
		s.Handler().ServeHTTP(w, r)
		if w.Code != 403 {
			t.Fatal(x, w.Code)
		}
	}
}
func TestBackupAndReopen(t *testing.T) {
	_, st := setup(t)
	d := st.Get()
	next := planner.Clone(d.State)
	next.Events = append(next.Events, event("persisted"))
	saved, _, e := st.Local(planner.Snapshot(d.State), next)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = os.Stat(st.Path() + ".previous"); e != nil {
		t.Fatal(e)
	}
	st.Close()
	again, e := OpenStore(filepath.Dir(st.Path()))
	if e != nil || !planner.Equal(saved, again.Get().State) {
		t.Fatal(e)
	}
	defer again.Close()
	token, e := again.AddDevice("phone")
	if e != nil {
		t.Fatal(e)
	}
	raw, _ := os.ReadFile(st.Path())
	if strings.Contains(string(raw), token) {
		t.Fatal("plaintext credential on disk")
	}
}
func TestCorruptStoreIsNeverOverwritten(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "schedule-sync.json")
	raw := []byte("{broken-json")
	os.WriteFile(p, raw, 0600)
	if _, e := OpenStore(dir); e == nil {
		t.Fatal("corrupt store accepted")
	}
	after, _ := os.ReadFile(p)
	if !bytes.Equal(after, raw) {
		t.Fatal("corrupt original destroyed")
	}
}
func TestFailedWriteDoesNotAcknowledgeOrChangeState(t *testing.T) {
	_, st := setup(t)
	before := st.Get()
	next := planner.Clone(before.State)
	next.Events = append(next.Events, event("fail"))
	bad := filepath.Join(t.TempDir(), "not-a-directory")
	os.WriteFile(bad, []byte("x"), 0600)
	st.path = filepath.Join(bad, "store.json")
	if _, _, e := st.Local(planner.Snapshot(before.State), next); e == nil {
		t.Fatal("write failure acknowledged")
	}
	if !planner.Equal(before, st.Get()) {
		t.Fatal("memory changed after failed write")
	}
}
func TestConcurrentIndependentDevices(t *testing.T) {
	_, st := setup(t)
	b := planner.Snapshot(st.Get().State)
	room := st.Get().Room
	var wg sync.WaitGroup
	for _, id := range []string{"phone", "tablet", "desktop"} {
		wg.Add(1)
		go func(id string) {
			defer wg.Done()
			next := planner.Clone(b)
			next.Events = append(next.Events, event(id))
			if _, _, e := st.Sync(room, &b, next); e != nil {
				t.Error(e)
			}
		}(id)
	}
	wg.Wait()
	if len(st.Get().State.Events) != 3 {
		t.Fatal(st.Get())
	}
}
func TestNetworkListenerAndStaticAssets(t *testing.T) {
	s, _ := setup(t)
	if e := s.StartLocal(0); e != nil {
		t.Fatal(e)
	}
	defer s.Close()
	w := req(s, "GET", "/", "", nil, "")
	if w.Code != 200 || !strings.Contains(w.Body.String(), "blank") {
		t.Fatal(w.Code, w.Body)
	}
	if e := s.EnableLAN(0); e != nil {
		t.Fatal(e)
	}
	s.DisableLAN()
	if s.Status()["enabled"] != false {
		t.Fatal("LAN listener not closed")
	}
	_ = io.Discard
}

func TestExclusiveStoreLock(t *testing.T) {
	dir := t.TempDir()
	s, e := OpenStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	if second, e := OpenStore(dir); e == nil {
		second.Close()
		t.Fatal("duplicate writer accepted")
	}
	s.Close()
	s, e = OpenStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	s.Close()
}
