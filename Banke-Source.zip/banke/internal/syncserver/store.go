// Package syncserver is a local-only, authenticated HTTP synchronization service.
package syncserver

import (
	"banke.local/planner/internal/planner"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
)

type Disk struct {
	Version  int               `json:"version"`
	Room     string            `json:"room"`
	Revision uint64            `json:"revision"`
	State    planner.State     `json:"state"`
	Devices  map[string]string `json:"devices"` // SHA-256(token) -> friendly device name; no plaintext token.
}
type Store struct {
	mu     sync.Mutex
	path   string
	data   Disk
	lock   *os.File
	closed bool
}

func OpenStore(folder string) (*Store, error) {
	s := &Store{path: filepath.Join(folder, "schedule-sync.json")}
	var err error
	s.lock, err = lockStore(s.path)
	if err != nil {
		return nil, err
	}
	success := false
	defer func() {
		if !success {
			s.lock.Close()
		}
	}()
	raw, err := os.ReadFile(s.path)
	if os.IsNotExist(err) {
		s.data = Disk{1, planner.Token(16), 1, planner.Blank(), map[string]string{}}
		if err = s.writeLocked(); err != nil {
			return nil, err
		}
		success = true
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	if len(raw) > 8*1024*1024 {
		return nil, errors.New("存档过大；未覆盖原文件")
	}
	if err = json.Unmarshal(raw, &s.data); err != nil {
		return nil, errors.New("存档 JSON 损坏；未覆盖原文件，请从 .previous 备份恢复")
	}
	if s.data.Version != 1 || s.data.Room == "" || s.data.Devices == nil {
		return nil, errors.New("存档格式无效；原文件已保留")
	}
	if err = planner.Validate(s.data.State); err != nil {
		return nil, err
	}
	success = true
	return s, nil
}
func (s *Store) writeLocked() error {
	if s.closed {
		return errors.New("日程服务已经关闭，修改未确认保存")
	}
	if err := os.MkdirAll(filepath.Dir(s.path), 0700); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	temp, err := os.CreateTemp(filepath.Dir(s.path), ".banke-write-*")
	if err != nil {
		return err
	}
	name := temp.Name()
	defer os.Remove(name)
	temp.Chmod(0600)
	if _, err = temp.Write(raw); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Sync(); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Close(); err != nil {
		return err
	}
	if previous, er := os.ReadFile(s.path); er == nil {
		var d Disk
		if json.Unmarshal(previous, &d) == nil && planner.Validate(d.State) == nil {
			if err = os.WriteFile(s.path+".previous", previous, 0600); err != nil {
				return err
			}
		}
	}
	return os.Rename(name, s.path)
}
func (s *Store) Get() Disk { s.mu.Lock(); defer s.mu.Unlock(); return planner.Clone(s.data) }
func (s *Store) Local(base planner.Shared, next planner.State) (planner.State, []string, error) {
	if err := planner.Validate(next); err != nil {
		return next, nil, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	merged, notices, err := planner.Merge(&base, planner.Snapshot(next), planner.Snapshot(s.data.State))
	if err != nil {
		return next, nil, err
	}
	before := planner.Clone(s.data)
	s.data.State = planner.Apply(next, merged)
	s.data.Revision++
	if err = s.writeLocked(); err != nil {
		s.data = before
		return next, nil, err
	}
	return planner.Clone(s.data.State), notices, nil
}
func (s *Store) Sync(room string, base *planner.Shared, current planner.Shared) (Disk, []string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if room != "" && room != s.data.Room {
		return Disk{}, nil, errors.New("ROOM_CHANGED: 电脑数据空间已改变，请先备份，再断开并重新配对")
	}
	merged, notices, err := planner.Merge(base, current, planner.Snapshot(s.data.State))
	if err != nil {
		return Disk{}, nil, err
	}
	if !planner.Equal(planner.Canonical(planner.Snapshot(s.data.State)), merged) {
		before := planner.Clone(s.data)
		s.data.State = planner.Apply(s.data.State, merged)
		s.data.Revision++
		if err = s.writeLocked(); err != nil {
			s.data = before
			return Disk{}, nil, err
		}
	}
	return planner.Clone(s.data), notices, nil
}
func digest(token string) string { h := sha256.Sum256([]byte(token)); return hex.EncodeToString(h[:]) }
func (s *Store) AddDevice(name string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.data.Devices) >= 20 {
		return "", errors.New("最多配对 20 台设备，请先撤销旧配对")
	}
	token := planner.Token(32)
	key := digest(token)
	s.data.Devices[key] = name
	if err := s.writeLocked(); err != nil {
		delete(s.data.Devices, key)
		return "", err
	}
	return token, nil
}
func (s *Store) Authorize(token string) bool {
	if len(token) != 64 {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	key := digest(token)
	for known := range s.data.Devices {
		if subtle.ConstantTimeCompare([]byte(key), []byte(known)) == 1 {
			return true
		}
	}
	return false
}
func (s *Store) Revoke() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	before := s.data.Devices
	s.data.Devices = map[string]string{}
	if err := s.writeLocked(); err != nil {
		s.data.Devices = before
		return err
	}
	return nil
}
func (s *Store) Path() string { return s.path }

func (s *Store) Close() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil
	}
	s.closed = true
	if s.lock != nil {
		return s.lock.Close()
	}
	return nil
}
