package syncserver

import (
	"banke.local/planner/internal/planner"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"math/big"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

const Version = "1.1.0"

type Service struct {
	Store         *Store
	Files         fs.FS
	Admin         string
	mu            sync.Mutex
	local         *http.Server
	lan           *http.Server
	lanPort       int
	localPort     int
	pairCode      string
	expires       time.Time
	attempts      int
	attemptsStart time.Time
	TLSCert       string
	TLSKey        string
}

func New(store *Store, files fs.FS) *Service {
	return &Service{Store: store, Files: files, Admin: planner.Token(32), lanPort: 47833}
}
func makeHTTP(handler http.Handler) *http.Server {
	return &http.Server{Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 12 * time.Second, WriteTimeout: 12 * time.Second, IdleTimeout: 20 * time.Second, MaxHeaderBytes: 16 * 1024}
}
func (s *Service) StartLocal(port int) error {
	listener, err := net.Listen("tcp4", fmt.Sprintf("127.0.0.1:%d", port))
	if err != nil {
		return err
	}
	s.localPort = listener.Addr().(*net.TCPAddr).Port
	s.local = makeHTTP(s.Handler())
	go s.local.Serve(listener)
	return nil
}
func (s *Service) EnableLAN(port int) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.lan != nil {
		return nil
	}
	if s.TLSCert != "" {
		if _, err := tls.LoadX509KeyPair(s.TLSCert, s.TLSKey); err != nil {
			return fmt.Errorf("TLS 证书或私钥无效：%w", err)
		}
	}
	listener, err := net.Listen("tcp4", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return err
	}
	s.lanPort = listener.Addr().(*net.TCPAddr).Port
	s.lan = makeHTTP(s.Handler())
	server := s.lan
	if s.TLSCert != "" {
		go server.ServeTLS(listener, s.TLSCert, s.TLSKey)
	} else {
		go server.Serve(listener)
	}
	return nil
}
func (s *Service) DisableLAN() {
	s.mu.Lock()
	server := s.lan
	s.lan = nil
	s.pairCode = ""
	s.expires = time.Time{}
	s.mu.Unlock()
	if server != nil {
		server.Close()
	}
}
func (s *Service) Close() {
	defer s.Store.Close()
	s.DisableLAN()
	if s.local != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		s.local.Shutdown(ctx)
	}
}
func (s *Service) URL() string {
	return fmt.Sprintf("http://127.0.0.1:%d/#host=%s", s.localPort, s.Admin)
}
func (s *Service) PairCode() (string, time.Time) {
	s.mu.Lock()
	defer s.mu.Unlock()
	n, err := rand.Int(rand.Reader, big.NewInt(1000000))
	if err != nil {
		panic(err)
	}
	s.pairCode = fmt.Sprintf("%06d", n.Int64())
	s.expires = time.Now().Add(2 * time.Minute)
	return s.pairCode, s.expires
}
func private(ip net.IP) bool {
	v := ip.To4()
	if v == nil {
		return false
	}
	return v[0] == 10 || (v[0] == 172 && v[1] >= 16 && v[1] <= 31) || (v[0] == 192 && v[1] == 168) || v[0] == 127
}
func (s *Service) Status() map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	addresses := []string{}
	scheme := "http"
	if s.TLSCert != "" {
		scheme = "https"
	}
	list, _ := net.InterfaceAddrs()
	for _, a := range list {
		ip, _, err := net.ParseCIDR(a.String())
		if err == nil && ip.To4() != nil && !ip.IsLoopback() && private(ip) {
			addresses = append(addresses, fmt.Sprintf("%s://%s:%d", scheme, ip.String(), s.lanPort))
		}
	}
	code := ""
	if time.Now().Before(s.expires) {
		code = s.pairCode
	}
	return map[string]any{"enabled": s.lan != nil, "addresses": addresses, "code": code, "expires": s.expires, "deviceCount": len(s.Store.Get().Devices), "encrypted": s.TLSCert != ""}
}
func reply(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func fail(w http.ResponseWriter, status int, message string) {
	reply(w, status, map[string]any{"ok": false, "error": message})
}
func decode(w http.ResponseWriter, r *http.Request, to any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 4*1024*1024)
	d := json.NewDecoder(r.Body)
	d.DisallowUnknownFields()
	if err := d.Decode(to); err != nil {
		fail(w, 400, "请求 JSON 格式错误或超过 4 MB")
		return false
	}
	if err := d.Decode(new(any)); err != io.EOF {
		fail(w, 400, "只接受单个 JSON 对象")
		return false
	}
	return true
}
func hostName(host string) string {
	if h, _, err := net.SplitHostPort(host); err == nil {
		return h
	}
	return host
}
func localRequest(r *http.Request) bool {
	h, _, _ := net.SplitHostPort(r.RemoteAddr)
	return net.ParseIP(h).IsLoopback()
}
func (s *Service) admin(r *http.Request) bool {
	token := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	return localRequest(r) && subtle.ConstantTimeCompare([]byte(token), []byte(s.Admin)) == 1
}
func (s *Service) auth(r *http.Request) bool {
	if s.admin(r) {
		return true
	}
	return s.Store.Authorize(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
}
func (s *Service) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if recover() != nil {
				fail(w, 500, "服务内部错误；请保留备份并重试")
			}
		}()
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		peer, _, _ := net.SplitHostPort(r.RemoteAddr)
		if !private(net.ParseIP(peer)) {
			fail(w, 403, "只允许本机与可信私有 IPv4 局域网")
			return
		}
		h := hostName(r.Host)
		if h != "localhost" && !private(net.ParseIP(h)) {
			fail(w, 403, "无效主机名，请使用软件显示的 IPv4 地址")
			return
		}
		origin := r.Header.Get("Origin")
		sameOrigin := origin == "http://"+r.Host || origin == "https://"+r.Host
		// A file-origin native WebView has Origin:null. Authorization is never cookie-based.
		if origin != "" && origin != "null" && !sameOrigin {
			fail(w, 403, "不接受其他网站的跨源请求，请用内置客户端或本机网页")
			return
		}
		if origin != "" {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Vary", "Origin")
		}
		if r.Method == http.MethodOptions {
			w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
			w.WriteHeader(204)
			return
		}
		if !strings.HasPrefix(r.URL.Path, "/api/") {
			if r.Method != "GET" && r.Method != "HEAD" {
				fail(w, 405, "只接受 GET")
				return
			}
			if strings.Contains(r.URL.Path, "..") {
				http.NotFound(w, r)
				return
			}
			w.Header().Set("Cache-Control", "no-cache")
			w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' http: https:; object-src 'none'; base-uri 'none'; frame-src 'none'; form-action 'none'")
			http.FileServer(http.FS(s.Files)).ServeHTTP(w, r)
			return
		}
		if r.URL.Path == "/api/health" && r.Method == "GET" {
			reply(w, 200, map[string]any{"ok": true, "app": "BankeGeneric", "version": Version})
			return
		}
		if r.URL.Path == "/api/pair" && r.Method == "POST" {
			var input struct {
				Code string `json:"code"`
				Name string `json:"name"`
			}
			if !decode(w, r, &input) {
				return
			}
			if len(input.Name) > 80 || strings.TrimSpace(input.Name) == "" {
				fail(w, 400, "请填写设备名称，最多 80 字节")
				return
			}
			s.mu.Lock()
			now := time.Now()
			if now.Sub(s.attemptsStart) > 2*time.Minute {
				s.attemptsStart = now
				s.attempts = 0
			}
			s.attempts++
			valid := s.attempts <= 10 && now.Before(s.expires) && s.pairCode != "" && subtle.ConstantTimeCompare([]byte(input.Code), []byte(s.pairCode)) == 1
			if valid {
				s.pairCode = ""
				s.expires = time.Time{}
			}
			s.mu.Unlock()
			if !valid {
				fail(w, 403, "配对码错误、已使用、已过期或尝试过多；两分钟后在电脑生成新码")
				return
			}
			token, err := s.Store.AddDevice(input.Name)
			if err != nil {
				fail(w, 500, err.Error())
				return
			}
			disk := s.Store.Get()
			reply(w, 200, map[string]any{"ok": true, "token": token, "room": disk.Room})
			return
		}
		if strings.HasPrefix(r.URL.Path, "/api/admin/") {
			if !s.admin(r) {
				fail(w, 401, "需要本机管理员授权")
				return
			}
			switch r.URL.Path {
			case "/api/admin/status":
				if r.Method != "GET" {
					fail(w, 405, "只接受 GET")
					return
				}
				reply(w, 200, s.Status())
			case "/api/admin/enable":
				if r.Method != "POST" {
					fail(w, 405, "只接受 POST")
					return
				}
				s.mu.Lock()
				port := s.lanPort
				s.mu.Unlock()
				if err := s.EnableLAN(port); err != nil {
					fail(w, 500, "无法开启端口："+err.Error())
					return
				}
				s.PairCode()
				reply(w, 200, s.Status())
			case "/api/admin/pair":
				if r.Method != "POST" {
					fail(w, 405, "只接受 POST")
					return
				}
				s.PairCode()
				reply(w, 200, s.Status())
			case "/api/admin/disable":
				if r.Method != "POST" {
					fail(w, 405, "只接受 POST")
					return
				}
				s.DisableLAN()
				reply(w, 200, s.Status())
			case "/api/admin/revoke":
				if r.Method != "POST" {
					fail(w, 405, "只接受 POST")
					return
				}
				if err := s.Store.Revoke(); err != nil {
					fail(w, 500, err.Error())
					return
				}
				reply(w, 200, s.Status())
			default:
				fail(w, 404, "接口不存在")
			}
			return
		}
		if !s.auth(r) {
			fail(w, 401, "配对已失效，请备份后重新配对")
			return
		}
		if r.URL.Path == "/api/state" && r.Method == "GET" {
			d := s.Store.Get()
			reply(w, 200, map[string]any{"ok": true, "room": d.Room, "revision": d.Revision, "shared": planner.Snapshot(d.State)})
			return
		}
		if r.URL.Path == "/api/sync" && r.Method == "POST" {
			var input struct {
				Room    string          `json:"room"`
				Base    *planner.Shared `json:"base"`
				Current planner.Shared  `json:"current"`
			}
			if !decode(w, r, &input) {
				return
			}
			d, notices, err := s.Store.Sync(input.Room, input.Base, input.Current)
			if err != nil {
				fail(w, 409, err.Error())
				return
			}
			reply(w, 200, map[string]any{"ok": true, "room": d.Room, "revision": d.Revision, "shared": planner.Snapshot(d.State), "conflicts": notices})
			return
		}
		fail(w, 404, "接口不存在")
	})
}
func ParsePort(value string) (int, error) {
	p, e := strconv.Atoi(value)
	if e != nil || p < 0 || p > 65535 {
		return 0, errors.New("端口范围 0–65535")
	}
	return p, nil
}

func (s *Service) SetLANPort(port int) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.lan != nil || port < 0 || port > 65535 {
		return errors.New("无效端口或服务已在运行")
	}
	s.lanPort = port
	return nil
}
