// Package planner defines the shared, versioned, privacy-neutral schedule model.
package planner

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode/utf8"
)

type Event struct {
	ID        string `json:"id"`
	Title     string `json:"title"`
	Day       int    `json:"day"`
	Start     int    `json:"start"`
	End       int    `json:"end"`
	Category  string `json:"category"`
	Location  string `json:"location"`
	Notes     string `json:"notes"`
	Weeks     []int  `json:"weeks"`
	Uncertain bool   `json:"uncertain"`
}
type Shared struct {
	SemesterStart string   `json:"semesterStart"`
	Events        []Event  `json:"events"`
	Completed     []string `json:"completed"`
}
type State struct {
	Version       int      `json:"version"`
	SemesterStart string   `json:"semesterStart"`
	SelectedWeek  int      `json:"selectedWeek"`
	RangeStart    int      `json:"rangeStart"`
	RangeEnd      int      `json:"rangeEnd"`
	Events        []Event  `json:"events"`
	Completed     []string `json:"completed"`
	Theme         string   `json:"theme"`
}

func Blank() State {
	t := time.Now()
	t = t.AddDate(0, 0, -((int(t.Weekday()) + 6) % 7))
	return State{1, t.Format("2006-01-02"), 1, 420, 1380, []Event{}, []string{}, "light"}
}
func Snapshot(s State) Shared { return Clone(Shared{s.SemesterStart, s.Events, s.Completed}) }
func Apply(s State, shared Shared) State {
	s.SemesterStart = shared.SemesterStart
	s.Events = Clone(shared.Events)
	s.Completed = Clone(shared.Completed)
	return s
}
func Clone[T any](value T) T {
	b, _ := json.Marshal(value)
	var result T
	_ = json.Unmarshal(b, &result)
	return result
}
func Token(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

var idPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$`)

func validText(s string, max int, required bool) bool {
	return utf8.ValidString(s) && utf8.RuneCountInString(s) <= max && !strings.ContainsRune(s, 0) && (!required || strings.TrimSpace(s) != "")
}
func ValidateEvent(e Event) error {
	if !idPattern.MatchString(e.ID) || !validText(e.Title, 200, true) || !validText(e.Location, 200, false) || !validText(e.Notes, 3000, false) {
		return errors.New("日程名称、ID 或文本字段无效")
	}
	if e.Day < 1 || e.Day > 7 || e.Start < 0 || e.Start >= 1440 || e.End > 1440 || e.End <= e.Start {
		return errors.New("星期或起止时间无效")
	}
	if !map[string]bool{"course": true, "work": true, "study": true, "life": true, "rest": true}[e.Category] {
		return errors.New("分类无效")
	}
	if len(e.Weeks) == 0 || len(e.Weeks) > 52 {
		return errors.New("周次数量无效")
	}
	seen := map[int]bool{}
	for _, w := range e.Weeks {
		if w < 1 || w > 52 || seen[w] {
			return errors.New("周次无效或重复")
		}
		seen[w] = true
	}
	return nil
}
func ValidateShared(s Shared) error {
	t, err := time.Parse("2006-01-02", s.SemesterStart)
	if err != nil || t.Weekday() != time.Monday {
		return errors.New("第 1 周起点必须是有效的周一日期")
	}
	if s.Events == nil || s.Completed == nil || len(s.Events) > 1000 || len(s.Completed) > 24000 {
		return errors.New("日程列表格式或数量无效")
	}
	ids := map[string]bool{}
	for _, e := range s.Events {
		if err := ValidateEvent(e); err != nil {
			return err
		}
		if ids[e.ID] {
			return errors.New("日程 ID 重复")
		}
		ids[e.ID] = true
	}
	marks := map[string]bool{}
	for _, v := range s.Completed {
		if !validText(v, 160, true) || strings.ContainsAny(v, "\r\n\t") || marks[v] {
			return errors.New("完成记录无效")
		}
		marks[v] = true
	}
	return nil
}
func Validate(s State) error {
	if s.Version != 1 || s.SelectedWeek < 1 || s.SelectedWeek > 52 || s.RangeStart < 0 || s.RangeStart >= 1440 || s.RangeEnd > 1440 || s.RangeStart >= s.RangeEnd || s.RangeStart%30 != 0 || s.RangeEnd%30 != 0 || (s.Theme != "light" && s.Theme != "dark") {
		return errors.New("日程显示设置无效")
	}
	return ValidateShared(Snapshot(s))
}
func Equal(a, b any) bool { return reflect.DeepEqual(a, b) }
func Canonical(s Shared) Shared {
	s = Clone(s)
	sort.Slice(s.Events, func(i, j int) bool { return s.Events[i].ID < s.Events[j].ID })
	sort.Strings(s.Completed)
	return s
}
func mapEvents(events []Event) map[string]Event {
	m := map[string]Event{}
	for _, e := range events {
		m[e.ID] = e
	}
	return m
}
func toMap(e Event) map[string]any {
	b, _ := json.Marshal(e)
	out := map[string]any{}
	json.Unmarshal(b, &out)
	return out
}
func mergedEvent(base, left, right Event) (Event, bool) {
	bm, lm, rm := toMap(base), toMap(left), toMap(right)
	out := map[string]any{}
	conflict := false
	for k, lv := range lm {
		rv, bv := rm[k], bm[k]
		switch {
		case Equal(lv, rv):
			out[k] = lv
		case Equal(lv, bv):
			out[k] = rv
		case Equal(rv, bv):
			out[k] = lv
		default:
			conflict = true
			out[k] = lv
		}
	}
	b, _ := json.Marshal(out)
	var e Event
	json.Unmarshal(b, &e)
	if ValidateEvent(e) != nil {
		conflict = true
	}
	return e, !conflict
}
func conflictCopy(e Event) Event {
	// Content-derived ID makes retried requests idempotent, even after lost responses.
	b, _ := json.Marshal(e)
	h := sha256.Sum256(b)
	e.ID = "conflict-" + hex.EncodeToString(h[:16])
	return e
}
func boolSet(a []string) map[string]bool {
	m := map[string]bool{}
	for _, s := range a {
		m[s] = true
	}
	return m
}

// Merge is a three-way merge. Current-server data wins a genuinely conflicting field;
// the incoming event is retained as a separate record. Delete-versus-edit retains the edit.
// Date-origin mismatches are rejected: silently shifting every event is never safe.
func Merge(base *Shared, incoming, server Shared) (Shared, []string, error) {
	if err := ValidateShared(incoming); err != nil {
		return Shared{}, nil, err
	}
	if err := ValidateShared(server); err != nil {
		return Shared{}, nil, err
	}
	notices := []string{}
	if base == nil {
		if len(incoming.Events) == 0 && len(incoming.Completed) == 0 {
			return Canonical(server), notices, nil
		}
		if len(server.Events) == 0 && len(server.Completed) == 0 {
			return Canonical(incoming), notices, nil
		}
		empty := Shared{SemesterStart: server.SemesterStart, Events: []Event{}, Completed: []string{}}
		base = &empty
	}
	if err := ValidateShared(*base); err != nil {
		return Shared{}, nil, err
	}
	result := Shared{Events: []Event{}, Completed: []string{}}
	switch {
	case incoming.SemesterStart == server.SemesterStart:
		result.SemesterStart = server.SemesterStart
	case incoming.SemesterStart == base.SemesterStart && Equal(incoming.Events, base.Events) && Equal(incoming.Completed, base.Completed):
		result.SemesterStart = server.SemesterStart
	case server.SemesterStart == base.SemesterStart && Equal(server.Events, base.Events) && Equal(server.Completed, base.Completed):
		result.SemesterStart = incoming.SemesterStart
	default:
		return Shared{}, nil, errors.New("PLAN_START_CONFLICT: 两端第 1 周的日期不同，请先备份并将计划起点调整一致")
	}
	bm, lm, rm := mapEvents(base.Events), mapEvents(incoming.Events), mapEvents(server.Events)
	keys := map[string]bool{}
	for _, m := range []map[string]Event{bm, lm, rm} {
		for k := range m {
			keys[k] = true
		}
	}
	ids := []string{}
	for k := range keys {
		ids = append(ids, k)
	}
	sort.Strings(ids)
	output := map[string]Event{}
	for _, id := range ids {
		b, bok := bm[id]
		l, lok := lm[id]
		r, rok := rm[id]
		switch {
		case lok && rok && Equal(l, r):
			output[id] = l
		case lok == bok && (!lok || Equal(l, b)):
			if rok {
				output[id] = r
			}
		case rok == bok && (!rok || Equal(r, b)):
			if lok {
				output[id] = l
			}
		case !lok && rok:
			output[id] = r
			notices = append(notices, "删除与修改冲突，保留修改："+r.Title)
		case lok && !rok:
			output[id] = l
			notices = append(notices, "删除与修改冲突，保留修改："+l.Title)
		case lok && rok:
			if bok {
				if e, ok := mergedEvent(b, l, r); ok {
					output[id] = e
					continue
				}
			}
			output[id] = r
			c := conflictCopy(l)
			output[c.ID] = c
			notices = append(notices, "同一安排存在不同修改，已保留冲突副本："+l.Title)
		}
	}
	for _, e := range output {
		result.Events = append(result.Events, e)
	}
	bs, ls, rs := boolSet(base.Completed), boolSet(incoming.Completed), boolSet(server.Completed)
	marks := map[string]bool{}
	for _, m := range []map[string]bool{bs, ls, rs} {
		for k := range m {
			marks[k] = true
		}
	}
	for k := range marks {
		value := ls[k]
		if ls[k] == bs[k] {
			value = rs[k]
		}
		if value {
			result.Completed = append(result.Completed, k)
		}
	}
	result = Canonical(result)
	if err := ValidateShared(result); err != nil {
		return Shared{}, nil, fmt.Errorf("合并结果未保存：%w", err)
	}
	return result, notices, nil
}
