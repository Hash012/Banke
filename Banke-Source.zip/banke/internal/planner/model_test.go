package planner

import (
	"strings"
	"testing"
)

func fixture() Shared {
	return Shared{"2026-10-19", []Event{{"test-event", "安排", 7, 555, 605, "work", "", "", []int{1, 7, 52}, false}}, []string{}}
}
func mustMerge(t *testing.T, b *Shared, l, r Shared) Shared {
	t.Helper()
	m, _, e := Merge(b, l, r)
	if e != nil {
		t.Fatal(e)
	}
	return m
}
func TestBlankAndValidation(t *testing.T) {
	s := Blank()
	if err := Validate(s); err != nil {
		t.Fatal(err)
	}
	if len(s.Events) != 0 || len(s.Completed) != 0 {
		t.Fatal("blank contains data")
	}
	f := fixture()
	if err := ValidateShared(f); err != nil {
		t.Fatal(err)
	}
	invalid := []Event{}
	for _, change := range []func(*Event){func(e *Event) { e.Day = 8 }, func(e *Event) { e.End = e.Start }, func(e *Event) { e.Start = -1 }, func(e *Event) { e.Weeks = []int{1, 1} }, func(e *Event) { e.Weeks = []int{53} }, func(e *Event) { e.Category = "evil" }, func(e *Event) { e.ID = "../../x" }, func(e *Event) { e.Title = " " }, func(e *Event) { e.Notes = strings.Repeat("x", 3001) }} {
		e := Clone(f.Events[0])
		change(&e)
		invalid = append(invalid, e)
	}
	for i, e := range invalid {
		if ValidateEvent(e) == nil {
			t.Errorf("invalid case %d accepted", i)
		}
	}
}
func TestFirstEmptyClientDoesNotClear(t *testing.T) {
	r := fixture()
	l := Shared{"2026-10-26", []Event{}, []string{}}
	m := mustMerge(t, nil, l, r)
	if !Equal(m, Canonical(r)) {
		t.Fatal(m)
	}
}
func TestFirstEmptyServerAdopts(t *testing.T) {
	l := fixture()
	r := Shared{"2026-10-26", []Event{}, []string{}}
	m := mustMerge(t, nil, l, r)
	if !Equal(m, Canonical(l)) {
		t.Fatal(m)
	}
}
func TestSeparateFieldsMerge(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	l.Events[0].Title = "phone"
	r.Events[0].Location = "desk"
	m := mustMerge(t, &b, l, r)
	if len(m.Events) != 1 || m.Events[0].Title != "phone" || m.Events[0].Location != "desk" {
		t.Fatal(m)
	}
}
func TestConflictRetainedAndRetryIdempotent(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	l.Events[0].Title = "phone"
	r.Events[0].Title = "desktop"
	m, n, e := Merge(&b, l, r)
	if e != nil || len(n) != 1 || len(m.Events) != 2 {
		t.Fatal(m, n, e)
	}
	again := mustMerge(t, &b, l, m)
	if !Equal(m, again) {
		t.Fatal("retry duplicated/lost record", m, again)
	}
}
func TestConcurrentInvalidIntervalRetainsBoth(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	l.Events[0].Start = 590
	r.Events[0].End = 580
	m := mustMerge(t, &b, l, r)
	if len(m.Events) != 2 {
		t.Fatal(m)
	}
}
func TestDeleteUnchanged(t *testing.T) {
	b := fixture()
	l := Clone(b)
	l.Events = []Event{}
	m := mustMerge(t, &b, l, b)
	if len(m.Events) != 0 {
		t.Fatal(m)
	}
}
func TestDeleteVersusEdit(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	l.Events = []Event{}
	r.Events[0].Notes = "keep this"
	m := mustMerge(t, &b, l, r)
	if len(m.Events) != 1 || m.Events[0].Notes != "keep this" {
		t.Fatal(m)
	}
}
func TestIndependentAdditions(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	e := Clone(b.Events[0])
	e.ID = "phone-new"
	l.Events = append(l.Events, e)
	e.ID = "desktop-new"
	r.Events = append(r.Events, e)
	m := mustMerge(t, &b, l, r)
	if len(m.Events) != 3 {
		t.Fatal(m)
	}
}
func TestPlanStartMismatchRejected(t *testing.T) {
	b := fixture()
	l, r := Clone(b), Clone(b)
	l.SemesterStart = "2026-10-26"
	r.Events[0].Notes = "changed"
	_, _, e := Merge(&b, l, r)
	if e == nil || !strings.Contains(e.Error(), "PLAN_START_CONFLICT") {
		t.Fatal(e)
	}
}
func TestPlanStartChangeWithUnchangedPeer(t *testing.T) {
	b := fixture()
	r := Clone(b)
	r.SemesterStart = "2026-10-26"
	m := mustMerge(t, &b, b, r)
	if m.SemesterStart != r.SemesterStart {
		t.Fatal(m)
	}
}
func TestCompletedMerge(t *testing.T) {
	b := fixture()
	b.Completed = []string{"test-event:1"}
	l, r := Clone(b), Clone(b)
	l.Completed = []string{"test-event:7"}
	r.Completed = append(r.Completed, "test-event:52")
	m := mustMerge(t, &b, l, r)
	if !Equal(m.Completed, []string{"test-event:52", "test-event:7"}) {
		t.Fatal(m.Completed)
	}
}
func TestViewPreferencesAreLocal(t *testing.T) {
	s := Blank()
	s.SelectedWeek = 7
	s.RangeStart = 960
	s.Theme = "dark"
	m := Apply(s, fixture())
	if m.SelectedWeek != 7 || m.RangeStart != 960 || m.Theme != "dark" {
		t.Fatal(m)
	}
}
