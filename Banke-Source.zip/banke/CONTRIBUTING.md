# Contributing

欢迎提交问题和修复。提 Issue 时写明应用版本、系统版本/CPU、是否已解压、报错发生在下载/安装/启动/编辑/同步哪一步，以及脱敏后的复现步骤。不要附私人日程或签名密钥。

运行 `go test -race ./...`、`node tests/legacy-core.cjs`、`node --test tests/sync-model.cjs` 和 `python3 scripts/run_browser_tests.py`。涉及手机宿主或窗口的改动还必须做平台实测。不要把接口单元测试通过写成手机已安装测试通过。

`web/` 是唯一 UI 源；修改后运行 `python3 scripts/prepare_assets.py` 更新 Android/iOS 资源。若更改 Android 宿主，Java 和 `tools/android_host.py` 的语义必须一致，或明确只维护 SDK 路径并移除旧预览构建入口。

对同步模型的改动需要测试：离线重连、同时编辑、删除冲突、初次空白合并、重复请求、保存失败、计划起点不一致。不得以“修复同步”为由直接用空白覆盖旧存档。

发版先修改 VERSION/应用版本号，更新 CHANGELOG 和验收记录。代码提交采用 MIT；新增第三方代码、图标、库必须附来源和许可证。
