# LAN sync protocol 1.1

## Transport and authorization

The Go service is the shared workspace coordinator. It listens on loopback only by default. A local administrator explicitly opens a separate IPv4 LAN listener (47833 by default). RFC1918/private IPv4 and loopback peers only; hostnames other than localhost/literal private IP are rejected to limit DNS rebinding. No cloud, discovery, relay, IPv6 or internet port forwarding.

Default HTTP is **unencrypted**. A six-digit one-time pairing code expires after two minutes; at most ten attempts per two-minute window. Successful pairing returns a random 256-bit bearer token. Only SHA-256 token hashes are saved by the server; each client privately retains its token. Pairing/data requests require no cookies. Data export excludes credentials. The local admin token is ephemeral and initially carried in a URL fragment consumed by the UI.

CORS accepts same origin and `Origin: null` for packaged file-origin WebViews; foreign web origins are rejected. A null origin is not itself authentication: state requests require bearer tokens. The HTTP parser limits input to 4 MB, rejects unknown JSON fields and sets timeouts. Native iOS requests and client URL validation only allow the private address/API list. TLS can be configured on the CLI with a trusted certificate/key; clients do not accept invalid certificates automatically.

## API

| Method/path | Auth | Request/response |
| --- | --- | --- |
| GET `/api/health` | none | app/version only; no schedules |
| POST `/api/pair` | valid code | `{code,name}` → `{ok,token,room}` |
| GET `/api/state` | device or local admin bearer | `{ok,room,revision,shared}` |
| POST `/api/sync` | device or local admin bearer | `{room,base,current}` → `{ok,room,revision,shared,conflicts}` |
| GET `/api/admin/status` | local peer + admin bearer | listener state, IPs, current code, count |
| POST `/api/admin/enable`, `/pair`, `/disable`, `/revoke` | local peer + admin bearer | enable listener / new code / stop LAN / revoke all device tokens |

`shared` has `semesterStart`, `events`, `completed`. `base` is the client's last acknowledged server snapshot, initially null. `current` is the current local snapshot. `room` prevents a stale device from blindly writing to a recreated workspace.

## Merge and durability

Three-way field-level merge uses base/client/server, not wall-clock “last modified wins”. Independent additions and non-overlapping field edits merge. Conflicting values preserve server original plus a content-derived-ID incoming copy; retries are idempotent. Delete-versus-edit preserves the edit. Conflicting plan start dates reject instead of shifting all records. First empty client adopts existing coordinator records rather than clearing them.

A client's additional changes made during an in-flight request are rebased onto the response; an open editor defers response application. A successful local write occurs before updating the acknowledged baseline. Failure leaves a visible paused status and original data available. Computer writes use a temp file, fsync, rename and a previous valid copy; OS file locking prevents two independent host processes writing one folder.

Selected week, visible hours, theme and mobile selected day are view preferences and not shared. Polling is approximately 3 seconds in the foreground, plus attempted sync after edits and on returning online/visible. Background mobile execution is not guaranteed. Computer software and LAN sharing must remain running.

An authorized client may edit/delete all records in this workspace. It is not a role-based collaborative system. Deletions and replacement imports synchronize; maintain separate backups. Up to 1000 events, 24000 completion flags, 52 weeks, 20 paired devices. Invalid/oversized merged output is rejected without destroying the original workspace.
