# 放到 GitHub 并提供真正的软件下载

## 1. 提交源码

解压 Banke-Source.zip，`banke/` 就是仓库根目录（能直接看到 README.md 和 .github）。先运行 `python3 scripts/privacy_check.py`，再提交。源码包不含你的账号信息；将 MIT 版权/维护者信息调整为项目实际安排。

```sh
git init -b main
git add .
git commit -m "Initial Banke open source release"
gh auth login
gh repo create banke --public --source=. --remote=origin --push
```

所有 URL/Actions 使用当前仓库上下文，不需要修改源码中的个人用户名。首次推送后，在 Actions 页检查真实日志；本次交付没有预先运行你的 GitHub 工作流。

## 2. 保留稳定的 Android 签名

Android 覆盖升级需要保持包名和签名身份。当前 APK 的私钥**不在公开源码或公开完整包里**。私人签名备份是另一份明确标记 PRIVATE 的文件；只有你作为维护者保存，绝不上传 GitHub Releases。

设置仓库 Settings → Secrets and variables → Actions：

| Secret | 内容 |
| --- | --- |
| `ANDROID_KEY_PEM` | android-key.pem 的完整 PEM 文本 |
| `ANDROID_CERT_PEM` | android-cert.pem 的完整 PEM 文本 |

没有这两个 Secrets 时，普通 CI 用临时签名跑验证；推送正式 v* 标签则**失败而不是换一把随机签名继续发新版**。不要把临时 CI APK 当作连续可升级的公开发行。密钥可保存在个人密码管理器/离线保险备份中；GitHub Secrets 仅供自己的可信工作流使用。

选择创建自己的新密钥也可以，但它不能覆盖安装本次预览 APK；先在旧安装中导出日程，再安装你的签名版本。

## 3. 构建与草稿发布

```sh
git tag v1.1.0
git push origin v1.1.0
```

`.github/workflows/build.yml` 在三个桌面 runner 上编译，验证同步/界面，并生成 Windows ZIP、Android APK、Mac ZIP、源码 ZIP 和校验和。Android 使用官方 SDK 构建 Java，然后使用稳定 PEM 证书签名。iOS job 只编译模拟器目标；它没有也不会凭空生成 Apple 发行证书。

所有 jobs 成功后，release job 创建 **Draft + Prerelease**，把 zip/apk 文件上传为 Release assets。没有生成或者测试失败时停止，不自动补一个空文件。

到 Releases 页面编辑草稿：填写实际通过的真机测试、签名状态和已知限制，完成 [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md)，再发布。正式 Mac 分发还需你自己的 Developer ID 签名/公证，iOS 通过 Xcode/TestFlight/App Store 或合规的设备分发流程。

## 4. 避免“下载失败”再次发生

给普通用户的是 Release assets 的下载入口，不是源码目录里的 sandbox 路径、开发电脑绝对路径，或需要登录/会过期的 Actions artifact。

手动上传也可：

```sh
gh release create v1.1.0 dist/*.zip dist/*.apk dist/SHA256SUMS.txt \
  --draft --prerelease --verify-tag --title "Banke 1.1.0 preview" \
  --notes-file docs/RELEASE_NOTES.md
```

上述命令由维护者在自己账号中运行；本项目没有冒充一个已存在的公开下载站点。发布后，在未登录的浏览器中打开 Releases，真正下载/解压一遍。用 SHA256SUMS 校验，不要只验证页面 HTTP 状态。

参考：
- https://cli.github.com/manual/gh_release_create
- https://cli.github.com/manual/gh_release_upload
- https://github.com/actions/upload-artifact （Actions artifact 需要登录，且受保留期限约束）
