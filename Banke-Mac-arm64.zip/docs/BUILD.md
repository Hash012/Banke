# 构建、签名与可重复性

## 工具和依赖

本地本次验证环境是 Linux、Go 1.23.2、Node 22.16、Python 3.13、cryptography 46.0.4、clang/LLD 17。这些数字是**构建记录，不是推荐长期停留的安全版本**；公开分发前使用受支持的 Go 稳定版重建。GitHub 工作流默认取 Go stable 并保留构建日志。

Go 源码仅使用标准库，无需 go.sum 或 npm。UI 是无依赖的 JavaScript/CSS。打包脚本需要 Python 3.10+；APK v2 签名需要 `pip install -r requirements-build.txt`；界面测试另需 `pip install -r requirements-test.txt` 和 Playwright Chromium。

## Windows x64

在 Windows：

```powershell
go build -trimpath -ldflags="-H=windowsgui -s -w" -o dist/Banke-Windows.exe ./cmd/windows
.\dist\Banke-Windows.exe --smoke-test
```

在 Linux/macOS 交叉构建：

```sh
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H=windowsgui -s -w' -o dist/Banke-Windows.exe ./cmd/windows
```

`--smoke-test` 创建隔离临时日程，检查窗口控件、七天列与 32 行默认半小时格；必须在 Windows 上执行。不会清空日常存档。它不是完整的人工编辑/安装验收。

便携 EXE 不需要安装运行库。使用 `scripts/package_release.py --source-only` 打源码包；发行者签名需自行配置 SignTool/代码签名证书，项目不附 Windows 私钥。

## Android：两种公开、可重建的路径

### 推荐发行构建：官方 SDK + Java

安装 JDK 17、Android SDK 35、Build Tools 35.0.0 和 Gradle 8.9（AGP 8.7.3）。所有业务 UI 和 Java 宿主都在仓库里。

```sh
python3 scripts/prepare_assets.py
gradle -p android --no-daemon :app:assembleRelease
# 在 ANDROID_HOME/local.properties 中正确配置 SDK 后，上一步产生未签名 APK。
zipalign -f -p 4 android/app/build/outputs/apk/release/app-release-unsigned.apk build/aligned.apk
python3 scripts/sign_apk.py build/aligned.apk dist/Banke-Android.apk --key /PRIVATE/android-key.pem --cert /PRIVATE/android-cert.pem
apksigner verify --verbose --print-certs dist/Banke-Android.apk
```

SDK 工具命令需要加入 PATH。首次使用 Gradle 需要联网下载 AGP/SDK；没有 Gradle Wrapper JAR 被偷偷嵌入仓库。安装 Gradle 8.9 后可运行 `gradle -p android wrapper --gradle-version 8.9` 为自己的仓库生成官方 Wrapper。

### 当前附件的离线预览构建

本次环境无法下载 Android SDK，因此使用一个明确公开的最小 DEX/二进制资源编码器。符号化方法实现见 `tools/android_host.py`，等价的 Java 实现见 `android/app/src/main/java/`。它们只建立本地 WebView，不包含继承自旧 APK 的隐藏代码。

```sh
python3 -m pip install -r requirements-build.txt
python3 scripts/build_android.py --out dist/Banke-Android.apk \
  --key /PRIVATE/android-key.pem --cert /PRIVATE/android-cert.pem --generate-key
# 后续更新必须去掉 --generate-key，并使用同一对文件。
python3 scripts/check_apk.py dist/Banke-Android.apk
```

内部校验检查 APK v2 内容摘要、签名、证书、公钥和 ZIP 完整性。它**不能代替** Android 官方校验器、Android 安装解析器或真机测试。工作流还会用 SDK 的 `apksigner` 和 `aapt` 验证该编码器产生的预览 APK，再用 Java/SDK 重新构建发行候选。

安装到开发设备后验证：

```sh
adb install -r dist/Banke-Android.apk
adb shell am start -W -n org.banke.generic.sync/.MainActivity
adb shell pidof org.banke.generic.sync
```

包名 `org.banke.generic.sync`、min SDK 26、target SDK 34。该配置用于直接 APK 分发，不代表满足当前 Google Play 上架要求。修改 Android 宿主时，必须同时修改 Java 和符号指令源并运行校验；不再需要离线编码器时可只维护官方 SDK 路径。

## macOS 独立 .app

推荐在装有命令行开发工具的 Mac 上：

```sh
python3 scripts/build_mac.py --arch both
./dist/Banke-macOS-arm64/Banke.app/Contents/MacOS/Banke --smoke-test
# Intel Mac 对应 dist/Banke-macOS-amd64/...
```

AppKit/WKWebView 宿主 `cmd/mac/main.c` 通过公开 Objective-C runtime API 创建窗口，启动内置 Go 本地服务，不调用外部浏览器。默认固定本机端口 47832，以保持 WebView 存储来源稳定。关闭窗口会退出服务。

Linux 上的交叉构建使用 clang + ld64.lld，无需复制 Apple SDK；仓库自己声明所需公开 ABI，并生成极小的 libSystem 文本链接存根。某些 Swift 下游 LLD 会错误拒绝带平台元信息的对象；脚本仅去除中间对象的可选版本元信息，最终链接仍明确指定 CPU 和 macOS 12.0。没有修改已安装编译器或应用指令来跳过安全验证。

交叉链接程序含 ad-hoc Mach-O 签名，**不是** Apple Developer ID 签名，也没有公证。若系统拒绝，先完成下面的正规签名流程或从源码在自己的 Mac 构建；不要把“生成了 .app”写成“已通过 Gatekeeper”。

发布者应使用自己的 Developer ID Application 证书签名内嵌服务和整个 app；使用 `xcrun notarytool submit ... --wait` 公证后，再 `xcrun stapler staple Banke.app`。先签嵌套可执行文件再签外层包。公证所需 Apple 账号、证书和密码不属于源码，不能提交到 Git。

## iPhone / iPad

```sh
python3 scripts/prepare_assets.py
open apple/BankeGeneric.xcodeproj
```

在 Xcode 中选择 `BankeGeneric` target，把 Bundle Identifier 换成自己唯一的标识，选择自己的 Signing Team，连接 iPhone（iOS 16+）后运行。首次访问电脑需要允许“本地网络”。原生传输桥仅允许私有 IPv4 和规定的同步接口；不跳过 HTTPS 证书校验、不跟随重定向。

仅检查编译、不签名的模拟器构建：

```sh
xcodebuild -project apple/BankeGeneric.xcodeproj -scheme BankeGeneric \
 -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
 -derivedDataPath build/ios CODE_SIGNING_ALLOWED=NO build
```

模拟器 `.app` 不是手机安装包。分发到真实设备需要合适的签名/描述文件、设备注册或 TestFlight/App Store；未提供个人 Apple 证书时，无法生成任意 iPhone 都能安装的 IPA。不要重命名 ZIP/APK 作为 IPA。

## 可重复构建的边界

应用源代码、资源、DEX 编码器和签名算法都可检查。相同数据/工具/签名密钥下离线 APK 产物可重现；新生成证书的时间、签名身份、Go/SDK/Xcode 版本、绝对构建路径和平台打包器会影响二进制摘要。发布时固定工具版本并保留 `SHA256SUMS.txt`，不要仅凭版本名判断两个文件相同。

官方参考：
- https://developer.android.com/build/building-cmdline
- https://developer.android.com/build/releases/agp-8-7-0-release-notes
- https://source.android.com/docs/security/features/apksigning/v2
- https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices
- https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution
