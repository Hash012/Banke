# 验证记录与尚未完成的验收

本次构建日期：2026-10-19。版本：1.1.0。环境：Linux x86_64。

## 已执行的检查

- Go：13 个模型/合并测试，11 个存储、文件锁、授权及实际 HTTP 服务测试；包含竞态检测。
- Node：原有日程核心断言集及 9 个同步模型测试。检查分钟精度、周日、断线合并、删除/编辑冲突、在途编辑重放、起点日期冲突、完成标记和导出时排除凭据。
- 浏览器界面集成：Chromium 在内存页面渲染真实 HTML/CSS/JS；测试传输桥接至**真实 Go HTTP 服务**。验证空白初始化、电脑七列、手机布局、两端双向同步、离线后重连、模拟网页存储恢复、无 JavaScript 页面错误。
- Windows：Go 交叉编译为真正的 x64 PE GUI 程序；不是改名的源码、网页或 ZIP。
- Android：由公开符号指令源码生成 DEX，检查 DEX 校验值、APK ZIP CRC、APK v2 RSA 签名/证书/内容摘要及包内网页与源码一致性。
- macOS：交叉生成 Intel/Apple Silicon 两个 Mach-O 宿主与内置 Go 服务；检查 `.app` 结构和 ZIP 可执行权限。
- iOS：Swift 语法解析、Xcode 项目/资源路径检查。**语法解析不等于 Xcode SDK 编译**。
- 下载：逐个 ZIP CRC、内部成员存在性、SHA-256 清单核对；公开源码排除私钥、私人日程和旧编译产物。

## 浏览器检查的准确边界

当前受管浏览器环境不允许直接导航本机 HTTP 地址，所以本次执行：

```sh
python3 scripts/run_browser_tests.py --bridged
```

该模式使用内存页面和 localStorage 模型，传输桥由 Python 发出真实 HTTP 请求。它验证界面/控制器与服务协作，**不验证原生 WebView 网络策略、浏览器 CORS/混合内容策略、系统权限、localStorage 真机持久性或安装体验**。没有修改或绕过受管浏览器策略。

在自己的开发机/GitHub runner 上运行下面这条命令，执行正常浏览器网络和真实浏览器存储测试：

```sh
python3 scripts/run_browser_tests.py
```

## 尚未执行（不得对外标为通过）

- 真实 Windows 的双击启动、任务栏、原生编辑、网络防火墙、退出和覆盖升级。
- 安卓/HarmonyOS 真机安装、系统 WebView 兼容性、文件导入、长按复制、锁屏/重启与升级数据保留。
- 官方 Android `apksigner`/`aapt` 解析验证（本地没有 SDK；已写入 CI）。
- Mac 的原生 AppKit/WKWebView 启动、权限、安全提示、关闭后服务退出；Developer ID 签名和公证。
- iOS 的 Xcode SDK 完整编译、Apple 签名、真机安装、局域网授权、TestFlight 分发。
- 你的 GitHub 账号中的任何实际 Actions 运行或 Release 发布。
- 长期运行、崩溃/断电恢复、所有校园/访客网络、跨网访问、持续后台同步。

## 重新运行

```sh
go test -race ./...
node tests/legacy-core.cjs
node --test tests/sync-model.cjs
python3 scripts/run_browser_tests.py
python3 scripts/check_apk.py dist/Banke-Android.apk --compare-assets
python3 scripts/privacy_check.py
python3 scripts/check_downloads.py dist/SHA256SUMS.txt
```

Windows 和 Mac 宿主提供 `--smoke-test`，CI 在对应平台调用它们。实际 native runner 检查失败会阻止 Release 草稿，不会以文件存在/编译成功代替启动成功。自动化通过后仍需 [人工验收清单](RELEASE_CHECKLIST.md)。
