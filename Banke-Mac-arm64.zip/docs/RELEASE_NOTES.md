# Banke 1.1.0 preview

通用空白七天日程，带 opt-in 私人 Wi-Fi 同步。无预置日程，无云账号。

下载 ZIP 后解压使用。Windows 是原生便携 EXE；Android 是独立 APK；Mac 分 Intel 和 Apple Silicon。iOS 仅提供完整待签名 Xcode 工程，不是可直接安装的 IPA。

默认 HTTP 未加密，仅在可信私人网络中使用。电脑和共享服务需运行，手机在前台同步；后台实时同步不保证。

**发布者请在公开本草稿前补写：实际测试设备、测试日期、APK/Windows/Mac 签名状态、Apple 公证状态、已知问题。不要把自动编译成功当作四平台真机验收成功。**

源码和 MIT 许可证附带，完整使用、备份、同步、排障说明在 README.md。签名私钥不属于公开附件。
