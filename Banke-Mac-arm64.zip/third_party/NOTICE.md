# Third-party notices

Application UI, icons, native glue, synchronization logic, packaging scripts and tests in this repository are licensed under the root MIT license.

Go-built executables contain the Go standard library/runtime. Their BSD-style license is reproduced in GO-LICENSE.txt (and patent grant where supplied). Go source/toolchains are available from https://go.dev/ .

Android WebView, Android SDK, Apple UIKit/AppKit/WebKit and their operating-system runtimes are supplied by their respective platforms, not redistributed as source in this repository. The Linux macOS linker stub is a project-authored list of public libSystem ABI symbols, not a copied Apple SDK.

Python cryptography is a build-time dependency under Apache-2.0/BSD terms; Playwright is a test-time dependency under Apache-2.0. These installed packages are not bundled into the application or vendored in this repository. See their upstream licenses if redistributing those tools themselves.

No font files, third-party tracking SDKs, external web assets, personal schedule snapshots, or opaque predecessor APK executables are included.
